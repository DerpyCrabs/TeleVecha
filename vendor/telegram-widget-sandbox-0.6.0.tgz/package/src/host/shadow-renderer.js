import { createRenderer } from "../renderer/core";
const BASE_CSS = ":host{all:initial;display:block;width:100%;position:relative;contain:layout paint style;container-type:size;container-name:tw}:where(html){display:flow-root;position:relative;min-height:0}:where(head){display:none}:where(body){display:block}";
const SIZE_QUERY = /^\s*\(\s*(min|max)-(width|height)\s*:\s*([\d.]+)px\s*\)\s*$/i;
class ShadowDomRenderer {
  static factory = (container, theme) => new ShadowDomRenderer(container, theme);
  /** Tells WidgetHost to run the validator in shadow scope (`:root`, `:host`, `@media`, viewport units). */
  cssScope = "shadow";
  element;
  onMessage = null;
  onDiag = null;
  shadow;
  html;
  core;
  queued = [];
  destroyed = false;
  constructor(container, theme) {
    const el = document.createElement("div");
    el.className = "widget-frame widget-shadow";
    el.style.colorScheme = theme;
    this.element = el;
    this.shadow = el.attachShadow({ mode: "open" });
    const base = document.createElement("style");
    base.textContent = BASE_CSS;
    const html = document.createElement("html");
    html.setAttribute("data-tw-root", "");
    const head = document.createElement("head");
    const body = document.createElement("body");
    html.append(head, body);
    this.shadow.append(base, html);
    this.html = html;
    this.core = createRenderer(this.env(head, body));
    container.appendChild(el);
  }
  env(head, body) {
    const html = this.html;
    const el = this.element;
    return {
      doc: document,
      root: this.shadow,
      roots: () => ({ html, head, body }),
      origin: () => {
        const r = html.getBoundingClientRect();
        return { x: r.left, y: r.top };
      },
      viewport: () => ({ innerWidth: el.clientWidth, innerHeight: el.clientHeight, dpr: window.devicePixelRatio }),
      docHeight: () => Math.ceil(html.getBoundingClientRect().height),
      matchMedia: (query) => {
        const m = SIZE_QUERY.exec(query);
        if (!m) return matchMedia(query).matches;
        const actual = m[2].toLowerCase() === "width" ? el.clientWidth : el.clientHeight;
        const limit = parseFloat(m[3]);
        return m[1].toLowerCase() === "min" ? actual >= limit : actual <= limit;
      },
      onViewportResize: (cb) => {
        const ro = new ResizeObserver(cb);
        ro.observe(el);
        return () => ro.disconnect();
      },
      onColorSchemeChange: (cb) => {
        const mq = matchMedia("(prefers-color-scheme: dark)");
        mq.addEventListener("change", cb);
        return () => mq.removeEventListener("change", cb);
      },
      // The host element is the bubble's canvas: a body background reaches the whole bubble, as in a frame.
      canvas: el
    };
  }
  load() {
    if (this.destroyed || !this.queued) return;
    this.core.init((msg) => {
      if (!this.destroyed) this.onMessage?.(msg);
    });
    const q = this.queued;
    this.queued = null;
    for (const msg of q) this.core.onMessage(msg);
  }
  send(msg) {
    if (this.destroyed) return;
    if (this.queued) this.queued.push(msg);
    else this.core.onMessage(msg);
  }
  setTheme(theme) {
    this.element.style.colorScheme = theme;
  }
  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    this.core.destroy();
    this.element.remove();
  }
}
export {
  ShadowDomRenderer
};
