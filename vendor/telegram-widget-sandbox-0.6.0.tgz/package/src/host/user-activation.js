const TYPES = /* @__PURE__ */ new Set(["click", "dblclick", "mousedown", "mouseup", "pointerdown", "pointerup"]);
const GESTURE_TTL_MS = 5e3;
const pointerClick = (ev) => Number(ev.detail) > 0;
function isUserActivation(ev) {
  const type = String(ev.type ?? "");
  if (!TYPES.has(type)) return false;
  return type === "click" || type === "dblclick" ? pointerClick(ev) : true;
}
class GestureCounter {
  n = 0;
  pressOpen = false;
  lastType = "";
  /** The gesture number for this event, 0 when it is not a user activation. */
  gestureFor(ev) {
    const type = String(ev.type ?? "");
    if (!TYPES.has(type)) return 0;
    let continues = false;
    if (type === "mousedown") continues = this.lastType === "pointerdown";
    else if (type === "pointerup" || type === "mouseup") continues = this.pressOpen;
    else if (type === "click") continues = this.pressOpen;
    else if (type === "dblclick") continues = this.lastType === "click";
    if (!continues && !isUserActivation(ev)) {
      this.pressOpen = false;
      this.lastType = "";
      return 0;
    }
    if (!continues) this.n++;
    this.pressOpen = type !== "click" && type !== "dblclick";
    this.lastType = type;
    return this.n;
  }
  /**
   * A primary press began: the renderer's `gesture` claim, sent for every one, whether the widget listens or not, and
   * before the press's own events. What follows is a new gesture, not the end of an open one: a finger's pointerdown is
   * not `trusted` (it may become the chat's scroll), so without this its release continued a press that had ended
   * without a click (a drag), whose gesture was spent.
   */
  pressBegan() {
    this.pressOpen = false;
    this.lastType = "";
  }
}
class HostActivationGate {
  issued = /* @__PURE__ */ new Map();
  consumed = 0;
  issue(gesture, now) {
    this.issued.set(gesture, now);
    if (this.issued.size > 64) for (const k of [...this.issued.keys()].slice(0, this.issued.size - 64)) this.issued.delete(k);
  }
  /** True once per issued gesture, while the widget is visible and the gesture is recent. */
  accept(gesture, now, visible) {
    if (!this.available(gesture, now, visible)) return false;
    this.consumed = gesture;
    return true;
  }
  /** What `accept` would say, without consuming the gesture (a request consumes it only when it goes out as a press's). */
  available(gesture, now, visible) {
    const n = typeof gesture === "number" && Number.isInteger(gesture) ? gesture : 0;
    const at = this.issued.get(n);
    return visible && n > this.consumed && at !== void 0 && now - at <= GESTURE_TTL_MS;
  }
}
export {
  GESTURE_TTL_MS,
  GestureCounter,
  HostActivationGate,
  isUserActivation
};
