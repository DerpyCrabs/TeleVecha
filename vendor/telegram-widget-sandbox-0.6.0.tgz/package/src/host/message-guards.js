function isTypedMessage(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value) && typeof value.type === "string";
}
function finiteNumber(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : void 0;
}
export {
  finiteNumber,
  isTypedMessage
};
