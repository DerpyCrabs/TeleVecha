import { PROFILE_TABLES } from "../shared/profile-tables";
const words = (s) => s.trim().split(/\s+/);
const P = PROFILE_TABLES;
const elementsWith = (action) => Object.entries(P.html.elements).filter(([, a]) => a === action).map(([t]) => t);
const SECURITY_DROPPED_TAGS = new Set(words(`
  script iframe frame frameset object embed link meta base portal noscript set title template applet param
  noembed noframes plaintext xmp listing slot track area map math metadata fencedframe audio video source
`));
const HTML_TAGS = new Set(elementsWith("keep").filter((t) => !SECURITY_DROPPED_TAGS.has(t)));
const REPLACED_TAGS = new Map([
  ...elementsWith("span").map((t) => [t, "span"]),
  ...elementsWith("div").map((t) => [t, "div"])
]);
const DROPPED_TAGS = /* @__PURE__ */ new Set([...SECURITY_DROPPED_TAGS, ...elementsWith("drop")]);
const SVG_TAGS = new Map(P.svg.elements.map((t) => [t.toLowerCase(), t]));
const HTML_ATTRS = new Set(P.html.attributes);
const SVG_ATTRS = P.svg.attributes;
const SVG_ALLOWED_ATTRS = new Set(SVG_ATTRS.map((a) => a.toLowerCase()));
const ALLOWED_ATTRS = /* @__PURE__ */ new Set([...HTML_ATTRS, ...SVG_ALLOWED_ATTRS]);
const SVG_ATTR_CASE = new Map(SVG_ATTRS.filter((a) => a !== a.toLowerCase()).map((a) => [a.toLowerCase(), a]));
const URL_ATTRS = new Set(words(`
  href xlink:href src srcset poster action formaction background ping data cite codebase manifest longdesc
  usemap profile icon archive classid lowsrc dynsrc srcdoc imagesrcset imagesizes attributionsrc
`));
const CSS_VALUE_ATTRS = new Set(words(`
  fill stroke filter mask clip-path marker marker-start marker-mid marker-end cursor color flood-color
  lighting-color stop-color
`));
const ANIMATION_VALUE_ATTRS = /* @__PURE__ */ new Set(["from", "to", "by", "values"]);
const SILENT_DROP_ATTRS = new Set(words(`
  xmlns xmlns:xlink target rel download autofocus nonce is loading decoding crossorigin referrerpolicy
  integrity fetchpriority charset http-equiv content async defer
`));
const ALL_PROPS = {
  scrollTop: { type: "number", tags: null },
  scrollLeft: { type: "number", tags: null }
};
const inProfile = (all, names) => Object.fromEntries(Object.entries(all).filter(([k]) => names.includes(k)));
const PROPS = inProfile(ALL_PROPS, P.properties);
const ALL_METHODS = {
  scrollIntoView: 4,
  setPointerCapture: 1,
  releasePointerCapture: 1,
  scrollTo: 2,
  scrollBy: 2,
  // Not DOM methods: (un)subscribe the element in the renderer's ResizeObserver.
  observeResize: 0,
  unobserveResize: 0
};
const METHODS = inProfile(ALL_METHODS, P.methods);
const CANVAS_METHODS = new Set(P.canvas.methods);
const CANVAS_PROPS = new Set(P.canvas.properties);
const CANVAS_OUT_OF_PROFILE = new Set(words(`
  putImageData globalCompositeOperation shadowBlur shadowColor shadowOffsetX shadowOffsetY filter
  letterSpacing wordSpacing fontKerning fontStretch fontVariantCaps textRendering
`));
const CANVAS_GRADIENTS = new Set(P.canvas.gradients);
const CANVAS_PATH_METHODS = new Set(words(`
  moveTo lineTo bezierCurveTo quadraticCurveTo arc arcTo ellipse rect roundRect closePath addPath
`));
const SVG_QUERY_METHODS = new Set(words(`
  getBBox getComputedTextLength getTotalLength getPointAtLength getCTM getScreenCTM getSubStringLength
  getNumberOfChars
`));
const CANVAS_QUERY_METHODS = new Set(P.canvas.queries.filter((m) => m !== "measureText"));
export {
  ALLOWED_ATTRS,
  ANIMATION_VALUE_ATTRS,
  CANVAS_GRADIENTS,
  CANVAS_METHODS,
  CANVAS_OUT_OF_PROFILE,
  CANVAS_PATH_METHODS,
  CANVAS_PROPS,
  CANVAS_QUERY_METHODS,
  CSS_VALUE_ATTRS,
  DROPPED_TAGS,
  HTML_ATTRS,
  HTML_TAGS,
  METHODS,
  PROPS,
  REPLACED_TAGS,
  SECURITY_DROPPED_TAGS,
  SILENT_DROP_ATTRS,
  SVG_ALLOWED_ATTRS,
  SVG_ATTR_CASE,
  SVG_QUERY_METHODS,
  SVG_TAGS,
  URL_ATTRS
};
