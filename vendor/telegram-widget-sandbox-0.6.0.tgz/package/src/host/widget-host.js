import { finiteNumber, isTypedMessage } from "./message-guards";
import sandboxBundle from "virtual:sandbox-bundle";
import { IframeRenderer } from "./iframe-renderer";
import { GestureCounter, HostActivationGate } from "./user-activation";
import {
  DEFAULT_LOCALE,
  DEFAULT_RESIZE_ANCHOR,
  HapticGate,
  PRIVILEGED_METHODS,
  RequestGate,
  allowedInPreview,
  checkBridgeCall,
  checkChatType,
  checkContentSafeArea,
  checkLocale,
  checkRequestAnswer,
  checkStorageCommit,
  checkViewer,
  checkWidgetData,
  requestFailure,
  requestRefusal,
  STORAGE_QUOTA_BYTES,
  toWidgetTheme,
  viewerUser,
  VIEWER_FIELD_RULES,
  walletFailure
} from "../shared/sdk-policy";
import { PROFILE_VERSION } from "../shared/profile-tables";
import { checkPaintLimit, paintLimitMessage } from "../shared/paint-policy";
import { Validator } from "./validator";
import {
  LIMIT_DEFAULTS,
  SAB_BIN_LEN,
  SAB_HEADER,
  SAB_JSON_LEN,
  SAB_SIZE,
  SAB_STATE,
  resolvePolicy
} from "../shared/protocol";
const MIN_HEIGHT = 50;
const MAX_HEIGHT = 600;
const encoder = new TextEncoder();
const BUBBLE_ACTIONS = /* @__PURE__ */ new Set(["menu", "swipe", "scroll", "back"]);
const REQUEST_REFUSED = {
  disabled: "the server allows no requests for this message (no can_query: a widget sent without allow_queries, or a forwarded copy of one sent without fwd_allow_queries)",
  busy: "a request is already in flight",
  "no-activation": "it needs a tap on the visible widget, one request per tap; this message allows no background requests (no background_query)",
  "rate-limited": "background requests at most once per 5 s",
  "no-wallet": "the client has no wallet for this user (no WidgetContext.wallet)"
};
const WALLET_REFUSED = {
  "no-activation": "it needs a tap on the visible widget, or the answer to a call made by a tap within 10 s; one call each",
  busy: "a request or a wallet call is already in flight"
};
const GESTURES = /* @__PURE__ */ new Set(["press", "tap", "double-tap", "hold", "drag-x", "drag-y", "menu-click"]);
class WidgetHost {
  constructor(container, html, opts) {
    this.opts = opts;
    const diag = (kind, detail) => opts.onDiag?.(kind, detail);
    this.widgetTheme = toWidgetTheme(opts.theme);
    this.theme = this.widgetTheme.colorScheme;
    this.safeArea = checkContentSafeArea(opts.contentSafeArea);
    this.visible = opts.visible ?? true;
    const preview = opts.context?.preview === true;
    const canQuery = opts.context?.canQuery === true && !preview;
    this.context = {
      isCopy: opts.context?.isCopy === true && !preview,
      canQuery,
      backgroundQuery: opts.context?.backgroundQuery === true && !preview,
      wallet: opts.context?.wallet === true && canQuery,
      preview
    };
    this.renderer = (opts.rendererFactory ?? IframeRenderer.factory)(container, this.theme);
    this.element = this.renderer.element;
    this.validator = new Validator(diag, { colorScheme: this.theme, scope: this.renderer.cssScope ?? "document" });
    this.policy = resolvePolicy(opts.policy);
    this.validator.setPolicy(this.policy);
    this.renderer.onMessage = (msg) => {
      if (isTypedMessage(msg)) this.onRenderer(msg);
    };
    this.renderer.onDiag = diag;
    this.renderer.load();
    this.toRenderer({ type: "theme", theme: this.widgetTheme });
    this.toRenderer({ type: "safeArea", inset: this.safeArea });
    this.toRenderer({ type: "policy", policy: this.policy });
    if (opts.bubbleGestures && !preview) this.setBubbleGestures(opts.bubbleGestures);
    this.viewport ??= { innerWidth: this.element.clientWidth || 400, innerHeight: this.element.clientHeight || 300, dpr: window.devicePixelRatio };
    const config = {
      memoryLimitBytes: opts.memoryLimitBytes ?? LIMIT_DEFAULTS.memoryLimitBytes,
      cpuLimitMs: opts.cpuLimitMs ?? LIMIT_DEFAULTS.cpuLimitMs,
      cpuQuotaMs: opts.cpuQuotaMs ?? LIMIT_DEFAULTS.cpuQuotaMs,
      cpuQuotaWindowMs: opts.cpuQuotaWindowMs ?? LIMIT_DEFAULTS.cpuQuotaWindowMs,
      cpuKillAfterMs: opts.cpuKillAfterMs ?? LIMIT_DEFAULTS.cpuKillAfterMs,
      mainThreadQuotaMs: opts.mainThreadQuotaMs ?? LIMIT_DEFAULTS.mainThreadQuotaMs,
      maxTimers: opts.maxTimers ?? LIMIT_DEFAULTS.maxTimers,
      visible: opts.visible ?? true,
      policy: this.policy,
      features: opts.features ?? [],
      viewport: this.viewport,
      theme: this.theme,
      themeParams: this.widgetTheme.params,
      locale: checkLocale(opts.locale) ?? DEFAULT_LOCALE,
      contentSafeArea: this.safeArea,
      profile: PROFILE_VERSION,
      // A preview has no message yet: no storage of its own (it lives in memory for this run and is never committed).
      storage: preview ? {} : this.preload(opts.storage),
      ...this.checkData(opts.data),
      isCopy: this.context.isCopy,
      canQuery: this.context.canQuery,
      isPreview: preview,
      // A copy is told nothing about the chat it is in (the bot must not learn where its widget was forwarded). The
      // widget knows its viewer only where it may send requests (canQuery, never in a preview): a widget that may not
      // talk to the bot cannot pass the id out through a link either, and the rule matches the network marker.
      chatType: preview || this.context.isCopy ? null : checkChatType(opts.context?.chatType),
      viewer: this.context.canQuery ? this.checkViewer(opts.context?.viewer) : null,
      wallet: this.context.wallet
    };
    let pooled = null;
    if (opts.workerPool) {
      pooled = opts.workerPool.take();
      this.worker = pooled.worker;
      this.sab = pooled.sab;
    } else {
      this.worker = new Worker(new URL("./worker.js", import.meta.url), { type: "module" });
      this.sab = new SharedArrayBuffer(SAB_SIZE);
    }
    this.header = new Int32Array(this.sab, 0, SAB_HEADER / 4);
    this.payload = new Uint8Array(this.sab, SAB_HEADER);
    this.worker.onmessage = (e) => {
      if (isTypedMessage(e.data)) this.onWorker(e.data);
    };
    this.worker.onerror = (e) => this.die("worker error: " + e.message);
    if (pooled) for (const m of pooled.pending.splice(0)) this.onWorker(m);
    if (opts.workerPool) this.toWorker({ type: "start", html, config });
    else this.toWorker({ type: "init", html, sab: this.sab, config, sandboxBundle });
  }
  opts;
  /** The renderer's element in the bubble (an iframe for the product renderer, a canvas for Blitz). */
  element;
  /** The product renderer's frame; null for other renderers (Playwright suites look inside it). */
  get iframe() {
    return this.element instanceof HTMLIFrameElement ? this.element : null;
  }
  /** The edge of the bubble that stays put when the widget's height changes: the widget's latest `setResizeAnchor`, `top` until then. */
  get resizeAnchor() {
    return this.anchor;
  }
  /** Whether the widget watches its shared `public_data` (its latest `watchPublicData` / `unwatchPublicData`), false until then. */
  get watchesPublicData() {
    return this.watching;
  }
  /** What the client draws over the widget as the widget sees it (checked: `contentSafeArea`, `setContentSafeArea`). */
  get contentSafeArea() {
    return { ...this.safeArea };
  }
  worker = null;
  renderer;
  validator;
  sab;
  header;
  payload;
  qid = 0;
  pendingQuery = 0;
  destroyed = false;
  dead = false;
  viewport;
  theme;
  widgetTheme;
  safeArea;
  visible;
  policy;
  gestures = new GestureCounter();
  activation = new HostActivationGate();
  blockedBridgeReported = 0;
  rejectedBridgeReported = 0;
  rejectedStorageReported = 0;
  haptics = new HapticGate();
  anchor = DEFAULT_RESIZE_ANCHOR;
  watching = false;
  context;
  previewBlockedReported = 0;
  requests = new RequestGate();
  /** A background request the widget made off screen: it goes to the client when the widget appears (`setVisible`). */
  heldRequest = null;
  blockedRequestsReported = 0;
  setTheme(theme) {
    this.widgetTheme = toWidgetTheme(theme);
    this.theme = this.widgetTheme.colorScheme;
    this.renderer.setTheme(this.theme);
    this.toRenderer({ type: "theme", theme: this.widgetTheme });
    const ops = this.validator.setTheme(this.theme);
    if (ops.length) this.toRenderer({ type: "ops", ops });
    this.toWorker({ type: "theme", theme: this.theme, themeParams: this.widgetTheme.params });
  }
  /**
   * What the client draws over the widget changed with the bubble's layout (docs/sdk-v1.md §2.17, §5.12): a caption
   * added or removed by an edit, an "edited" mark that widens the time. The renderer gets the root variables and the
   * widget `contentSafeAreaInset` and `contentSafeAreaChanged`, from the same call; never per frame.
   */
  setContentSafeArea(area) {
    this.safeArea = checkContentSafeArea(area);
    this.toRenderer({ type: "safeArea", inset: this.safeArea });
    this.toWorker({ type: "safeArea", inset: this.safeArea });
  }
  /** Turns the renderer's bubble on or off (`WidgetHostOptions.bubbleGestures`); a preview takes no input at all. */
  setBubbleGestures(mode) {
    if (this.context.preview) return;
    const o = typeof mode === "object" ? mode : {};
    this.toRenderer({ type: "arbitrate", bubble: mode !== false, touch: o.touch === true, rtl: o.rtl === true });
  }
  /**
   * The bot's data changed (`updateMessageWidgetData`, or a new `public_data` from polling the shared object): the
   * full state of both strings. The widget gets `chatDataChanged` / `publicDataChanged` for each that differs; a copy
   * keeps no `chatData`, only its `publicData` changes.
   */
  setData(data) {
    this.toWorker({ type: "bridge", event: { type: "data", ...this.checkData(data) } });
  }
  /** The viewer as the widget sees it; a field that breaks its rule is left out and reported (`data-rejected`). */
  checkViewer(viewer) {
    const v = checkViewer(viewerUser(viewer));
    for (const field of v.rejected) this.opts.onDiag?.("data-rejected", `viewer.${field}: ${VIEWER_FIELD_RULES[field]}; the widget does not see it`);
    return v.viewer;
  }
  checkData(data) {
    const d = checkWidgetData(data, this.context.isCopy);
    if (d.rejected.length) this.opts.onDiag?.("data-rejected", `${d.rejected.join(" and ")}: not text of at most 1024 bytes (UTF-8, no NUL); the widget sees null`);
    return { chatData: d.chatData, publicData: d.publicData };
  }
  /**
   * docs/sdk-v1.md §2.14: a press unlocks one request, background ones only where the context allows them; one in
   * flight. The gate decides first; one made off screen waits here for the widget to appear (`held`); a client
   * without `onRequest` refuses at delivery, as the native hosts do.
   */
  request(id, data, wallet, gesture) {
    const now = performance.now();
    const pressed = this.policy === "compat" || this.activation.available(gesture, now, this.visible);
    const c = this.context;
    const verdict = this.requests.decide(now, { gesture: pressed, visible: this.visible, canQuery: c.canQuery, backgroundQuery: c.backgroundQuery, withWallet: wallet, wallet: c.wallet });
    if (requestRefusal(verdict)) {
      const why = wallet && verdict === "no-activation" ? "a request for the wallet needs a tap on the visible widget, one request per tap" : REQUEST_REFUSED[verdict] ?? verdict;
      return this.refuseRequest(id, verdict, `request refused (${verdict}): ${why}`);
    }
    if (verdict === "foreground" && this.policy === "strict") this.activation.accept(gesture, now, this.visible);
    if (verdict === "held") this.heldRequest = { id, data };
    else this.deliverRequest(id, data, wallet);
  }
  /**
   * docs/sdk-v1.md §2.18: a wallet call goes out on a press or on the grant (the answer to a call made by a press,
   * within 10 s), never in the background; one call in flight with the requests.
   */
  walletCall(id, call, gesture) {
    const now = performance.now();
    const pressed = this.policy === "compat" || this.activation.available(gesture, now, this.visible);
    const verdict = this.requests.decideWallet(now, { gesture: pressed, visible: this.visible, canQuery: this.context.canQuery, wallet: this.context.wallet });
    if (requestRefusal(verdict)) return this.refuseRequest(id, verdict, `wallet.${call.method} refused (${verdict}): ${WALLET_REFUSED[verdict] ?? REQUEST_REFUSED[verdict] ?? verdict}`);
    if (verdict === "foreground" && this.policy === "strict") this.activation.accept(gesture, now, this.visible);
    const onWallet = this.opts.onWallet;
    if (!onWallet) {
      this.requests.finish();
      return this.refuseRequest(id, "unsupported", `wallet.${call.method} refused: the client handles no wallet calls (WidgetHostOptions.onWallet)`);
    }
    this.settle(id, new Promise((resolve) => resolve(onWallet(call))), walletFailure);
  }
  answerRequest(id, event) {
    this.toWorker({ type: "bridge", event: { type: "answer", id, ...event } });
  }
  refuseRequest(id, reason, detail) {
    if (this.blockedRequestsReported < 20) {
      this.blockedRequestsReported++;
      this.opts.onDiag?.("request-blocked", detail);
    }
    this.answerRequest(id, { error: (reason === "unsupported" ? null : requestRefusal(reason)) ?? "NOT_ALLOWED", reason });
  }
  /** A request the gate let through, to the client; its answer or failure frees the gate. */
  deliverRequest(id, data, wallet = false) {
    const onRequest = this.opts.onRequest;
    if (!onRequest) {
      this.requests.finish();
      return this.refuseRequest(id, "unsupported", "request refused: the client handles no requests (WidgetHostOptions.onRequest)");
    }
    this.settle(id, new Promise((resolve) => resolve(onRequest(wallet ? { data, wallet: true } : { data }))), requestFailure);
  }
  /** The client's outcome of a request or a wallet call into the widget; it frees the gate, and an answer brings the grant when the call had a press or the grant. */
  settle(id, outcome, failure) {
    outcome.then((a) => {
      const checked = checkRequestAnswer(a);
      if (!checked) {
        this.requests.finish();
        this.opts.onDiag?.("answer-rejected", "the answer's result is not text of at most 1024 bytes (UTF-8, no NUL); the widget gets INVALID_ANSWER");
        return this.answerRequest(id, { error: "INVALID_ANSWER" });
      }
      this.requests.finish(performance.now());
      this.answerRequest(id, { result: checked.result });
    }, (reason) => {
      this.requests.finish();
      this.answerRequest(id, { error: failure(reason) });
    });
  }
  /** The widget stopped (dead or destroyed): a held request never reaches the client. */
  dropHeldRequest() {
    if (!this.heldRequest) return;
    this.heldRequest = null;
    this.requests.finish();
  }
  preload(storage) {
    if (storage === void 0) return {};
    const checked = checkStorageCommit(storage);
    if (checked === null) this.opts.onDiag?.("storage-rejected", `the preload is not { local, session } objects of strings within ${STORAGE_QUOTA_BYTES} bytes each; the widget starts with empty storage`);
    return checked ?? {};
  }
  /**
   * The host knows whether the bubble is on screen; the sandbox does not.
   * Hidden: no animation frames, timers at 1 Hz, `document.hidden` /
   * `visibilitychange` inside the widget. Visible again: deferred timers fire,
   * one frame is requested if the widget asked for one meanwhile.
   */
  setVisible(visible) {
    if (this.visible === visible) return;
    this.visible = visible;
    if (visible && this.requests.show(performance.now()) && this.heldRequest) {
      const { id, data } = this.heldRequest;
      this.heldRequest = null;
      this.deliverRequest(id, data);
    }
    this.toWorker({ type: "visibility", visible });
  }
  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    this.dropHeldRequest();
    this.worker?.terminate();
    this.renderer.destroy();
  }
  toWorker(msg) {
    if (!this.destroyed) this.worker?.postMessage(msg);
  }
  toRenderer(msg) {
    if (!this.destroyed) this.renderer.send(msg);
  }
  die(reason) {
    if (this.dead) return;
    this.dead = true;
    this.opts.onDead?.(reason);
    this.worker?.terminate();
    this.dropHeldRequest();
    this.answerQuery({ error: "dead" });
    this.toRenderer({ type: "frozen", reason: this.opts.stoppedLabel ?? "Widget stopped", fatal: true });
  }
  // ───────────── worker → host ─────────────
  onWorker(msg) {
    switch (msg.type) {
      case "ops": {
        const ops = this.validator.processOps(msg.ops);
        if (this.validator.stopped) return this.die(this.validator.stopped);
        if (ops.length) this.toRenderer({ type: "ops", ops });
        break;
      }
      case "query": {
        const query = this.validator.validateQuery(msg.query);
        if (!query) {
          this.answerQuery({ error: "invalid query" });
          break;
        }
        if (query.q === "matchMedia") query.query = this.validator.rewriteMediaQuery(query.query);
        this.pendingQuery = ++this.qid;
        this.toRenderer({ type: "query", qid: this.pendingQuery, query });
        break;
      }
      case "listen":
        this.toRenderer({ type: "listen", types: this.validator.validateListen(msg.types) });
        break;
      case "pd":
        this.toRenderer({ type: "preventDefault", keys: this.validator.validatePreventDefault(msg.keys) });
        break;
      case "anim": {
        const anims = this.validator.validateAnim(msg.anims);
        const now = finiteNumber(msg.now);
        if (anims.length && now !== void 0) this.toRenderer({ type: "anim", now, anims });
        break;
      }
      case "raf":
        this.toRenderer({ type: "requestFrame" });
        break;
      case "log": {
        const text = String(msg.text);
        this.opts.onLog?.(String(msg.level), text);
        if (msg.level === "error" && text.startsWith("Uncaught ")) this.opts.onError?.(text);
        break;
      }
      case "diag":
        this.opts.onDiag?.(String(msg.kind), String(msg.detail));
        break;
      case "bridge": {
        const method = String(msg.method).slice(0, 64);
        const action = checkBridgeCall(method, msg.args);
        if (!action) {
          if (this.rejectedBridgeReported < 20) {
            this.rejectedBridgeReported++;
            this.opts.onDiag?.("bridge-rejected", `${method}: unknown method or malformed arguments`);
          }
          break;
        }
        if (this.context.preview && !allowedInPreview(method)) {
          if (this.previewBlockedReported < 20) {
            this.previewBlockedReported++;
            this.opts.onDiag?.("preview-blocked", `${method} ignored: a preview (an inline result not sent yet) takes no actions`);
          }
          if (action.kind === "request" || action.kind === "wallet") this.toWorker({ type: "bridge", event: { type: "answer", id: action.id, error: "NOT_ALLOWED", reason: "preview" } });
          break;
        }
        if (action.kind === "setResizeAnchor") {
          this.anchor = action.edge;
          break;
        }
        if (action.kind === "watchPublicData") {
          if (action.on !== this.watching) {
            this.watching = action.on;
            this.opts.onWatchPublicData?.(action.on);
          }
          break;
        }
        if (action.kind === "request") {
          this.request(action.id, action.data, action.wallet === true, msg.gesture);
          break;
        }
        if (action.kind === "wallet") {
          this.walletCall(action.id, action.call, msg.gesture);
          break;
        }
        if (this.policy === "strict" && PRIVILEGED_METHODS.has(method) && !this.activation.accept(msg.gesture, performance.now(), this.visible)) {
          if (this.blockedBridgeReported < 20) {
            this.blockedBridgeReported++;
            this.opts.onDiag?.("activation-blocked", `${method} ignored: it needs a tap on the visible widget and runs in that tap's handler, one call per tap`);
          }
          break;
        }
        if (action.kind === "haptic") {
          const d = this.haptics.decide(performance.now(), this.visible);
          if (d === "report") this.opts.onDiag?.("haptic-limit", this.visible ? "haptics over 5 per burst or 10 per second, or outside a touch after a 1 s series, are dropped" : "haptics of a hidden widget are dropped");
          if (d !== "play") break;
        }
        if (action.kind === "copyText") {
          this.opts.onCopyText?.(action.text);
          break;
        }
        this.opts.onAction?.(action);
        this.opts.onBridge?.(method, msg.args);
        break;
      }
      case "storage": {
        if (this.context.preview) break;
        const commit = checkStorageCommit(msg.commit);
        if (!commit || !commit.local && !commit.session) {
          if (this.rejectedStorageReported < 20) {
            this.rejectedStorageReported++;
            this.opts.onDiag?.("storage-rejected", `a storage commit that is not { local?, session? } objects of strings within ${STORAGE_QUOTA_BYTES} bytes each; the client keeps the previous content`);
          }
          break;
        }
        if (commit.local) this.opts.onStorageCommit?.("local", commit.local);
        if (commit.session) this.opts.onStorageCommit?.("session", commit.session);
        break;
      }
      case "warmed":
        break;
      case "loaded":
        this.validator.markLoaded();
        this.opts.onLoaded?.();
        break;
      case "stats":
        if (typeof msg.stats !== "object" || msg.stats === null) break;
        this.opts.onStats?.({ ...msg.stats, nodes: this.validator.nodeCount });
        break;
      case "dead":
        this.die(msg.reason);
        break;
    }
  }
  /** Write a query answer into the shared buffer and wake the blocked worker. */
  answerQuery(result, binary) {
    if (Atomics.load(this.header, SAB_STATE) !== 1) return;
    let json = encoder.encode(JSON.stringify(result ?? null));
    let bin = binary ? new Uint8Array(binary) : null;
    if (json.length + (bin?.length ?? 0) > this.payload.length) {
      json = encoder.encode('{"error":"result too large"}');
      bin = null;
    }
    this.payload.set(json, 0);
    if (bin) this.payload.set(bin, json.length);
    Atomics.store(this.header, SAB_JSON_LEN, json.length);
    Atomics.store(this.header, SAB_BIN_LEN, bin ? bin.length : 0);
    Atomics.store(this.header, SAB_STATE, 2);
    Atomics.notify(this.header, SAB_STATE);
    this.pendingQuery = 0;
  }
  // ───────────── renderer → host ─────────────
  onRenderer(msg) {
    switch (msg.type) {
      case "event": {
        if (this.context.preview) break;
        if (msg.ev?.type === "pointerdown") this.gestures.pressBegan();
        const gesture = msg.trusted === true ? this.gestures.gestureFor(msg.ev) : 0;
        if (gesture) this.activation.issue(gesture, performance.now());
        this.toWorker(gesture ? { type: "event", ev: msg.ev, gesture } : { type: "event", ev: msg.ev });
        break;
      }
      case "result":
        if (msg.qid === this.pendingQuery) this.answerQuery(msg.result, msg.binary);
        break;
      case "size": {
        const h = finiteNumber(msg.height), iw = finiteNumber(msg.innerWidth), ih = finiteNumber(msg.innerHeight), dpr = finiteNumber(msg.dpr);
        if (h === void 0 || iw === void 0 || ih === void 0 || dpr === void 0) break;
        const height = Math.min(Math.max(h, MIN_HEIGHT), MAX_HEIGHT);
        this.element.style.height = height + "px";
        this.opts.onResize?.(height, this.anchor);
        const vp = { innerWidth: iw, innerHeight: ih, dpr };
        if (JSON.stringify(vp) !== JSON.stringify(this.viewport)) {
          this.viewport = vp;
          this.toWorker({ type: "viewport", viewport: vp });
        }
        break;
      }
      case "resize":
        this.toWorker({ type: "resize", entries: msg.entries });
        break;
      case "frame": {
        const time = finiteNumber(msg.time);
        if (time !== void 0) this.toWorker({ type: "frame", time });
        break;
      }
      case "gesture":
        this.haptics.press(performance.now());
        this.gestures.pressBegan();
        if (this.context.preview) break;
        this.opts.onGestureClaim?.({ x: msg.x === true, y: false, hold: msg.hold === true });
        break;
      case "release":
        this.haptics.release(performance.now());
        break;
      case "bubble": {
        if (this.context.preview) break;
        const x = finiteNumber(msg.x), y = finiteNumber(msg.y);
        if (!BUBBLE_ACTIONS.has(msg.action) || !GESTURES.has(msg.gesture) || x === void 0 || y === void 0) break;
        this.opts.onBubbleGesture?.({ action: msg.action, gesture: msg.gesture, x, y, edge: msg.edge === true });
        break;
      }
      case "media":
        this.toWorker({ type: "theme", theme: this.theme, themeParams: this.widgetTheme.params });
        break;
      case "limit": {
        const limit = checkPaintLimit(msg.code, msg.count);
        if (!limit) {
          this.opts.onDiag?.("renderer-violation", "a limit report with an unknown code or no count");
          break;
        }
        if (this.policy === "compat" || this.dead) break;
        const reason = paintLimitMessage(limit.code, limit.count);
        this.opts.onDiag?.(limit.code, reason);
        this.die(reason);
        break;
      }
      case "violation":
        this.opts.onDiag?.("renderer-violation", String(msg.detail).slice(0, 4e3));
        break;
    }
  }
}
export {
  WidgetHost
};
