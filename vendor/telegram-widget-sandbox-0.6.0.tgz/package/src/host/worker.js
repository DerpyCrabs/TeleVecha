import { newQuickJSWASMModuleFromVariant, newVariant } from "quickjs-emscripten-core";
import baseVariant from "@telegram/widget-sandbox-quickjs";
import wasmUrl from "@telegram/widget-sandbox-quickjs/wasm?url";
import { CpuBudget, opsCostMs, queryLimitHit as queryLimitOf, queryLimitReason } from "./cpu-budget";
import { LIMIT_DEFAULTS, MAX_ANIM_BATCH_BYTES, MAX_TIMER_DELAY_MS, SAB_BIN_LEN, SAB_HEADER, SAB_JSON_LEN, SAB_STATE, WASM_INITIAL_PAGES, WASM_PAGE_BYTES } from "../shared/protocol";
import { STORAGE_QUOTA_BYTES } from "../shared/sdk-policy";
import { formatIntl } from "../shared/intl";
const post = (msg) => self.postMessage(msg);
const QUERY_TIMEOUT_MS = 3e3;
const MAX_LOG = 4e3;
const MAX_STORAGE_COMMIT_CHARS = 2 * 12 * STORAGE_QUOTA_BYTES + 64;
let rt;
let vm;
let config;
const WEB_FEATURES = /* @__PURE__ */ new Set(["webAnimations", "noInPlaceText", "noAttrFast", "noCanvasRect"]);
const withWebFeatures = (c) => ({ ...c, features: (c.features ?? []).filter((f) => WEB_FEATURES.has(f)) });
let warmedMemoryLimitBytes = 0;
let header;
let payload;
let dead = false;
let interrupted = false;
let deadline = 0;
let taskQueryMs = 0;
let taskQueries = 0;
let taskOpsCostMs = 0;
let queryLimitHit = null;
let currentSliceMs = 0;
let currentKind = "boot";
let budget;
let mainBudget;
const newMainBudget = (c) => new CpuBudget({ cpuLimitMs: c.cpuLimitMs, cpuQuotaMs: c.mainThreadQuotaMs ?? LIMIT_DEFAULTS.mainThreadQuotaMs, cpuQuotaWindowMs: c.cpuQuotaWindowMs, cpuKillAfterMs: 0 });
let excludeMs = 0;
let lastThrottleDiag = -Infinity;
const throttledSinceDiag = {};
let lastBinary = null;
let twDispatch;
let inTask = false;
const queue = [];
let visible = true;
let frameWanted = false;
const deferred = [];
let wakeTimer = null;
let wakeAt = Infinity;
let hiddenTickAt = 0;
function defer(kind, arg) {
  if (kind === "frame") {
    const f = deferred.find((d) => d.kind === "frame");
    if (f) {
      f.arg = arg;
      return;
    }
  } else if (kind === "timer" && deferred.some((d) => d.kind === "timer" && d.arg === arg)) {
    return;
  }
  deferred.push({ kind, arg });
}
function scheduleWake(at) {
  if (wakeTimer && at >= wakeAt) return;
  if (wakeTimer) clearTimeout(wakeTimer);
  wakeAt = at;
  wakeTimer = setTimeout(wake, Math.max(0, at - performance.now()));
}
function wake() {
  wakeTimer = null;
  wakeAt = Infinity;
  hiddenTickAt = 0;
  const items = deferred.splice(0);
  for (let i = 0; i < items.length; i++) {
    if (dead) return;
    if (!dispatch(items[i].kind, items[i].arg)) {
      deferred.unshift(...items.slice(i));
      return;
    }
  }
}
function onTimerFired(id) {
  timers.delete(id);
  if (!visible) {
    defer("timer", id);
    if (!hiddenTickAt) hiddenTickAt = performance.now() + 1e3;
    scheduleWake(hiddenTickAt);
    return;
  }
  dispatch("timer", id);
}
function setVisible(v) {
  if (visible === v) return;
  visible = v;
  dispatch("visibility", { visible: v });
  if (visible) {
    if (frameWanted) {
      frameWanted = false;
      post({ type: "raf" });
    }
    if (deferred.length) wake();
  }
}
const stats = { jsMs: 0, tasks: 0, memoryBytes: 0, ops: 0, queries: 0, queryMs: 0, queryCacheHits: 0, missedMutations: 0, throttledTasks: 0, cpuWindowMs: 0 };
let lastStatsPost = 0;
let lastMemCheck = 0;
const timers = /* @__PURE__ */ new Map();
let timerLimitReported = false;
const decoder = new TextDecoder();
function syncQuery(queryJson) {
  let query;
  try {
    query = JSON.parse(queryJson);
  } catch {
    return '{"error":"bad query"}';
  }
  if (queryLimitHit) return '{"error":"query budget exceeded"}';
  const t0 = performance.now();
  Atomics.store(header, SAB_STATE, 1);
  post({ type: "query", query });
  const res = Atomics.wait(header, SAB_STATE, 1, QUERY_TIMEOUT_MS);
  const dt = performance.now() - t0;
  deadline += dt;
  stats.queries++;
  stats.queryMs += dt;
  taskQueryMs += dt;
  taskQueries++;
  queryLimitHit = queryLimitOf(taskQueries, taskQueryMs);
  if (queryLimitHit) {
    deadline = -Infinity;
  }
  if (res === "timed-out") {
    Atomics.store(header, SAB_STATE, 0);
    return '{"error":"timeout"}';
  }
  const jsonLen = Atomics.load(header, SAB_JSON_LEN);
  const binLen = Atomics.load(header, SAB_BIN_LEN);
  const json = decoder.decode(payload.slice(0, jsonLen));
  lastBinary = binLen > 0 ? payload.slice(jsonLen, jsonLen + binLen) : null;
  Atomics.store(header, SAB_STATE, 0);
  return json;
}
function hostCall(kind, arg) {
  switch (kind) {
    case "ops": {
      let ops;
      try {
        ops = JSON.parse(arg);
      } catch {
        return;
      }
      if (Array.isArray(ops)) {
        stats.ops += ops.length;
        let commands = 0;
        for (const op of ops) if (op && op.op === "canvas" && Array.isArray(op.cmds)) commands += op.cmds.length;
        taskOpsCostMs += opsCostMs(ops.length, commands);
      }
      post({ type: "ops", ops });
      return;
    }
    case "query":
      return syncQuery(arg);
    case "now":
      return coarseNowMs(performance.now());
    case "timer": {
      const [id, delay] = JSON.parse(arg);
      if (typeof id !== "number") return;
      const replaced = timers.get(id);
      if (replaced !== void 0) clearTimeout(replaced);
      else if (timers.size >= config.maxTimers) {
        if (!timerLimitReported) {
          timerLimitReported = true;
          post({ type: "diag", kind: "timer-limit-enforced", detail: `glue refused a timer beyond maxTimers=${config.maxTimers}; the shim did not stop it` });
        }
        return;
      }
      let ms = Math.min(Math.max(Number(delay) || 0, 0), MAX_TIMER_DELAY_MS);
      if (!visible) ms = Math.max(ms, 1e3 + ms / 10);
      timers.set(id, setTimeout(() => onTimerFired(id), ms));
      return;
    }
    case "clearTimer": {
      const id = Number(arg);
      const t = timers.get(id);
      if (t !== void 0) {
        clearTimeout(t);
        timers.delete(id);
      }
      return;
    }
    case "raf":
      if (!visible) {
        frameWanted = true;
        return;
      }
      post({ type: "raf" });
      return;
    case "log": {
      const i = arg.indexOf(":");
      post({ type: "log", level: arg.slice(0, i), text: arg.slice(i + 1, i + 1 + MAX_LOG) });
      return;
    }
    case "diag": {
      const i = arg.indexOf(":");
      post({ type: "diag", kind: arg.slice(0, i).slice(0, 64), detail: arg.slice(i + 1, i + 1 + MAX_LOG) });
      return;
    }
    case "listen":
      try {
        post({ type: "listen", types: JSON.parse(arg) });
      } catch {
      }
      return;
    case "pd":
      try {
        post({ type: "pd", keys: JSON.parse(arg) });
      } catch {
      }
      return;
    case "anim":
      if (arg.length > MAX_ANIM_BATCH_BYTES || !config.features?.includes("webAnimations")) return;
      try {
        post({ type: "anim", anims: JSON.parse(arg), now: performance.now() });
      } catch {
      }
      return;
    case "bridge":
      try {
        const [method, args] = JSON.parse(arg);
        post(activeGesture ? { type: "bridge", method: String(method).slice(0, 64), args, gesture: activeGesture } : { type: "bridge", method: String(method).slice(0, 64), args });
      } catch {
      }
      return;
    case "storage":
      if (arg.length > MAX_STORAGE_COMMIT_CHARS) {
        post({ type: "diag", kind: "storage-rejected", detail: `commit of ${arg.length} characters` });
        return;
      }
      try {
        post({ type: "storage", commit: JSON.parse(arg) });
      } catch {
      }
      return;
    case "intl":
      try {
        return formatIntl(JSON.parse(arg));
      } catch {
        return "";
      }
    case "random": {
      const n = Math.min(Math.max(Number(arg) | 0, 0), 65536);
      return JSON.stringify(Array.from(crypto.getRandomValues(new Uint8Array(n))));
    }
    case "stat": {
      try {
        const s = JSON.parse(arg);
        stats.queryCacheHits = Number(s.cacheHits) || 0;
        stats.missedMutations = Number(s.missed) || 0;
      } catch {
      }
      return;
    }
  }
}
function kill(reason) {
  if (dead) return;
  dead = true;
  for (const t of timers.values()) clearTimeout(t);
  timers.clear();
  deferred.length = 0;
  if (wakeTimer) {
    clearTimeout(wakeTimer);
    wakeTimer = null;
  }
  post({ type: "dead", reason });
}
function describeError(err) {
  let text;
  try {
    const e = vm.dump(err);
    text = e && typeof e === "object" ? `${e.name ?? "Error"}: ${e.message ?? ""}${e.stack ? "\n" + e.stack : ""}` : String(e);
  } catch {
    text = "unknown error";
  }
  err.dispose();
  return text;
}
function handleError(err, where) {
  const text = describeError(err);
  if (interrupted && queryLimitHit) {
    return kill(`${queryLimitReason(queryLimitHit, currentKind)} (${where})`);
  }
  if (interrupted) {
    return kill(`CPU limit exceeded: more than ${currentSliceMs.toFixed(0)} ms of continuous execution (${where})`);
  }
  if (/out of memory/i.test(text)) return kill(`Memory limit exceeded (${config.memoryLimitBytes >> 20} MB)`);
  post({ type: "log", level: "error", text: `Uncaught ${text}`.slice(0, MAX_LOG) });
}
function drainJobs() {
  for (let i = 0; i < 100 && !dead; i++) {
    const r = rt.executePendingJobs();
    if (r.error) {
      handleError(r.error, "promise job");
      continue;
    }
    if (r.value === 0) break;
  }
}
function callTw(kind, arg) {
  const k = vm.newString(kind);
  const a = vm.newString(arg);
  const r = vm.callFunction(twDispatch, vm.undefined, k, a);
  k.dispose();
  a.dispose();
  if (r.error) {
    handleError(r.error, kind);
    return null;
  }
  const out = vm.typeof(r.value) === "string" ? vm.getString(r.value) : null;
  r.value.dispose();
  return out;
}
function settle() {
  for (let i = 0; i < 20 && !dead; i++) {
    drainJobs();
    if (dead) return;
    const more = callTw("endTick", "");
    if (more !== "1" && !rt.hasPendingJob()) break;
  }
}
function evalScript(code, filename, type) {
  const r = vm.evalCode(code, filename, { type });
  if (r.error) {
    handleError(r.error, filename);
    return false;
  }
  r.value.dispose();
  return true;
}
function pumpScripts() {
  for (let i = 0; i < 1e3 && !dead; i++) {
    const next = callTw("nextScript", "");
    if (!next) break;
    const s = JSON.parse(next);
    let ok = true;
    resetDeadline();
    if (s.src !== void 0) {
      ok = false;
      post({ type: "diag", kind: "script-skipped", detail: `external script not available: ${String(s.src).slice(0, 200)}` });
    } else if (s.code !== void 0) {
      evalScript(s.code, `inline-script-${s.id}.js`, s.type);
    }
    if (dead) return;
    settle();
    callTw("scriptDone", JSON.stringify([s.id, ok]));
    settle();
  }
}
function resetDeadline() {
  interrupted = false;
  deadline = performance.now() + currentSliceMs;
}
function task(kind, sliceMs, fn) {
  if (dead) return;
  inTask = true;
  currentKind = kind;
  currentSliceMs = sliceMs;
  excludeMs = 0;
  taskQueryMs = 0;
  taskQueries = 0;
  taskOpsCostMs = 0;
  queryLimitHit = null;
  const t0 = performance.now();
  const q0 = stats.queryMs;
  resetDeadline();
  try {
    fn();
    if (!dead) settle();
    if (!dead) pumpScripts();
    if (!dead && queryLimitHit) kill(queryLimitReason(queryLimitHit, kind));
  } catch (e) {
    kill("sandbox glue error: " + e.message);
  }
  inTask = false;
  stats.tasks++;
  const now = performance.now();
  const cpuMs = now - t0 - (stats.queryMs - q0) - excludeMs;
  stats.jsMs += cpuMs;
  budget.record(kind, cpuMs, now);
  mainBudget.record(kind, taskQueryMs + taskOpsCostMs, now);
  stats.cpuWindowMs = budget.used(now);
  if (now - lastMemCheck > 1e3 && !dead) {
    lastMemCheck = now;
    try {
      const h = rt.computeMemoryUsage();
      stats.memoryBytes = vm.dump(h).memory_used_size ?? 0;
      h.dispose();
    } catch {
    }
  }
  if (now - lastStatsPost > 200) {
    lastStatsPost = now;
    post({ type: "stats", stats: { ...stats } });
  }
}
function dispatch(kind, arg) {
  if (dead) return true;
  const now = performance.now();
  const js = budget.decide(kind, now);
  const main = mainBudget.decide(kind, now);
  if (!js.run || !main.run) {
    if (budget.shouldKill(now)) {
      kill(`CPU quota: throttled for ${(budget.throttledFor(now) / 1e3).toFixed(1)} s (${config.cpuQuotaMs} ms per ${config.cpuQuotaWindowMs} ms, cpuKillAfterMs=${config.cpuKillAfterMs})`);
      return true;
    }
    defer(kind, arg);
    stats.throttledTasks++;
    throttledSinceDiag[kind] = (throttledSinceDiag[kind] ?? 0) + 1;
    if (now - lastThrottleDiag >= 1e3) {
      lastThrottleDiag = now;
      const parts = Object.entries(throttledSinceDiag).map(([k, n]) => `${n} ${k}${n === 1 ? "" : "s"}`);
      for (const k of Object.keys(throttledSinceDiag)) delete throttledSinceDiag[k];
      const window = js.run ? `${mainBudget.used(now).toFixed(0)} ms of the ${config.mainThreadQuotaMs ?? LIMIT_DEFAULTS.mainThreadQuotaMs} ms per ${config.cpuQuotaWindowMs} ms main-thread budget used by layout queries and ops` : `${budget.used(now).toFixed(0)} ms of the ${config.cpuQuotaMs} ms per ${config.cpuQuotaWindowMs} ms budget used`;
      post({ type: "diag", kind: "cpu-throttled", detail: `deferred ${parts.join(", ")}: ${window}` });
    }
    scheduleWake(Math.max(js.run ? 0 : js.retryAt, main.run ? 0 : main.retryAt));
    return false;
  }
  task(kind, js.sliceMs, () => callTw(kind, JSON.stringify(arg)));
  return true;
}
async function warm(msg) {
  config = withWebFeatures(msg.config);
  visible = config.visible !== false;
  budget = new CpuBudget(config);
  mainBudget = newMainBudget(config);
  header = new Int32Array(msg.sab, 0, SAB_HEADER / 4);
  payload = new Uint8Array(msg.sab, SAB_HEADER);
  warmedMemoryLimitBytes = config.memoryLimitBytes;
  const wasmMemory = new WebAssembly.Memory({ initial: WASM_INITIAL_PAGES, maximum: WASM_INITIAL_PAGES + Math.ceil(config.memoryLimitBytes / WASM_PAGE_BYTES) });
  const QuickJS = await newQuickJSWASMModuleFromVariant(newVariant(baseVariant, { wasmLocation: wasmUrl, wasmMemory }));
  rt = QuickJS.newRuntime();
  rt.setMemoryLimit(config.memoryLimitBytes);
  rt.setMaxStackSize(1024 * 1024);
  rt.setInterruptHandler(() => {
    if (performance.now() > deadline) {
      interrupted = true;
      return true;
    }
    return false;
  });
  vm = rt.newContext();
  const hostFn = vm.newFunction("__host", (kindH, argH) => {
    const r = hostCall(vm.getString(kindH), argH ? vm.getString(argH) : "");
    if (typeof r === "string") return vm.newString(r);
    if (typeof r === "number") return vm.newNumber(r);
    return vm.undefined;
  });
  vm.setProp(vm.global, "__host", hostFn);
  hostFn.dispose();
  const binFn = vm.newFunction("__hostBinary", () => {
    if (!lastBinary) return vm.null;
    const copy = lastBinary.buffer.slice(lastBinary.byteOffset, lastBinary.byteOffset + lastBinary.byteLength);
    lastBinary = null;
    return vm.newArrayBuffer(copy);
  });
  vm.setProp(vm.global, "__hostBinary", binFn);
  binFn.dispose();
  let bootMs = 0;
  task("boot", config.cpuLimitMs, () => {
    const t0 = performance.now();
    deadline = performance.now() + Math.max(config.cpuLimitMs, 5e3);
    const loaded = evalScript(msg.sandboxBundle, "sandbox-bundle.js", "global");
    excludeMs = performance.now() - t0;
    if (dead) return;
    if (!loaded) return kill("sandbox bundle failed to load");
    const fn = vm.getProp(vm.global, "__twDispatch");
    if (vm.typeof(fn) !== "function") {
      fn.dispose();
      return kill("sandbox bundle failed to initialise");
    }
    twDispatch = fn;
    if (!evalScript(HIDE_HOST_GLOBALS, "hide-host.js", "global")) return kill("sandbox bundle failed to load");
    bootMs = performance.now() - t0;
    post({ type: "diag", kind: "boot", detail: `sandbox bundle eval ${bootMs.toFixed(0)} ms; wasm memory ${(wasmMemory.buffer.byteLength / 1048576).toFixed(1)} MB, cap ${((WASM_INITIAL_PAGES * WASM_PAGE_BYTES + config.memoryLimitBytes) / 1048576).toFixed(0)} MB${QuickJS.getWasmMemory() === wasmMemory ? "" : " (module ignored the provided Memory)"}` });
  });
  if (!dead) post({ type: "warmed", bootMs });
}
function start(msg) {
  if (dead) return;
  config = withWebFeatures({ ...msg.config, memoryLimitBytes: Math.min(msg.config.memoryLimitBytes, warmedMemoryLimitBytes) });
  visible = config.visible !== false;
  budget = new CpuBudget(config);
  mainBudget = newMainBudget(config);
  rt.setMemoryLimit(config.memoryLimitBytes);
  task("boot", config.cpuLimitMs, () => callTw("boot", JSON.stringify({ html: msg.html, config })));
  task("boot", config.cpuLimitMs, () => callTw("loaded", ""));
  if (!dead) post({ type: "loaded" });
  post({ type: "stats", stats: { ...stats } });
  ready = true;
  for (const m of queue.splice(0)) handle(m);
}
const HIDE_HOST_GLOBALS = "(function(g){for(const n of ['__host','__hostBinary','__hostCanvas','__hostOps','__twDispatch'])if(!delete g[n])throw new Error(n);})(globalThis);";
const coarseNowMs = (ms) => Math.floor(ms / 0.1) * 0.1;
let ready = false;
let activeGesture = 0;
function handle(msg) {
  if (dead) return;
  switch (msg.type) {
    case "event":
      activeGesture = typeof msg.gesture === "number" ? msg.gesture : 0;
      try {
        dispatch("event", msg.ev);
      } finally {
        activeGesture = 0;
      }
      return;
    case "frame":
      if (!visible) {
        frameWanted = true;
        return;
      }
      dispatch("frame", coarseNowMs(msg.time));
      return;
    case "viewport":
      dispatch("viewport", msg.viewport);
      return;
    case "resize":
      dispatch("resize", msg.entries);
      return;
    case "theme":
      dispatch("theme", { theme: msg.theme, themeParams: msg.themeParams });
      return;
    case "safeArea":
      dispatch("safeArea", msg.inset);
      return;
    case "visibility":
      setVisible(!!msg.visible);
      return;
    // The bot's data or a request's answer, checked by WidgetHost; deferred under the CPU quota like a theme change, in order.
    case "bridge":
      dispatch("bridge", msg.event);
      return;
  }
}
let warming = null;
const fail = (err) => kill("failed to start sandbox: " + err.message);
self.onmessage = (e) => {
  const msg = e.data;
  if (msg.type === "init") {
    warming = warm(msg);
    warming.then(() => start(msg)).catch(fail);
  } else if (msg.type === "warm") {
    warming = warm(msg);
    warming.catch(fail);
  } else if (msg.type === "start") {
    (warming ?? Promise.reject(new Error("start before warm"))).then(() => start(msg)).catch(fail);
  } else if (!ready || inTask) {
    queue.push(msg);
  } else {
    handle(msg);
  }
};
