import { clearStylesheetCache, sanitizeCssValue, sanitizeStyleAttribute, sanitizeStyleProperty, sanitizeStylesheet } from "./css-sanitizer";
import { Validator, validatorTables } from "./validator";
import { MAX_ANIM_BATCH_BYTES } from "../shared/protocol";
let validator = null;
const diag = (kind, detail) => {
  if (typeof __diag === "function") __diag(kind, detail);
};
const v = () => {
  if (!validator) throw new Error("validator not created");
  return validator;
};
globalThis.__twValidator = {
  create(theme) {
    clearStylesheetCache();
    validator = new Validator(diag, { colorScheme: theme === "dark" ? "dark" : "light" });
  },
  setNativeScrolling(enabled) {
    v().cssEnv.nativeScrolling = enabled === "1";
    clearStylesheetCache();
    return "";
  },
  processOps(json) {
    return JSON.stringify(v().processOps(JSON.parse(json)));
  },
  validateQuery(json) {
    const q = v().validateQuery(JSON.parse(json));
    return q ? JSON.stringify(q) : "";
  },
  validateListen(json) {
    return JSON.stringify(v().validateListen(JSON.parse(json)));
  },
  validateAnim(json) {
    return json.length > MAX_ANIM_BATCH_BYTES ? "[]" : JSON.stringify(v().validateAnim(JSON.parse(json)));
  },
  validatePreventDefault(json) {
    return JSON.stringify(v().validatePreventDefault(JSON.parse(json)));
  },
  setTheme(theme) {
    return JSON.stringify(v().setTheme(theme === "dark" ? "dark" : "light"));
  },
  rewriteMediaQuery(query) {
    return v().rewriteMediaQuery(String(query));
  },
  nodeCount() {
    return v().nodeCount;
  },
  markLoaded() {
    v().markLoaded();
  },
  isCanvas(id) {
    return v().isCanvas(Number(id));
  },
  stopped() {
    return v().stopped ?? "";
  },
  // For a native node model (Swift NativeValidator): the rules as data and the
  // stateless sanitizers; with native('1') the queries ask the host's model
  // through __twNode(id) → tag or ''.
  /** Sanitizes the stylesheets of a widget that is still booting (results and diagnostics are cached, nothing is reported now). */
  warmStylesheets(json) {
    const texts = JSON.parse(json);
    if (Array.isArray(texts)) {
      for (const t of texts.slice(0, 16)) if (typeof t === "string" && t.length < 262144) sanitizeStylesheet(t, () => {
      }, v().cssEnv);
    }
    return "";
  },
  setPolicy(policy) {
    v().setPolicy(policy === "compat" ? "compat" : "strict");
    return "";
  },
  tables() {
    return JSON.stringify(validatorTables(v().policy));
  },
  native(on) {
    v().setNodeLookup(on === "1" && typeof __twNode === "function" ? (id) => __twNode(id) || null : null);
    return "";
  },
  cssProp(name, value) {
    const r = sanitizeStyleProperty(String(name), String(value), v().diagnostics, v().cssEnv);
    return r ? "+" + r.value : "-";
  },
  cssAttr(value) {
    return sanitizeStyleAttribute(String(value), v().diagnostics, v().cssEnv);
  },
  cssValue(value, where) {
    const r = sanitizeCssValue(String(value), v().diagnostics, String(where), v().cssEnv);
    return r === null ? "-" : "+" + r;
  },
  cssSheet(text) {
    return sanitizeStylesheet(String(text), v().diagnostics, v().cssEnv);
  },
  canvasCmds(json) {
    return JSON.stringify(v().canvasCommands(JSON.parse(json)));
  }
};
