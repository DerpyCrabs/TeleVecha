const BUCKETS = 10;
const DEFERRABLE = /* @__PURE__ */ new Set(["timer", "frame", "viewport", "resize", "theme", "bridge"]);
const QUERY_LIMIT = 128;
const QUERY_BUDGET_MS = 1e3;
function queryLimitHit(queries, queryMs) {
  if (queries > QUERY_LIMIT) return "count";
  if (queryMs > QUERY_BUDGET_MS) return "time";
  return null;
}
function queryLimitReason(hit, kind) {
  return hit === "count" ? `Layout query limit exceeded: more than ${QUERY_LIMIT} layout queries in one ${kind} task` : `Layout query limit exceeded: host queries blocked the renderer for more than ${QUERY_BUDGET_MS} ms in one ${kind} task`;
}
const OP_COST_MS = 0.025;
const CANVAS_COMMAND_COST_MS = 2e-3;
function opsCostMs(ops, canvasCommands) {
  return ops * OP_COST_MS + canvasCommands * CANVAS_COMMAND_COST_MS;
}
class CpuBudget {
  constructor(cfg) {
    this.cfg = cfg;
    this.bucketMs = Math.max(1, cfg.cpuQuotaWindowMs / BUCKETS);
    for (let i = 0; i < BUCKETS; i++) this.buckets.push({ start: -Infinity, ms: 0 });
  }
  cfg;
  bucketMs;
  buckets = [];
  /** Time spent past the quota, not in the window yet: at most one quota. */
  debtMs = 0;
  /** The last bucket the debt was settled at. */
  settled = -Infinity;
  throttledSince = -1;
  lastThrottleAt = -1;
  /** Bucket `b`'s slot, emptied when it still holds an older bucket. */
  slot(b) {
    const slot = this.buckets[(b % BUCKETS + BUCKETS) % BUCKETS];
    const start = b * this.bucketMs;
    if (slot.start !== start) {
      slot.start = start;
      slot.ms = 0;
    }
    return slot;
  }
  /** Time in the window that ends with bucket `b` (the ten bucket slots cover exactly one window). */
  windowAt(b) {
    const oldest = (b - BUCKETS + 1) * this.bucketMs;
    let sum = 0;
    for (const s of this.buckets) if (s.start >= oldest) sum += s.ms;
    return sum;
  }
  /** Moves the debt into the window, bucket by bucket since the last call, as the buckets that filled it leave. */
  settle(now) {
    const cur = Math.floor(now / this.bucketMs);
    if (this.debtMs > 0) {
      const last = Math.min(cur, this.settled + 2 * BUCKETS);
      for (let b = this.settled + 1; b <= last && this.debtMs > 0; b++) {
        const pay = Math.min(this.debtMs, this.cfg.cpuQuotaMs - this.windowAt(b));
        if (pay > 0) {
          this.slot(b).ms += pay;
          this.debtMs -= pay;
        }
      }
      if (last < cur) this.debtMs = 0;
    }
    if (cur > this.settled) this.settled = cur;
  }
  /** Account `cpuMs` of widget JS time for a task that ended at `now`: into the window up to the quota, the rest is the debt. */
  record(_kind, cpuMs, now) {
    this.settle(now);
    const b = Math.floor(now / this.bucketMs);
    const slot = this.slot(b);
    if (!(cpuMs > 0)) return;
    const into = Math.min(cpuMs, Math.max(0, this.cfg.cpuQuotaMs - this.windowAt(b) - this.debtMs));
    slot.ms += into;
    this.debtMs = Math.min(this.cfg.cpuQuotaMs, this.debtMs + cpuMs - into);
  }
  /** JS time charged now: the window ending now plus the debt. */
  used(now) {
    this.settle(now);
    return this.windowAt(Math.floor(now / this.bucketMs)) + this.debtMs;
  }
  /** Before a task: run it with the whole slice for the interrupt handler, or retry at `retryAt`. */
  decide(kind, now) {
    const remaining = this.cfg.cpuQuotaMs - this.used(now);
    if (DEFERRABLE.has(kind) && remaining <= 0) {
      if (this.throttledSince < 0 || now - this.lastThrottleAt > this.cfg.cpuQuotaWindowMs) this.throttledSince = now;
      this.lastThrottleAt = now;
      const oldestBusy = (Math.floor(now / this.bucketMs) - BUCKETS + 1) * this.bucketMs;
      let oldest = Infinity;
      for (const s of this.buckets) if (s.ms > 0 && s.start >= oldestBusy && s.start < oldest) oldest = s.start;
      let retryAt = oldest === Infinity ? now + this.bucketMs : oldest + this.cfg.cpuQuotaWindowMs;
      if (retryAt <= now) retryAt = now + this.bucketMs;
      return { run: false, retryAt };
    }
    return { run: true, sliceMs: this.cfg.cpuLimitMs };
  }
  /** Length of the current uninterrupted throttling stretch (0 when not throttled). */
  throttledFor(now) {
    if (this.throttledSince < 0 || now - this.lastThrottleAt > this.cfg.cpuQuotaWindowMs) return 0;
    return now - this.throttledSince;
  }
  /** `cpuKillAfterMs` (0 = never): kill the runtime once throttling has lasted this long. */
  shouldKill(now) {
    return this.cfg.cpuKillAfterMs > 0 && this.throttledFor(now) >= this.cfg.cpuKillAfterMs;
  }
}
export {
  BUCKETS,
  CANVAS_COMMAND_COST_MS,
  CpuBudget,
  DEFERRABLE,
  OP_COST_MS,
  QUERY_BUDGET_MS,
  QUERY_LIMIT,
  opsCostMs,
  queryLimitHit,
  queryLimitReason
};
