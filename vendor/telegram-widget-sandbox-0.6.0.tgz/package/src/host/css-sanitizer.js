import * as csstree from "css-tree";
import { checkUrl } from "./url-policy";
import { PROFILE_TABLES } from "../shared/profile-tables";
import { SAFE_AREA_ENV_VARIABLES } from "../shared/sdk-policy";
import {
  cssFunctionInProfile,
  cssPropertyInProfile,
  cssPseudoClassInProfile,
  cssPseudoElementInProfile,
  cssUnitInProfile,
  fontShorthandFamilyStart,
  isGenericFont,
  supportsCondition
} from "../shared/css-supports";
const DEFAULT_ENV = { colorScheme: "light" };
const VISIBLE_TEXT_ATTRS = /* @__PURE__ */ new Set(["value", "placeholder", "alt", "label", "title"]);
function isTextAttr(name) {
  return VISIBLE_TEXT_ATTRS.has(name) || name.startsWith("data-") || name.startsWith("aria-");
}
const TEXT_ATTRS = [...VISIBLE_TEXT_ATTRS];
const TEXT_ATTR_PREFIXES = ["data-", "aria-"];
function cssStringText(css) {
  let out = "";
  for (let i = 0; i < css.length; ) {
    const c = css.charCodeAt(i);
    if (c === 92) {
      i += 2;
      continue;
    }
    if (c !== 34 && c !== 39) {
      i++;
      continue;
    }
    let j = i + 1;
    while (j < css.length && css.charCodeAt(j) !== c) {
      if (css.charCodeAt(j) === 92 && j + 1 < css.length) j++;
      out += css[j];
      j++;
    }
    i = j + 1;
  }
  return out;
}
const ALWAYS = "(min-width: 0px)";
const NEVER = "(min-width: 99999px)";
const PROFILE_CSS = PROFILE_TABLES.css;
const ALLOWED_ATRULES = new Set(PROFILE_CSS.atRules);
const SECURITY_ATRULES = /* @__PURE__ */ new Set(["import", "namespace", "font-face"]);
const MEDIA_TYPES = new Set(PROFILE_CSS.mediaTypes);
const MEDIA_FEATURES = new Set(PROFILE_CSS.mediaFeatures);
const VALUE_SETS = PROFILE_CSS.values;
const REWRITES = PROFILE_CSS.rewrite;
const FILTER_FUNCTIONS = new Set(PROFILE_CSS.filterFunctions);
const TRANSFORM_3D = new Set(PROFILE_CSS.transform3d);
const FONT_FALLBACK = PROFILE_CSS.fonts.fallback;
const FONT_ALIASES = PROFILE_CSS.fonts.aliases;
const PSEUDO_REWRITE = PROFILE_CSS.pseudoRewrite;
const GLOBAL_KEYWORDS = /* @__PURE__ */ new Set(["inherit", "initial", "unset", "revert", "revert-layer"]);
const FONT_SIZE_KEYWORDS = /* @__PURE__ */ new Set(["xx-small", "x-small", "small", "medium", "large", "x-large", "xx-large", "xxx-large", "smaller", "larger"]);
const SUBSTITUTED = (n) => n.type === "Function" && SUBSTITUTION_NAMES.has(n.name.toLowerCase());
const SUBSTITUTION_NAMES = /* @__PURE__ */ new Set(["var", "env", "attr"]);
const URL_FUNCTIONS = /* @__PURE__ */ new Set(["image-set", "-webkit-image-set", "image", "src", "cross-fade", "-webkit-cross-fade"]);
const SUBSTITUTION_FUNCTIONS = /* @__PURE__ */ new Set(["var", "env", "attr"]);
const FORBIDDEN_PROPERTIES = /* @__PURE__ */ new Set(["behavior", "-moz-binding"]);
const SAFE_RAW_PRELUDE = /^[\w\s\-.,:()<>=%/*+!#]*$/;
const PARSE_OPTS = { parseCustomProperty: true, positions: false };
function stripUnicodeControls(s) {
  return s.replace(/\u0000/g, "\uFFFD");
}
function valueIsSafe(value, urlKind, diag, where, env) {
  if (value.type === "Raw") {
    if (value.value.trim() === "") return true;
    diag("css-dropped", `${where}: unparsable value`);
    return false;
  }
  let ok = true;
  const fnStack = [];
  const visitor = {
    enter(node, item, list) {
      if (!ok) return;
      if (node.type === "Function" && node.name.toLowerCase() === "light-dark" && list) {
        const parts = [[]];
        node.children.forEach((c) => c.type === "Operator" && c.value === "," ? parts.push([]) : parts[parts.length - 1].push(c));
        const chosen = parts[env.colorScheme === "dark" ? 1 : 0] ?? parts[0];
        const repl = new csstree.List();
        for (const c of chosen) repl.appendData(c);
        csstree.walk({ type: "Value", children: repl }, visitor);
        list.replace(item, repl);
        return csstree.walk.skip;
      }
      if (node.type === "Function" && node.name.toLowerCase() === "env" && list) {
        if (fnStack.some((f) => URL_FUNCTIONS.has(f))) {
          ok = false;
          diag("css-dropped", `${where}: env() inside a URL-taking function`);
          return;
        }
        const env2 = resolveEnv(node);
        if (env2 === null) {
          ok = false;
          diag("profile", `${where}: ${envLabel(node)}`);
          return;
        }
        if (env2 !== "var") {
          diag("profile", `${where}: ${envLabel(node)} \u2192 its fallback`);
          const repl = new csstree.List().fromArray(env2);
          csstree.walk({ type: "Value", children: repl }, visitor);
          list.replace(item, repl);
          return csstree.walk.skip;
        }
      }
      switch (node.type) {
        case "Raw":
          ok = false;
          diag("css-dropped", `${where}: unparsable value`);
          break;
        case "Dimension":
          if (!cssUnitInProfile(node.unit)) {
            ok = false;
            diag("profile", `${where}: unit ${truncate(node.unit)}`);
            break;
          }
          if (env.scope === "shadow") {
            const unit = CONTAINER_UNITS[node.unit.toLowerCase()];
            if (unit) node.unit = unit;
          }
          break;
        case "Url": {
          const checked = checkUrl(node.value, urlKind);
          if (checked === null) {
            ok = false;
            diag("url-blocked", `${where}: url(${truncate(node.value)})`);
          } else node.value = checked;
          break;
        }
        case "Function": {
          const name = node.name.toLowerCase();
          if (name === "url") {
            ok = false;
            diag("url-blocked", `${where}: url() with modifiers`);
          } else if (!cssFunctionInProfile(name)) {
            ok = false;
            diag("profile", `${where}: ${truncate(name)}()`);
          } else if (fnStack.some((f) => URL_FUNCTIONS.has(f)) && SUBSTITUTION_FUNCTIONS.has(name)) {
            ok = false;
            diag("css-dropped", `${where}: ${name}() inside a URL-taking function`);
          } else if (name === "attr" && env.strict) {
            const first = node.children.first;
            const attr = first?.type === "Identifier" ? first.name.toLowerCase() : "";
            if (!isTextAttr(attr)) {
              ok = false;
              diag("css-dropped", `${where}: attr(${truncate(attr)}) reads an attribute outside the text budget`);
            }
          }
          fnStack.push(name);
          break;
        }
        case "String":
          if (fnStack.some((f) => URL_FUNCTIONS.has(f))) {
            const checked = checkUrl(node.value, "image");
            if (checked === null) {
              ok = false;
              diag("url-blocked", `${where}: "${truncate(node.value)}" in ${fnStack[fnStack.length - 1]}()`);
            } else node.value = checked;
          }
          break;
      }
    },
    leave(node) {
      if (node.type === "Function") fnStack.pop();
    }
  };
  csstree.walk(value, visitor);
  return ok;
}
function resolveEnv(node) {
  const args = node.children.toArray();
  const name = args[0]?.type === "Identifier" ? args[0].name : null;
  if (name === null || args.length > 1 && !(args[1].type === "Operator" && args[1].value === ",")) return null;
  const fallback = args.slice(2);
  if (Object.prototype.hasOwnProperty.call(SAFE_AREA_ENV_VARIABLES, name)) {
    node.name = "var";
    args[0].name = SAFE_AREA_ENV_VARIABLES[name];
    return "var";
  }
  return fallback.length ? fallback : null;
}
function envLabel(node) {
  const first = node.children.first;
  return `env(${truncate(first?.type === "Identifier" ? first.name : "")})`;
}
function truncate(s) {
  if (s.length <= 80) return s;
  const last = s.charCodeAt(79);
  return s.slice(0, last >= 55296 && last <= 56319 ? 79 : 80) + "\u2026";
}
function declarationIsSafe(decl, diag, env) {
  const prop = decl.property.toLowerCase();
  if (FORBIDDEN_PROPERTIES.has(prop)) return false;
  if (!cssPropertyInProfile(prop)) {
    diag("profile", `property ${truncate(prop)}`);
    return false;
  }
  if (prop === "color-scheme") {
    const t = csstree.generate(decl.value).toLowerCase();
    if (/\blight\b/.test(t) && /\bdark\b/.test(t)) decl.value = csstree.parse(env.colorScheme, { context: "value" });
  }
  if (FILTER_PROPERTIES.has(prop) && !pruneFilterList(prop, decl, diag)) return false;
  return valueIsSafe(decl.value, "image", diag, prop, env) && valueInProfile(prop, decl, diag, env);
}
const FILTER_PROPERTIES = /* @__PURE__ */ new Set(["filter", "backdrop-filter", "-webkit-backdrop-filter"]);
function pruneFilterList(prop, decl, diag) {
  if (decl.value.type !== "Value") return true;
  const items = decl.value.children.toArray();
  const kept = items.filter((n) => {
    if (n.type === "Url" || n.type === "Function" && !FILTER_FUNCTIONS.has(n.name.toLowerCase()) && !SUBSTITUTION_NAMES.has(n.name.toLowerCase())) {
      diag("profile", `${prop}: ${n.type === "Url" ? "url()" : n.name.toLowerCase() + "()"}`);
      return false;
    }
    return true;
  });
  if (kept.length === 0) return false;
  if (kept.length !== items.length) decl.value.children = listOf(kept);
  return true;
}
const ident = (n) => n?.type === "Identifier" ? n.name.toLowerCase() : null;
const listOf = (nodes) => new csstree.List().fromArray(nodes);
const comma = () => ({ type: "Operator", value: "," });
function valueInProfile(prop, decl, diag, env) {
  if (prop.startsWith("--") || decl.value.type !== "Value") return true;
  const items = decl.value.children.toArray();
  const substituted = items.some((n) => csstree.find(n, SUBSTITUTED) !== null);
  const only = items.length === 1 ? ident(items[0]) : null;
  if (only && GLOBAL_KEYWORDS.has(only)) return true;
  const drop = (why) => {
    diag("profile", `${prop}: ${truncate(why)}`);
    return false;
  };
  const allowed = VALUE_SETS[prop];
  const overflow = prop === "overflow" || prop === "overflow-x" || prop === "overflow-y";
  const rewrite = overflow && env.nativeScrolling ? void 0 : REWRITES[overflow ? "overflow" : prop];
  if (rewrite) {
    for (const n of items) {
      const v = ident(n);
      if (v && Object.prototype.hasOwnProperty.call(rewrite, v)) {
        diag("profile", `${prop}: ${v} \u2192 ${rewrite[v]}`);
        n.name = rewrite[v];
      }
    }
  }
  if (allowed && !substituted) {
    const v = items.length === 1 ? ident(items[0]) : null;
    if (!v || !allowed.includes(v)) return drop(csstree.generate(decl.value));
  }
  switch (prop) {
    case "background-clip":
      if (items.some((n) => ident(n) === "text")) return drop("text");
      break;
    case "transform":
      if (csstree.find(decl.value, (n) => n.type === "Function" && TRANSFORM_3D.has(n.name.toLowerCase()))) return drop("3D function");
      break;
    case "rotate":
      if (items.some((n) => ["x", "y", "z"].includes(ident(n) ?? "")) || items.filter((n) => n.type === "Number").length > 1) return drop("3D rotation");
      break;
    case "translate":
    case "scale":
      if (items.filter((n) => n.type !== "Operator").length > 2) return drop("3D");
      break;
    case "font-family":
      decl.value.children = listOf(genericFamilies(items, diag));
      break;
    case "font": {
      const start = fontShorthandFamilyStart(items, fontTokenKind);
      if (start > 0 && start < items.length) decl.value.children = listOf([...items.slice(0, start), ...genericFamilies(items.slice(start), diag)]);
      break;
    }
  }
  return true;
}
function fontTokenKind(n) {
  const size = n.type === "Dimension" || n.type === "Percentage" || n.type === "Identifier" && FONT_SIZE_KEYWORDS.has(n.name.toLowerCase()) || n.type === "Function" && ["calc", "min", "max", "clamp"].includes(n.name.toLowerCase());
  return { size, slash: n.type === "Operator" && n.value === "/" };
}
function genericFamilies(items, diag) {
  const groups = [[]];
  for (const n of items) {
    if (n.type === "Operator" && n.value === ",") groups.push([]);
    else groups[groups.length - 1].push(n);
  }
  const kept = [];
  const names = /* @__PURE__ */ new Set();
  for (const g of groups) {
    if (g.length === 0) continue;
    if (g.some((n) => n.type === "Function")) {
      kept.push(g);
      continue;
    }
    const name = g.length === 1 ? ident(g[0]) : null;
    const alias = name && Object.prototype.hasOwnProperty.call(FONT_ALIASES, name) ? FONT_ALIASES[name] : null;
    if (alias) {
      diag("profile", `font-family: ${name} \u2192 ${alias}`);
      if (!names.has(alias)) kept.push([{ type: "Identifier", name: alias }]);
      names.add(alias);
      continue;
    }
    if (name && (isGenericFont(name) || GLOBAL_KEYWORDS.has(name))) {
      if (names.has(name)) continue;
      kept.push(g);
      names.add(name);
      continue;
    }
    diag("profile", `font-family: ${truncate(g.map((n) => n.type === "String" ? JSON.stringify(n.value) : csstree.generate(n)).join(" "))}`);
  }
  const out = [];
  kept.forEach((g, i) => {
    out.push(g);
    const name = g.length === 1 ? ident(g[0]) : null;
    const fallback = name ? FONT_FALLBACK[name] : void 0;
    if (fallback && !kept.slice(i + 1).some((h) => h.length === 1 && ident(h[0]) === fallback) && !out.some((h) => h.length === 1 && ident(h[0]) === fallback)) {
      out.push([{ type: "Identifier", name: fallback }]);
    }
  });
  if (out.length === 0) out.push([{ type: "Identifier", name: PROFILE_CSS.fonts.default }]);
  return out.flatMap((g, i) => i ? [comma(), ...g] : g);
}
function sanitizeFontValue(prop, value, diag) {
  try {
    const ast = parse(`${prop}:${value}`, "declaration");
    if (ast.type !== "Declaration" || !declarationIsSafe(ast, diag, DEFAULT_ENV)) return null;
    return csstree.generate(ast.value);
  } catch {
    return null;
  }
}
const CONTAINER_UNITS = {
  vw: "cqw",
  svw: "cqw",
  lvw: "cqw",
  dvw: "cqw",
  vh: "cqh",
  svh: "cqh",
  lvh: "cqh",
  dvh: "cqh",
  vmin: "cqmin",
  svmin: "cqmin",
  lvmin: "cqmin",
  dvmin: "cqmin",
  vmax: "cqmax",
  svmax: "cqmax",
  lvmax: "cqmax",
  dvmax: "cqmax",
  vi: "cqi",
  svi: "cqi",
  lvi: "cqi",
  dvi: "cqi",
  vb: "cqb",
  svb: "cqb",
  lvb: "cqb",
  dvb: "cqb"
};
const SIZE_FEATURE = /^\(\s*(?:(?:min-|max-)?(?:width|height|aspect-ratio)\s*:\s*[^()]+|orientation\s*:\s*(?:portrait|landscape)\s*|[^()]*\b(?:width|height)\b[^()]*[<>][^()]*)\)$/i;
function mediaToContainer(text) {
  const out = [];
  for (let q of text.split(",")) {
    q = q.trim().replace(/^only\s+/i, "");
    if (!q) return null;
    const type = /^(screen|all)\b\s*(?:and\b)?\s*/i.exec(q);
    if (type) q = q.slice(type[0].length).trim();
    if (!q) {
      out.push("(min-width: 0px)");
      continue;
    }
    const features = q.split(/\s+and\s+/i);
    for (const f of features) if (!SIZE_FEATURE.test(f.trim())) return null;
    out.push(features.map((f) => f.trim()).join(" and "));
  }
  return "tw " + out.join(" or ");
}
function profileSelectorList(prelude, diag) {
  const keep = new csstree.List();
  prelude.children.forEach((sel) => {
    let bad = null;
    csstree.walk(sel, {
      enter(node, item, list) {
        if (bad) return;
        if (node.type === "NestingSelector") bad = "&";
        else if (node.type === "PseudoElementSelector" && !cssPseudoElementInProfile(node.name)) bad = "::" + node.name;
        else if (node.type === "PseudoClassSelector") {
          const name = node.name.toLowerCase();
          const replacement = Object.prototype.hasOwnProperty.call(PSEUDO_REWRITE, name) ? PSEUDO_REWRITE[name] : null;
          if (replacement && list) {
            const parsed = csstree.parse(replacement, { context: "selector" });
            list.replace(item, parsed.children);
          } else if (!cssPseudoClassInProfile(name)) bad = ":" + name;
        }
      }
    });
    if (bad) diag("profile", `selector ${truncate(bad)}`);
    else keep.appendData(sel);
  });
  prelude.children = keep;
  return !keep.isEmpty;
}
function scopeSelectorList(prelude) {
  const keep = new csstree.List();
  prelude.children.forEach((sel) => {
    csstree.walk(sel, {
      enter(node, item, list) {
        if (node.type === "PseudoClassSelector" && node.name.toLowerCase() === "root" && !node.children && list) {
          const attr = { type: "AttributeSelector", name: { type: "Identifier", name: "data-tw-root" }, matcher: null, value: null, flags: null };
          list.replace(item, csstree.List.createItem(attr));
        }
      }
    });
    keep.appendData(sel);
  });
  prelude.children = keep;
  return !keep.isEmpty;
}
function mediaInProfile(text) {
  let s = text.toLowerCase();
  const features = [];
  for (let guard = 0; /\([^()]*\)/.test(s) && guard < 64; guard++) {
    s = s.replace(/\(([^()]*)\)/g, (_, inner) => {
      const t = inner.trim();
      if (t === "" || t === "" || /^(?:not\s+)?\u0001(?:\s+(?:and|or)\s+\u0001)*$/.test(t)) return "  ";
      const colon = t.indexOf(":");
      if (colon >= 0) features.push(t.slice(0, colon).trim());
      else if (/[<>=]/.test(t)) features.push(...t.match(/[a-z][a-z-]*/g) ?? []);
      else features.push(t);
      return "  ";
    });
  }
  if (/[()]/.test(s)) return false;
  for (const f of features) if (!MEDIA_FEATURES.has(f)) return false;
  for (const word of s.match(/[a-z][a-z-]*/g) ?? []) if (!["and", "or", "not", "only"].includes(word) && !MEDIA_TYPES.has(word)) return false;
  return true;
}
function rewriteMediaQuery(text, env) {
  if (!mediaInProfile(text)) return NEVER;
  return text.replace(/\(\s*prefers-color-scheme\s*:\s*(dark|light)\s*\)/gi, (_, v) => v.toLowerCase() === env.colorScheme ? ALWAYS : NEVER).replace(/\(\s*prefers-reduced-motion\s*(?::\s*(reduce|no-preference)\s*)?\)/gi, (_, v) => (v ?? "reduce").toLowerCase() === "reduce" === !!env.reducedMotion ? ALWAYS : NEVER);
}
function resolveSupports(list) {
  const out = [];
  list.forEach((node) => {
    if (node.type === "Atrule" && node.name.toLowerCase() === "supports") {
      if (node.block && node.prelude && supportsCondition(csstree.generate(node.prelude))) out.push(...resolveSupports(node.block.children).toArray());
      return;
    }
    if ((node.type === "Atrule" || node.type === "Rule") && node.block) node.block.children = resolveSupports(node.block.children);
    out.push(node);
  });
  return new csstree.List().fromArray(out);
}
function hasRaw(node) {
  return !!node && csstree.find(node, (n) => n.type === "Raw") !== null;
}
function rawIsSafe(node) {
  let ok = true;
  csstree.walk(node, (n) => {
    if (n.type === "Raw" && !SAFE_RAW_PRELUDE.test(n.value)) ok = false;
  });
  return ok;
}
function sanitizeTree(ast, diag, env) {
  const atruleStack = [];
  let ruleDepth = 0;
  if (ast.type === "StyleSheet") ast.children = resolveSupports(ast.children);
  csstree.walk(ast, {
    enter(node, item, list) {
      if ((node.type === "Atrule" || node.type === "Rule") && ruleDepth > 0 && list) {
        diag("profile", "nested rule");
        list.remove(item);
        return csstree.walk.skip;
      }
      if (node.type === "Atrule") {
        const name = node.name.toLowerCase();
        if (!ALLOWED_ATRULES.has(name)) {
          diag(SECURITY_ATRULES.has(name) ? "css-dropped" : "profile", `@${name}`);
          list.remove(item);
          return csstree.walk.skip;
        }
        if (name === "media" && node.prelude) {
          let text = csstree.generate(node.prelude);
          if (!mediaInProfile(text)) {
            diag("profile", `@media ${truncate(text)}`);
            list.remove(item);
            return csstree.walk.skip;
          }
          if (/prefers-(?:color-scheme|reduced-motion)/i.test(text)) {
            text = rewriteMediaQuery(text, env);
            node.prelude = { type: "Raw", value: text };
          }
          if (env.scope === "shadow") {
            const container = mediaToContainer(text);
            if (container) {
              node.name = "container";
              node.prelude = { type: "Raw", value: container };
            }
          }
        }
        if (node.prelude && hasRaw(node.prelude) && !rawIsSafe(node.prelude)) {
          diag("css-dropped", `@${name}: unparsable prelude`);
          list.remove(item);
          return csstree.walk.skip;
        }
        atruleStack.push(name);
      } else if (node.type === "Rule") {
        if (hasRaw(node.prelude)) {
          diag("css-dropped", "rule with unparsable selector");
          list.remove(item);
          return csstree.walk.skip;
        }
        const inKeyframes = /keyframes$/.test(atruleStack[atruleStack.length - 1] ?? "");
        if (!inKeyframes && node.prelude.type === "SelectorList" && !profileSelectorList(node.prelude, diag)) {
          list.remove(item);
          return csstree.walk.skip;
        }
        if (env.scope === "shadow" && node.prelude.type === "SelectorList" && !scopeSelectorList(node.prelude)) {
          diag("css-dropped", "rule: shadow-host selector");
          list.remove(item);
          return csstree.walk.skip;
        }
        if (!inKeyframes) ruleDepth++;
        atruleStack.push(inKeyframes ? "keyframe" : "rule");
      } else if (node.type === "Declaration") {
        if (!declarationIsSafe(node, diag, env)) list.remove(item);
        return csstree.walk.skip;
      } else if (node.type === "Raw") {
        if (ruleDepth > 0 && node.value.includes("{")) diag("profile", "nested rule");
        if (list) list.remove(item);
        return csstree.walk.skip;
      }
    },
    leave(node) {
      if (node.type === "Atrule") atruleStack.pop();
      else if (node.type === "Rule" && atruleStack.pop() === "rule") ruleDepth--;
    }
  });
}
function parse(css, context) {
  return csstree.parse(stripUnicodeControls(css), { ...PARSE_OPTS, context });
}
const SHEET_CACHE_SIZE = 32;
const SHEET_CACHE_MAX_TEXT = 262144;
const sheetCache = /* @__PURE__ */ new Map();
function clearStylesheetCache() {
  sheetCache.clear();
}
function sanitizeStylesheet(css, diag, env = DEFAULT_ENV) {
  const key = `${env.colorScheme}${env.scope ?? ""}${env.strict ? 1 : 0}${env.reducedMotion ? 1 : 0}${env.nativeScrolling ? 1 : 0}${css}`;
  let hit = sheetCache.get(key);
  if (!hit) {
    const diags = [];
    hit = { out: sanitizeStylesheetUncached(css, (k, d) => diags.push([k, d]), env), diags };
    if (css.length < SHEET_CACHE_MAX_TEXT) {
      if (sheetCache.size >= SHEET_CACHE_SIZE) sheetCache.delete(sheetCache.keys().next().value);
      sheetCache.set(key, hit);
    }
  }
  for (const [k, d] of hit.diags) diag(k, d);
  return hit.out;
}
function sanitizeStylesheetUncached(css, diag, env) {
  try {
    const ast = parse(css, "stylesheet");
    sanitizeTree(ast, diag, env);
    return csstree.generate(ast);
  } catch (e) {
    diag("css-dropped", "stylesheet: " + e.message);
    return "";
  }
}
function sanitizeStyleAttribute(css, diag, env = DEFAULT_ENV) {
  try {
    const ast = parse(css, "declarationList");
    sanitizeTree(ast, diag, env);
    return csstree.generate(ast);
  } catch (e) {
    diag("css-dropped", "style attribute: " + e.message);
    return "";
  }
}
const PROPERTY_NAME = /^-{0,2}[a-zA-Z_][\w-]*$/;
const FAST_MAX = 256;
const T_IDENT = 1, T_FUNC = 2, T_HASH = 3, T_NUM = 4, T_PCT = 5, T_DIM = 6, T_COMMA = 7, T_CLOSE = 8;
const bits = (...ts) => ts.reduce((m, t) => m | 1 << t, 0);
const SPACE_BEFORE = [];
SPACE_BEFORE[0] = 0;
SPACE_BEFORE[T_IDENT] = bits(T_IDENT, T_FUNC, T_NUM, T_PCT, T_DIM, T_HASH);
SPACE_BEFORE[T_FUNC] = 0;
SPACE_BEFORE[T_HASH] = bits(T_IDENT, T_FUNC, T_NUM, T_PCT, T_DIM, T_HASH);
SPACE_BEFORE[T_NUM] = bits(T_IDENT, T_FUNC, T_NUM, T_PCT, T_DIM);
SPACE_BEFORE[T_PCT] = bits(T_PCT, T_DIM, T_FUNC);
SPACE_BEFORE[T_DIM] = bits(T_IDENT, T_FUNC, T_NUM, T_PCT, T_DIM, T_HASH);
SPACE_BEFORE[T_COMMA] = 0;
SPACE_BEFORE[T_CLOSE] = bits(T_IDENT, T_FUNC, T_PCT, T_DIM, T_HASH);
const MINUS_SPACE = bits(T_IDENT, T_HASH, T_DIM, T_PCT, T_CLOSE);
const FAST_FUNCTIONS = new Set(PROFILE_CSS.functions.filter((f) => !SUBSTITUTION_FUNCTIONS.has(f) && !URL_FUNCTIONS.has(f) && f !== "url" && f !== "light-dark" && !TRANSFORM_3D.has(f)));
const FAST_UNITS = new Set(PROFILE_CSS.units.filter((u) => !Object.prototype.hasOwnProperty.call(CONTAINER_UNITS, u)));
const FAST_CUSTOM = {};
const FAST_PROPS = /* @__PURE__ */ new Map();
for (const prop of PROFILE_CSS.properties) {
  if (FORBIDDEN_PROPERTIES.has(prop) || FILTER_PROPERTIES.has(prop) || prop === "color-scheme" || prop === "font" || prop === "font-family") continue;
  const overflow = prop === "overflow" || prop === "overflow-x" || prop === "overflow-y";
  FAST_PROPS.set(prop, {
    keywords: VALUE_SETS[prop],
    rewrite: REWRITES[overflow ? "overflow" : prop],
    kind: prop === "rotate" ? "rotate" : prop === "translate" || prop === "scale" ? "translate" : prop === "background-clip" ? "clip" : void 0
  });
}
const C_DIGIT = 1, C_LETTER = 2, C_NAME = 4;
const CHAR = new Uint8Array(128);
for (let c = 48; c <= 57; c++) CHAR[c] = C_DIGIT | C_NAME;
for (let c = 65; c <= 90; c++) CHAR[c] = CHAR[c + 32] = C_LETTER | C_NAME;
CHAR[45] = C_NAME;
let fastPathOn = true;
function setCssFastPath(on) {
  fastPathOn = on;
}
function fastStyleValue(name, value) {
  const n = value.length;
  if (n === 0 || n > FAST_MAX) return void 0;
  let rule = FAST_PROPS.get(name);
  const custom = rule === void 0 && name.charCodeAt(0) === 45 && name.charCodeAt(1) === 45 && PROPERTY_NAME.test(name);
  if (custom) rule = FAST_CUSTOM;
  if (rule === void 0) return void 0;
  let out;
  let prev = 0;
  let prevEnd = 0;
  let depth = 0;
  let topItems = 0, topNonComma = 0, topNumbers = 0;
  let lastTopIdent = "";
  let lastTopStart = -1;
  const readsIdents = rule.rewrite !== void 0 || rule.kind === "clip" || rule.kind === "rotate";
  let i = 0;
  while (i < n) {
    const start = i;
    const c = value.charCodeAt(i);
    const k = c < 128 ? CHAR[c] : 0;
    let type;
    let minus = false;
    if (c === 32) {
      i++;
      continue;
    }
    if (k & C_DIGIT || c === 46 || c === 45) {
      const c1 = value.charCodeAt(i + 1);
      const k1 = c1 < 128 ? CHAR[c1] : 0;
      let numeric = (k | k1) & C_DIGIT;
      if (!numeric && c === 45 && c1 === 46) {
        const c2 = value.charCodeAt(i + 2);
        numeric = c2 < 128 ? CHAR[c2] & C_DIGIT : 0;
      }
      if (c === 46 && !(k1 & C_DIGIT)) numeric = 0;
      if (numeric) {
        minus = c === 45;
        if (minus) i++;
        let d = value.charCodeAt(i);
        while (d >= 48 && d <= 57) d = value.charCodeAt(++i);
        if (d === 46) {
          const d1 = value.charCodeAt(i + 1);
          if (d1 >= 48 && d1 <= 57) {
            i++;
            do
              d = value.charCodeAt(++i);
            while (d >= 48 && d <= 57);
          }
        }
        const u1 = value.charCodeAt(i + 1);
        if (d === 101 || d === 69) {
          if (u1 >= 48 && u1 <= 57 || (u1 === 45 || u1 === 43) && (value.charCodeAt(i + 2) >= 48 && value.charCodeAt(i + 2) <= 57)) return void 0;
        }
        const ku = d < 128 ? CHAR[d] : 0;
        if (d === 37) {
          i++;
          type = T_PCT;
        } else if (ku & C_LETTER || d === 45 && ((u1 < 128 ? CHAR[u1] : 0) & C_LETTER || u1 === 45)) {
          const unitStart = i;
          do
            d = value.charCodeAt(++i);
          while (d < 128 && CHAR[d] & C_NAME);
          const unit = value.slice(unitStart, i);
          if (!FAST_UNITS.has(unit) && !FAST_UNITS.has(unit.toLowerCase())) return void 0;
          type = T_DIM;
        } else type = T_NUM;
      } else if (c === 45 && (k1 & C_LETTER || c1 === 45)) {
        let d = c1;
        do
          d = value.charCodeAt(++i);
        while (d < 128 && CHAR[d] & C_NAME);
        type = T_IDENT;
      } else return void 0;
    } else if (k & C_LETTER) {
      let d = c;
      do
        d = value.charCodeAt(++i);
      while (d < 128 && CHAR[d] & C_NAME);
      type = T_IDENT;
    } else if (c === 35) {
      let d = c;
      do
        d = value.charCodeAt(++i);
      while (d < 128 && CHAR[d] & C_NAME);
      if (i === start + 1) return void 0;
      type = T_HASH;
    } else if (c === 44) {
      i++;
      if (prev === 0 || prev === T_FUNC || prev === T_COMMA) return void 0;
      type = T_COMMA;
    } else if (c === 41) {
      i++;
      if (depth === 0 || prev === T_COMMA) return void 0;
      depth--;
      type = T_CLOSE;
    } else return void 0;
    if (type === T_IDENT && i < n && value.charCodeAt(i) === 40) {
      const fn = value.slice(start, i);
      if (!FAST_FUNCTIONS.has(fn) && !FAST_FUNCTIONS.has(fn.toLowerCase())) return void 0;
      i++;
      type = T_FUNC;
    }
    if (depth === 0 && type !== T_CLOSE) {
      topItems++;
      if (type !== T_COMMA) topNonComma++;
      if (type === T_NUM) topNumbers++;
      if (type === T_IDENT) {
        lastTopStart = start;
        if (readsIdents) {
          lastTopIdent = value.slice(start, i).toLowerCase();
          if (rule.rewrite && Object.prototype.hasOwnProperty.call(rule.rewrite, lastTopIdent)) return void 0;
          if (rule.kind === "clip" && lastTopIdent === "text") return void 0;
          if (rule.kind === "rotate" && (lastTopIdent === "x" || lastTopIdent === "y" || lastTopIdent === "z")) return void 0;
        }
      }
    }
    if (type === T_FUNC) depth++;
    const space = (minus ? MINUS_SPACE >> prev : SPACE_BEFORE[prev] >> type) & 1;
    if (out === void 0) {
      if (start - prevEnd !== space) out = value.slice(0, prevEnd) + (space ? " " : "") + value.slice(start, i);
    } else out += (space ? " " : "") + value.slice(start, i);
    prev = type;
    prevEnd = i;
  }
  if (prev === 0 || depth !== 0 || prev === T_COMMA) return void 0;
  if (out === void 0 && prevEnd !== n) out = value.slice(0, prevEnd);
  if (!custom) {
    const single = topItems === 1 && prev === T_IDENT;
    if (single && !readsIdents) lastTopIdent = value.slice(lastTopStart, prevEnd).toLowerCase();
    if (!(single && GLOBAL_KEYWORDS.has(lastTopIdent))) {
      if (rule.keywords && !(single && rule.keywords.includes(lastTopIdent))) return void 0;
      if (rule.kind === "rotate" && topNumbers > 1) return void 0;
      if (rule.kind === "translate" && topNonComma > 2) return void 0;
    }
  }
  return out ?? value;
}
function sanitizeStyleProperty(name, value, diag, env = DEFAULT_ENV) {
  if (fastPathOn) {
    const fast = fastStyleValue(name, value);
    if (fast !== void 0) return { name, value: fast };
  }
  return sanitizeStylePropertyFull(name, value, diag, env);
}
function sanitizeStylePropertyFull(name, value, diag, env = DEFAULT_ENV) {
  if (!PROPERTY_NAME.test(name)) return null;
  if (value === "") return { name, value: "" };
  try {
    const ast = parse(`${name}:${value}`, "declaration");
    if (ast.type !== "Declaration" || !declarationIsSafe(ast, diag, env)) return null;
    return { name, value: csstree.generate(ast.value) };
  } catch {
    return null;
  }
}
function sanitizeCssValue(value, diag, where = "value", env = DEFAULT_ENV) {
  try {
    const ast = parse(value, "value");
    if (!valueIsSafe(ast, "image", diag, where, env)) return null;
    return csstree.generate(ast);
  } catch {
    return null;
  }
}
export {
  DEFAULT_ENV,
  TEXT_ATTRS,
  TEXT_ATTR_PREFIXES,
  clearStylesheetCache,
  cssStringText,
  fastStyleValue,
  isTextAttr,
  mediaInProfile,
  mediaToContainer,
  rewriteMediaQuery,
  sanitizeCssValue,
  sanitizeFontValue,
  sanitizeStyleAttribute,
  sanitizeStyleProperty,
  sanitizeStylePropertyFull,
  sanitizeStylesheet,
  setCssFastPath
};
