import sandboxBundle from "virtual:sandbox-bundle";
import { LIMIT_DEFAULTS, SAB_SIZE } from "../shared/protocol";
class WorkerPool {
  constructor(size, opts = {}) {
    this.size = size;
    this.opts = opts;
  }
  size;
  opts;
  idle = [];
  destroyed = false;
  /** Counters for the demo / bench. */
  stats = { created: 0, hits: 0, misses: 0 };
  /** Fill the pool and wait until every worker is warm (app start). */
  async prewarm() {
    this.refill();
    await Promise.all(this.idle.map((e) => e.warmed.catch(() => 0)));
  }
  /** A warmed worker (or a fresh one when the pool is empty: it still boots, just later than it could have). */
  take() {
    let e = this.idle.shift();
    if (e) this.stats.hits++;
    else {
      this.stats.misses++;
      e = this.create();
    }
    queueMicrotask(() => this.refill());
    return e;
  }
  /** Top the pool up to `size` (no-op while `canRefill` says no). */
  refill() {
    if (this.destroyed) return;
    while (this.idle.length < this.size && (this.opts.canRefill?.() ?? true)) this.idle.push(this.create());
  }
  get warm() {
    return this.idle.length;
  }
  destroy() {
    this.destroyed = true;
    for (const e of this.idle.splice(0)) e.worker.terminate();
  }
  create() {
    this.stats.created++;
    const worker = new Worker(new URL("./worker.js", import.meta.url), { type: "module" });
    const sab = new SharedArrayBuffer(SAB_SIZE);
    const config = {
      ...LIMIT_DEFAULTS,
      ...this.opts.limits,
      visible: true,
      viewport: { innerWidth: 400, innerHeight: 300, dpr: 1 },
      theme: "light"
    };
    const pending = [];
    const warmed = new Promise((resolve, reject) => {
      worker.onmessage = (ev) => {
        pending.push(ev.data);
        if (ev.data.type === "warmed") resolve(ev.data.bootMs);
        else if (ev.data.type === "dead") reject(new Error(ev.data.reason));
      };
      worker.onerror = (ev) => reject(new Error(ev.message));
    });
    worker.postMessage({ type: "warm", sab, config, sandboxBundle });
    return { worker, sab, warmed, pending };
  }
}
export {
  WorkerPool
};
