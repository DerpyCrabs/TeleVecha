import { PROFILE_IMAGES } from "../shared/profile-tables";
const IMAGE_MIME = new Set(PROFILE_IMAGES);
const hostBlobUrls = /* @__PURE__ */ new Set();
function normalize(raw) {
  return raw.replace(/[\t\n\r]/g, "").replace(/^[\u0000- ]+|[\u0000- ]+$/g, "");
}
function dataMime(url) {
  const m = /^data:([^,;]*)(?:;[^,]*)?,/i.exec(url);
  return m ? m[1].trim().toLowerCase() : null;
}
const MAX_IMAGE_PIXELS = 1024 * 1024;
const BROKEN_IMAGE = "data:image/png;base64,";
const HEADER_SCAN_BYTES = 64 * 1024;
const BLOCK_BYTES = 3072;
function dataBytes(url) {
  const hash = url.indexOf("#");
  const data = hash < 0 ? url : url.slice(0, hash);
  const comma = data.indexOf(",");
  const base64 = comma >= 0 && /;[\t\n\f\r ]*base64$/i.test(data.slice(0, comma).replace(/[\t\n\f\r ]+$/, ""));
  const body = comma < 0 ? "" : data.slice(comma + 1);
  let plain = base64 ? 0 : -1;
  let start = 0, text = "", toEnd = false;
  let failed = false;
  let decoder;
  const load = (from, to) => {
    if (failed || from >= start && toEnd) return false;
    if (plain >= 0) {
      const first = Math.floor(from / 3) * 3;
      const end = Math.min(Math.ceil(Math.max(to, first + BLOCK_BYTES) / 3) * 4, body.length);
      if (end > plain) plain = /[%\t\n\f\r ]/.test(body.slice(plain, end)) ? -1 : end;
      if (plain >= 0) {
        try {
          text = atob(body.slice(first / 3 * 4, end));
        } catch {
          failed = true;
          return false;
        }
        start = first;
        toEnd = end === body.length;
        return to <= start + text.length;
      }
    }
    decoder ??= bodyDecoder(body, base64);
    const decoded = decoder(to);
    if (decoded === null) {
      failed = true;
      return false;
    }
    start = 0;
    text = decoded;
    toEnd = decoded.length < to;
    return !toEnd;
  };
  return {
    has: (from, to) => from >= start && to <= start + text.length || load(from, to),
    at: (i) => text.charCodeAt(i - start)
  };
}
function bodyDecoder(body, base64) {
  let decoded = "", read = 0, carry = "", failed = false;
  return (n) => {
    while (!failed && decoded.length < n && read < body.length) {
      let part = body.slice(read, read + Math.max(4096, decoded.length));
      const last = read + part.length >= body.length;
      if (!last) part = part.slice(0, part.length - cutTail(part));
      read += part.length;
      const text = percentDecode(part);
      if (!base64) {
        decoded += text;
        continue;
      }
      let b64 = carry + text.replace(/[\t\n\f\r ]/g, "");
      carry = last ? "" : b64.slice(b64.length - b64.length % 4);
      b64 = b64.slice(0, b64.length - carry.length);
      try {
        decoded += atob(b64);
      } catch {
        failed = true;
      }
    }
    return failed ? null : decoded;
  };
}
function cutTail(part) {
  const n = part.length, last = part.charCodeAt(n - 1);
  if (last === 37 || last >= 55296 && last <= 56319) return 1;
  return n > 1 && part.charCodeAt(n - 2) === 37 && /[0-9a-f]/i.test(part[n - 1]) ? 2 : 0;
}
function percentDecode(text) {
  if (/[^\x00-\x7f]/.test(text)) {
    text = unescape(encodeURIComponent(text.replace(/[\ud800-\udbff][\udc00-\udfff]|[\ud800-\udfff]/g, (c) => c.length === 2 ? c : "\uFFFD")));
  }
  if (!text.includes("%")) return text;
  return unescape(/%u/i.test(text) ? text.replace(/%u/gi, "%25u") : text);
}
function dataImageSize(url) {
  const { has, at } = dataBytes(url);
  const u16be = (i) => at(i) << 8 | at(i + 1);
  const le16 = (i) => at(i) | at(i + 1) << 8;
  const u24le = (i) => at(i) | at(i + 1) << 8 | at(i + 2) << 16;
  const is = (i, magic) => {
    if (!has(i, i + magic.length)) return false;
    for (let k = 0; k < magic.length; k++) if (at(i + k) !== magic.charCodeAt(k)) return false;
    return true;
  };
  if (is(0, "\x89PNG\r\n\n") && is(12, "IHDR") && has(0, 24)) return [u16be(16) * 65536 + u16be(18), u16be(20) * 65536 + u16be(22)];
  if ((is(0, "GIF87a") || is(0, "GIF89a")) && has(0, 13)) {
    const screen = [le16(6), le16(8)];
    let blocks = 0;
    for (let i = 13 + (at(10) & 128 ? 3 << (at(10) & 7) + 1 : 0), extensions = 0; i < HEADER_SCAN_BYTES && extensions < 256; extensions++) {
      if (!has(i, i + 2)) return null;
      if (at(i) === 44) return has(i, i + 9) ? [Math.max(screen[0], le16(i + 1) + le16(i + 5)), Math.max(screen[1], le16(i + 3) + le16(i + 7))] : null;
      if (at(i) !== 33) return null;
      for (i += 2; ; ) {
        if (i >= HEADER_SCAN_BYTES || ++blocks > 4096 || !has(i, i + 1)) return null;
        const n = at(i);
        i += 1 + n;
        if (n === 0) break;
      }
    }
    return null;
  }
  if (is(0, "RIFF") && is(8, "WEBP")) {
    if (is(12, "VP8X") && has(0, 30)) return [1 + u24le(24), 1 + u24le(27)];
    if (is(12, "VP8L") && has(0, 25) && at(20) === 47) return [1 + (at(21) | (at(22) & 63) << 8), 1 + (at(22) >> 6 | at(23) << 2 | (at(24) & 15) << 10)];
    if (is(12, "VP8 ") && has(0, 30)) return [(at(26) | at(27) << 8) & 16383, (at(28) | at(29) << 8) & 16383];
    return null;
  }
  if (is(0, "\xFF\xD8") && has(0, 4)) {
    for (let i = 2, steps = 0; i + 9 <= HEADER_SCAN_BYTES && steps < 1024; steps++) {
      if (!has(i, i + 4) || at(i) !== 255) return null;
      const marker = at(i + 1);
      if (marker === 255) {
        i++;
        continue;
      }
      if (marker === 1 || marker >= 208 && marker <= 216) {
        i += 2;
        continue;
      }
      if (marker >= 192 && marker <= 207 && marker !== 196 && marker !== 200 && marker !== 204) return has(i, i + 9) ? [u16be(i + 7), u16be(i + 5)] : null;
      if (marker === 217 || marker === 218) return null;
      i += 2 + u16be(i + 2);
    }
  }
  return null;
}
let lastImage = null;
function checkUrl(raw, kind) {
  const url = normalize(String(raw));
  if (url.startsWith("#")) {
    return /^#[^\s"'()\\<>]*$/.test(url) ? url : null;
  }
  if (kind === "fragment-only") return null;
  if (/^data:/i.test(url)) {
    const mime = dataMime(url);
    if (mime === null) return null;
    if (kind !== "image" || !IMAGE_MIME.has(mime)) return null;
    if (lastImage?.url === url) return lastImage.checked;
    const size = dataImageSize(url);
    const checked = !size ? BROKEN_IMAGE : size[0] * size[1] <= MAX_IMAGE_PIXELS ? url : null;
    lastImage = { url, checked };
    return checked;
  }
  if (/^blob:/i.test(url)) return hostBlobUrls.has(url) ? url : null;
  return null;
}
function isFragment(raw) {
  return normalize(String(raw)).startsWith("#");
}
const PLACEHOLDER_IMAGE = "data:image/svg+xml," + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48"><rect width="48" height="48" fill="#8882"/><path d="M8 36l10-12 8 9 6-7 8 10z" fill="#8886"/><circle cx="33" cy="15" r="4" fill="#8886"/></svg>'
);
export {
  BROKEN_IMAGE,
  IMAGE_MIME,
  MAX_IMAGE_PIXELS,
  PLACEHOLDER_IMAGE,
  checkUrl,
  dataImageSize,
  hostBlobUrls,
  isFragment
};
