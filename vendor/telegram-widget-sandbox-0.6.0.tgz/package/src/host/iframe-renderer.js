import rendererBundle from "virtual:renderer-bundle";
import { buildSrcdoc, makeNonce } from "../renderer/srcdoc";
class IframeRenderer {
  static factory = (container, theme) => new IframeRenderer(container, theme);
  element;
  onMessage = null;
  onDiag = null;
  port;
  channel = new MessageChannel();
  onWindowMessage;
  destroyed = false;
  constructor(container, theme) {
    const nonce = makeNonce();
    const iframe = document.createElement("iframe");
    iframe.setAttribute("sandbox", "allow-scripts allow-forms");
    iframe.setAttribute("referrerpolicy", "no-referrer");
    iframe.className = "widget-frame";
    iframe.style.colorScheme = theme;
    iframe.srcdoc = buildSrcdoc(rendererBundle, nonce);
    this.element = iframe;
    this.port = this.channel.port1;
    this.port.onmessage = (e) => this.onMessage?.(e.data);
    this.onWindowMessage = (e) => {
      if (e.source !== iframe.contentWindow || e.data?.type !== "tw-renderer-ready") return;
      window.removeEventListener("message", this.onWindowMessage);
      iframe.contentWindow.postMessage({ type: "tw-init" }, "*", [this.channel.port2]);
    };
    window.addEventListener("message", this.onWindowMessage);
    container.appendChild(iframe);
  }
  /** The frame is already loading; the renderer bundle announces itself through the port once initialised. */
  load() {
  }
  send(msg) {
    if (!this.destroyed) this.port.postMessage(msg);
  }
  setTheme(theme) {
    this.element.style.colorScheme = theme;
  }
  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    window.removeEventListener("message", this.onWindowMessage);
    this.port.close();
    this.element.remove();
  }
}
export {
  IframeRenderer
};
