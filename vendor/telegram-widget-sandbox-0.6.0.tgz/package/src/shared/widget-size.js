const MINI_HTML = { zlib: 4096, raw: 32768, warnZlib: 3800 };
const kb = (n) => (n / 1024).toFixed(1) + " KB";
function sizeLine(s) {
  return `size: ${s.zlib} B zlib / ${kb(s.raw)} raw (limit ${MINI_HTML.zlib} / ${MINI_HTML.raw})`;
}
function sizeVerdict(s) {
  const over = [];
  if (s.zlib > MINI_HTML.zlib) over.push(`${s.zlib} B compressed is over the ${MINI_HTML.zlib} B limit by ${s.zlib - MINI_HTML.zlib} B`);
  if (s.raw > MINI_HTML.raw) over.push(`${s.raw} B of HTML is over the ${MINI_HTML.raw} B limit by ${s.raw - MINI_HTML.raw} B`);
  if (over.length) return { level: "error", message: `error: too large, the server refuses it (INPUT_MEDIA_WIDGET_TOO_LARGE): ${over.join("; ")}. Shorten the code, drop data: images, reuse classes.` };
  if (s.zlib > MINI_HTML.warnZlib) return { level: "warning", message: `warning: ${s.zlib} B compressed is ${MINI_HTML.zlib - s.zlib} B under the ${MINI_HTML.zlib} B limit; another zlib can count a few bytes more: aim for ${MINI_HTML.warnZlib} B or less.` };
  return { level: "ok", message: null };
}
export {
  MINI_HTML,
  sizeLine,
  sizeVerdict
};
