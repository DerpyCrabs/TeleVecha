const PAINT_HEAVY_BOXES = 16;
const PAINT_BACKDROP_BOXES = 2;
const PAINT_LIMIT_CODES = ["paint-limit", "backdrop-limit"];
const word = (v) => (v ?? "").trim().toLowerCase();
const isNone = (v) => {
  const w = word(v);
  return w === "" || w === "none";
};
function layers(value) {
  const out = [];
  let depth = 0, from = 0;
  for (let i = 0; i < value.length; i++) {
    const c = value[i];
    if (c === "(") depth++;
    else if (c === ")") depth = Math.max(0, depth - 1);
    else if (c === "," && depth === 0) {
      out.push(value.slice(from, i));
      from = i + 1;
    }
  }
  out.push(value.slice(from));
  return out.map((l) => l.trim()).filter(Boolean);
}
const LENGTH = /^[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?[a-z%]*$/i;
const MATH = /^(calc|min|max|clamp)$/i;
function layerLengths(layer) {
  const out = [];
  let i = 0;
  while (i < layer.length) {
    if (/\s/.test(layer[i])) {
      i++;
      continue;
    }
    let j = i;
    while (j < layer.length && !/[\s(]/.test(layer[j])) j++;
    const token = layer.slice(i, j);
    if (layer[j] === "(") {
      let depth = 0, k = j;
      for (; k < layer.length; k++) {
        if (layer[k] === "(") depth++;
        else if (layer[k] === ")" && --depth === 0) {
          k++;
          break;
        }
      }
      if (MATH.test(token)) out.push(NaN);
      i = k;
      continue;
    }
    if (LENGTH.test(token)) out.push(parseFloat(token));
    i = j;
  }
  return out;
}
function layerBlurred(layer) {
  const n = layerLengths(layer);
  return n.length >= 3 && !(n[2] <= 0);
}
function boxShadowBlurred(value) {
  if (isNone(value)) return false;
  return layers(value).some(layerBlurred);
}
function boxShadowWithoutBlur(value) {
  if (isNone(value)) return "none";
  const kept = layers(value).filter((l) => !layerBlurred(l));
  return kept.length ? kept.join(", ") : "none";
}
function transparent(value) {
  if (typeof value === "number") return value < 1;
  const w = word(value);
  if (!w) return false;
  const n = w.endsWith("%") ? parseFloat(w) / 100 : parseFloat(w);
  return n < 1;
}
function hidesSubtree(display) {
  return word(display) === "none";
}
function boxPaint(style, pseudo = false) {
  const display = word(style.display);
  if (display === "none" || !pseudo && display === "contents") return null;
  if (pseudo) {
    const content = word(style.content);
    if (content === "" || content === "none" || content === "normal") return null;
  }
  const backdrop = !isNone(style.backdropFilter);
  const dimmedButton = !pseudo && (style.button === "disabled" || style.button === "pressed");
  const heavy = backdrop || !isNone(style.filter) || !dimmedButton && transparent(style.opacity) || boxShadowBlurred(style.boxShadow);
  return { heavy, backdrop };
}
function cssName(name) {
  return name.replace(/[A-Z]/g, (c) => "-" + c.toLowerCase()).toLowerCase().replace(/^-(webkit|moz|ms|o)-/, "");
}
const KEYFRAME_MEMBERS = /* @__PURE__ */ new Set(["offset", "computedoffset", "easing", "composite"]);
function animationPaint(keyframes) {
  let heavy = false, backdrop = false, shadow = false, shadowBlurred = false, shadowFirst = false, shadowLast = false;
  for (const k of keyframes) {
    const at = typeof k.computedOffset === "number" ? k.computedOffset : typeof k.offset === "number" ? k.offset : null;
    for (const p of Object.keys(k)) {
      if (KEYFRAME_MEMBERS.has(p.toLowerCase())) continue;
      const name = cssName(p);
      if (name === "backdrop-filter") heavy = backdrop = true;
      else if (name === "filter" || name === "opacity") heavy = true;
      else if (name === "box-shadow") {
        shadow = true;
        const v = k[p];
        if (typeof v !== "string" || boxShadowBlurred(v)) shadowBlurred = true;
        if (at === 0) shadowFirst = true;
        if (at === 1) shadowLast = true;
      }
    }
  }
  if (shadow && (shadowBlurred || !shadowFirst || !shadowLast)) heavy = true;
  return heavy ? { heavy, backdrop } : null;
}
function paintLimitMessage(code, count) {
  return code === "backdrop-limit" ? `Paint limit exceeded: ${count} boxes with backdrop-filter (max ${PAINT_BACKDROP_BOXES})` : `Paint limit exceeded: ${count} boxes with shadows, filters or transparency (max ${PAINT_HEAVY_BOXES})`;
}
function checkPaintLimit(code, count) {
  if (!PAINT_LIMIT_CODES.includes(code)) return null;
  if (typeof count !== "number" || !Number.isFinite(count) || count < 0) return null;
  return { code, count: Math.floor(count) };
}
class PaintCounter {
  boxes = /* @__PURE__ */ new Map();
  heavyBoxes = 0;
  backdropBoxes = 0;
  stopped = null;
  /** The most heavy boxes there were at once, and with backdrop-filter. */
  peakHeavy = 0;
  peakBackdrop = 0;
  get heavy() {
    return this.heavyBoxes;
  }
  get backdrop() {
    return this.backdropBoxes;
  }
  contribution(b) {
    if (!b || !b.paint) return { heavy: false, backdrop: false };
    let heavy = b.paint.heavy, backdrop = b.paint.backdrop;
    if (b.anims) for (const a of b.anims.values()) {
      heavy = true;
      if (a.backdrop) backdrop = true;
    }
    return { heavy, backdrop };
  }
  /** Applies `change` to the box of `key` and keeps the counts in step. */
  update(key, change) {
    let b = this.boxes.get(key);
    const before = this.contribution(b);
    if (!b) b = { paint: null, anims: null };
    change(b);
    const after = this.contribution(b);
    this.heavyBoxes += Number(after.heavy) - Number(before.heavy);
    this.backdropBoxes += Number(after.backdrop) - Number(before.backdrop);
    if (b.paint || b.anims) this.boxes.set(key, b);
    else this.boxes.delete(key);
    if (this.heavyBoxes > this.peakHeavy) this.peakHeavy = this.heavyBoxes;
    if (this.backdropBoxes > this.peakBackdrop) this.peakBackdrop = this.backdropBoxes;
  }
  /** The box's computed values (`boxPaint`), or null: it builds no box now (display contents, a pseudo-element without content); its animations stay. */
  setBox(key, paint) {
    if (!paint && !this.boxes.has(key)) return;
    this.update(key, (b) => {
      b.paint = paint ? { heavy: paint.heavy, backdrop: paint.backdrop } : null;
    });
  }
  /** The box is not rendered (`display: none` on it or an ancestor), or its node left the document: its CSS animations are cancelled with it. */
  removeBox(key) {
    if (this.boxes.has(key)) this.update(key, (b) => {
      b.paint = null;
      b.anims = null;
    });
  }
  /** An animation of rule 5 started on the box (`animationPaint` of its properties); `id` tells it from the box's others. */
  startAnimation(key, id, paint) {
    this.update(key, (b) => {
      b.anims ??= /* @__PURE__ */ new Map();
      const a = b.anims.get(id);
      if (a) {
        a.n++;
        a.backdrop ||= paint.backdrop;
      } else b.anims.set(id, { n: 1, backdrop: paint.backdrop });
    });
  }
  /** That animation ended or was cancelled (an end without a start, a cancel during its delay, changes nothing). */
  endAnimation(key, id) {
    const a = this.boxes.get(key)?.anims?.get(id);
    if (!a) return;
    this.update(key, (b) => {
      if (--a.n > 0) return;
      b.anims.delete(id);
      if (!b.anims.size) b.anims = null;
    });
  }
  /** Whether the box of `key` has running animations under `id`. */
  animating(key, id) {
    return !!this.boxes.get(key)?.anims?.has(id);
  }
  /**
   * The verdict before a frame is drawn: null while both counts are within their limits; the first time one is past
   * its limit, `paint-limit` with the heavy count (checked first) or `backdrop-limit` with the backdrop count, and the
   * same verdict from then on.
   */
  check() {
    if (this.stopped) return this.stopped;
    if (this.heavyBoxes > PAINT_HEAVY_BOXES) this.stopped = { code: "paint-limit", count: this.heavyBoxes };
    else if (this.backdropBoxes > PAINT_BACKDROP_BOXES) this.stopped = { code: "backdrop-limit", count: this.backdropBoxes };
    return this.stopped;
  }
}
export {
  PAINT_BACKDROP_BOXES,
  PAINT_HEAVY_BOXES,
  PAINT_LIMIT_CODES,
  PaintCounter,
  animationPaint,
  boxPaint,
  boxShadowBlurred,
  boxShadowWithoutBlur,
  checkPaintLimit,
  hidesSubtree,
  paintLimitMessage
};
