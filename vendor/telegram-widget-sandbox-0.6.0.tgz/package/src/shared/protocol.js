import { PROFILE_EVENTS } from "./profile-tables";
const DOCUMENT_ID = 1;
const MAX_ANIM_BATCH_BYTES = 4 * 1024 * 1024;
const EVENT_TYPES = PROFILE_EVENTS;
function resolvePolicy(policy) {
  return policy === "compat" ? "compat" : "strict";
}
const LIMIT_DEFAULTS = {
  memoryLimitBytes: 8 * 1024 * 1024,
  cpuLimitMs: 500,
  cpuQuotaMs: 300,
  cpuQuotaWindowMs: 1e3,
  cpuKillAfterMs: 0,
  /** The host's main-thread work for the widget per `cpuQuotaWindowMs`: layout queries and the modelled cost of its ops. */
  mainThreadQuotaMs: 100,
  maxTimers: 64
};
const MAX_TIMER_DELAY_MS = 864e5;
const WASM_PAGE_BYTES = 65536;
const WASM_INITIAL_PAGES = 16 * 1024 * 1024 / WASM_PAGE_BYTES;
const SAB_SIZE = 16 * 1024 * 1024;
const SAB_HEADER = 16;
const SAB_STATE = 0;
const SAB_JSON_LEN = 1;
const SAB_BIN_LEN = 2;
export {
  DOCUMENT_ID,
  EVENT_TYPES,
  LIMIT_DEFAULTS,
  MAX_ANIM_BATCH_BYTES,
  MAX_TIMER_DELAY_MS,
  SAB_BIN_LEN,
  SAB_HEADER,
  SAB_JSON_LEN,
  SAB_SIZE,
  SAB_STATE,
  WASM_INITIAL_PAGES,
  WASM_PAGE_BYTES,
  resolvePolicy
};
