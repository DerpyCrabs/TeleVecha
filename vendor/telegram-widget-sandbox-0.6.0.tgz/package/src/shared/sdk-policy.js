const MAX_LINK_LENGTH = 256;
const STORAGE_QUOTA_BYTES = 4096;
const MAX_LOCALE_LENGTH = 35;
const DEFAULT_LOCALE = "en-US";
const HAPTIC_BURST = 5;
const HAPTIC_PER_SECOND = 10;
const HAPTIC_REPORT_MS = 1e3;
const HAPTIC_TOUCH_WINDOW_MS = 5e3;
const HAPTIC_SERIES_MS = 1e3;
const HAPTIC_SERIES_GAP_MS = 1e4;
const HAPTIC_PRESS_MAX_MS = 3e4;
const MAX_HANDLERS_PER_EVENT = 16;
const THEME_KEYS = [
  "bg_color",
  "text_color",
  "hint_color",
  "link_color",
  "button_color",
  "button_text_color",
  "secondary_bg_color",
  "accent_text_color",
  "subtitle_text_color",
  "destructive_text_color",
  "section_bg_color",
  "section_header_text_color",
  "section_separator_color",
  "header_bg_color",
  "bottom_bar_bg_color"
];
const HAPTIC_IMPACT_STYLES = ["light", "medium", "heavy", "rigid", "soft"];
const HAPTIC_NOTIFICATION_TYPES = ["error", "success", "warning"];
const TELEGRAM_HOSTS = ["t.me", "telegram.me", "telegram.dog"];
const RESIZE_ANCHORS = ["top", "bottom"];
const DEFAULT_RESIZE_ANCHOR = "top";
const MAX_WIDGET_DATA_BYTES = 1024;
const MAX_REQUEST_DATA_BYTES = 64;
const MAX_REQUEST_RESULT_BYTES = 1024;
const MAX_COPY_TEXT_LENGTH = 256;
const BACKGROUND_REQUEST_INTERVAL_MS = 5e3;
const MAX_REQUEST_ID = 2147483647;
const MAX_VIEWER_ID = 9007199254740991;
const MAX_VIEWER_NAME_LENGTH = 64;
const VIEWER_USERNAME = /^[A-Za-z0-9_]{5,32}$/;
const CHAT_TYPES = ["private", "group", "supergroup", "channel"];
const REQUEST_ERRORS = ["NOT_ALLOWED", "BUSY", "RATE_LIMITED", "TIMEOUT", "FAILED", "INVALID_ANSWER", "REJECTED", "BAD_REQUEST"];
const PRIVILEGED_METHODS = /* @__PURE__ */ new Set(["openLink", "openTelegramLink", "copyText"]);
const PREVIEW_METHODS = /* @__PURE__ */ new Set(["ready", "setResizeAnchor"]);
function allowedInPreview(method) {
  return typeof method === "string" && PREVIEW_METHODS.has(method);
}
function utf8Length(s) {
  let n = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 128) n += 1;
    else if (c < 2048) n += 2;
    else if (c >= 55296 && c <= 56319 && i + 1 < s.length && (s.charCodeAt(i + 1) & 64512) === 56320) {
      n += 4;
      i++;
    } else n += 3;
  }
  return n;
}
const HEX = "0123456789ABCDEF";
const isHex = (c) => c >= 48 && c <= 57 || c >= 65 && c <= 70 || c >= 97 && c <= 102;
const URL_ASCII = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~:/?#[]@!$&'()*+,;=%";
const asciiLower = (s) => s.replace(/[A-Z]/g, (c) => String.fromCharCode(c.charCodeAt(0) + 32));
const isTelegramHost = (host) => TELEGRAM_HOSTS.some((t) => host === t || host.endsWith("." + t));
function checkLink(method, url) {
  if (typeof url !== "string" || utf8Length(url) > MAX_LINK_LENGTH) return null;
  if (asciiLower(url.slice(0, 8)) !== "https://") return null;
  let end = 8;
  while (end < url.length && url[end] !== "/" && url[end] !== "?" && url[end] !== "#") end++;
  const authority = url.slice(8, end);
  if (authority.includes("@")) return null;
  const colon = authority.indexOf(":");
  const host = asciiLower(colon < 0 ? authority : authority.slice(0, colon));
  const port = colon < 0 ? null : authority.slice(colon + 1);
  if (port !== null && !/^[0-9]{1,5}$/.test(port)) return null;
  if (port !== null && Number(port) > 65535) return null;
  if (host.length === 0 || host.length > 253) return null;
  for (const label of host.split(".")) {
    if (label.length === 0 || label.length > 63 || !/^[a-z0-9-]+$/.test(label) || label[0] === "-" || label[label.length - 1] === "-") return null;
  }
  if (isTelegramHost(host) !== (method === "openTelegramLink")) return null;
  let rest = "";
  for (let i = end; i < url.length; i++) {
    const c = url.charCodeAt(i);
    if (c < 128) {
      if (!URL_ASCII.includes(url[i])) return null;
      if (c === 37 && !(i + 2 < url.length && isHex(url.charCodeAt(i + 1)) && isHex(url.charCodeAt(i + 2)))) return null;
      rest += url[i];
      continue;
    }
    let cp = c;
    if (c >= 55296 && c <= 56319 && i + 1 < url.length && (url.charCodeAt(i + 1) & 64512) === 56320) cp = 65536 + (c - 55296 << 10) + (url.charCodeAt(++i) - 56320);
    else if (c >= 55296 && c <= 57343) return null;
    const bytes = cp < 2048 ? [192 | cp >> 6, 128 | cp & 63] : cp < 65536 ? [224 | cp >> 12, 128 | cp >> 6 & 63, 128 | cp & 63] : [240 | cp >> 18, 128 | cp >> 12 & 63, 128 | cp >> 6 & 63, 128 | cp & 63];
    for (const b of bytes) rest += "%" + HEX[b >> 4] + HEX[b & 15];
  }
  const out = "https://" + host + (port === null ? "" : ":" + port) + rest;
  return out.length > MAX_LINK_LENGTH ? null : out;
}
function checkHaptic(args) {
  if (!Array.isArray(args)) return null;
  if (args[0] === "impact" && args.length === 2 && HAPTIC_IMPACT_STYLES.includes(args[1])) return { haptic: "impact", value: args[1] };
  if (args[0] === "notification" && args.length === 2 && HAPTIC_NOTIFICATION_TYPES.includes(args[1])) return { haptic: "notification", value: args[1] };
  if (args[0] === "selection" && args.length === 1) return { haptic: "selection" };
  return null;
}
function checkResizeAnchor(edge) {
  return edge === "top" || edge === "bottom" ? edge : null;
}
function checkBridgeCall(method, args) {
  if (!Array.isArray(args)) return null;
  switch (method) {
    case "ready":
      return args.length === 0 ? { kind: "ready" } : null;
    case "openLink":
    case "openTelegramLink": {
      const url = args.length === 1 ? checkLink(method, args[0]) : null;
      return url === null ? null : { kind: method, url };
    }
    case "haptic": {
      const h = checkHaptic(args);
      return h === null ? null : { kind: "haptic", ...h };
    }
    case "setResizeAnchor": {
      const edge = args.length === 1 ? checkResizeAnchor(args[0]) : null;
      return edge === null ? null : { kind: "setResizeAnchor", edge };
    }
    case "watchPublicData":
      return args.length === 1 && typeof args[0] === "boolean" ? { kind: "watchPublicData", on: args[0] } : null;
    case "request": {
      const id = args[0];
      const data = args.length === 2 || args.length === 3 ? checkRequestData(args[1]) : null;
      const options = args.length === 3 ? checkRequestOptions(args[2]) : { wallet: false };
      if (data === null || options === null || !isRequestId(id)) return null;
      return options.wallet ? { kind: "request", id, data, wallet: true } : { kind: "request", id, data };
    }
    case "wallet": {
      const [id, name, arg, label] = args;
      const data = args.length === 4 ? checkRequestData(label) : null;
      if (data === null || !isRequestId(id)) return null;
      if (name === "sendTransaction") {
        const transaction = checkWalletTransaction(arg);
        return transaction === null ? null : { kind: "wallet", id, call: { method: "sendTransaction", transaction, data } };
      }
      if (name === "signData") {
        const payload = checkSignDataPayload(arg);
        return payload === null ? null : { kind: "wallet", id, call: { method: "signData", payload, data } };
      }
      return null;
    }
    case "copyText": {
      const text = args.length === 1 ? checkCopyText(args[0]) : null;
      return text === null ? null : { kind: "copyText", text };
    }
    default:
      return null;
  }
}
function wellFormed(s) {
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 55296 || c > 57343) continue;
    if (c > 56319 || i + 1 >= s.length || (s.charCodeAt(i + 1) & 64512) !== 56320) return false;
    i++;
  }
  return true;
}
function checkRequestData(data) {
  if (typeof data !== "string" || !wellFormed(data)) return null;
  const n = utf8Length(data);
  return n >= 1 && n <= MAX_REQUEST_DATA_BYTES ? data : null;
}
const isRequestId = (id) => typeof id === "number" && Number.isInteger(id) && id >= 1 && id <= MAX_REQUEST_ID;
function checkRequestOptions(options) {
  if (!isPlainObject(options) || !onlyKeys(options, ["wallet"])) return null;
  const w = options.wallet;
  return w === void 0 || w === null ? { wallet: false } : typeof w === "boolean" ? { wallet: w } : null;
}
function checkCopyText(text) {
  return typeof text === "string" && text.length >= 1 && text.length <= MAX_COPY_TEXT_LENGTH && wellFormed(text) ? text : null;
}
function checkWidgetDataValue(value) {
  return typeof value === "string" && value.length > 0 && wellFormed(value) && !value.includes("\0") && utf8Length(value) <= MAX_WIDGET_DATA_BYTES ? value : null;
}
function checkWidgetData(data, copy) {
  const d = typeof data === "object" && data !== null ? data : {};
  const out = { chatData: null, publicData: null, rejected: [] };
  for (const field of ["chatData", "publicData"]) {
    const v = d[field];
    if (field === "chatData" && copy) continue;
    out[field] = checkWidgetDataValue(v);
    if (out[field] === null && v !== void 0 && v !== null && v !== "") out.rejected.push(field);
  }
  return out;
}
function checkViewer(viewer) {
  const v = typeof viewer === "object" && viewer !== null ? viewer : {};
  const id = v.id;
  if (typeof id !== "number" || !Number.isInteger(id) || id < 1 || id > MAX_VIEWER_ID) return { viewer: null, rejected: [] };
  const out = { id };
  const rejected = [];
  const name = (s) => typeof s === "string" && s.length >= 1 && s.length <= MAX_VIEWER_NAME_LENGTH && wellFormed(s);
  for (const field of ["first_name", "last_name"]) {
    const s = v[field];
    if (s === void 0 || s === null) continue;
    if (name(s)) out[field] = s;
    else rejected.push(field);
  }
  if (v.username !== void 0 && v.username !== null) {
    if (typeof v.username === "string" && VIEWER_USERNAME.test(v.username)) out.username = v.username;
    else rejected.push("username");
  }
  if (v.is_premium !== void 0 && v.is_premium !== null) {
    if (v.is_premium === true) out.is_premium = true;
    else if (v.is_premium !== false) rejected.push("is_premium");
  }
  return { viewer: out, rejected };
}
const VIEWER_FIELD_RULES = {
  first_name: "not text of 1\u201364 UTF-16 code units",
  last_name: "not text of 1\u201364 UTF-16 code units",
  username: "not 5\u201332 characters of A\u2013Z, a\u2013z, 0\u20139 and _",
  is_premium: "not a boolean"
};
function viewerUser(viewer) {
  if (typeof viewer !== "object" || viewer === null) return null;
  return { id: viewer.id, first_name: viewer.firstName, last_name: viewer.lastName, username: viewer.username, is_premium: viewer.isPremium };
}
function checkChatType(chatType) {
  return CHAT_TYPES.includes(chatType) ? chatType : null;
}
function checkRequestAnswer(answer) {
  const r = typeof answer === "object" && answer !== null ? answer.result : void 0;
  if (r === void 0 || r === null) return { result: null };
  return typeof r === "string" && wellFormed(r) && !r.includes("\0") && utf8Length(r) <= MAX_REQUEST_RESULT_BYTES ? { result: r } : null;
}
function requestFailure(reason) {
  const code = typeof reason === "object" && reason !== null ? reason.code : reason;
  return code === "TIMEOUT" || code === "RATE_LIMITED" ? code : "FAILED";
}
function walletFailure(reason) {
  const code = typeof reason === "object" && reason !== null ? reason.code : reason;
  return code === "REJECTED" || code === "BAD_REQUEST" ? code : requestFailure(code);
}
const MAX_WALLET_MESSAGES = 255;
const MAX_WALLET_BOC_LENGTH = 8192;
const MAX_WALLET_BOC_TOTAL = 65536;
const MAX_SIGN_DATA_LENGTH = 4096;
const MAX_SIGN_DATA_SCHEMA_BYTES = 1024;
const WALLET_GRANT_MS = 1e4;
const WALLET_NETWORKS = ["-239", "-3"];
const isPlainObject = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
const onlyKeys = (o, keys) => Object.keys(o).every((k) => keys.includes(k));
const absent = (v) => v === void 0 || v === null;
const RAW_ADDRESS = /^(0|-1):[0-9a-fA-F]{64}$/;
const FRIENDLY_ADDRESS = /^[A-Za-z0-9+/_-]{48}$/;
const AMOUNT = /^(0|[1-9][0-9]{0,36})$/;
const BASE64 = /^[A-Za-z0-9+/_-]+={0,2}$/;
function checkWalletAddress(address) {
  return typeof address === "string" && (RAW_ADDRESS.test(address) || FRIENDLY_ADDRESS.test(address)) ? address : null;
}
function checkWalletDestination(address) {
  return typeof address === "string" && FRIENDLY_ADDRESS.test(address) ? address : null;
}
const base64 = (v, max) => typeof v === "string" && v.length <= max && BASE64.test(v);
function walletTarget(input, out) {
  if (!absent(input.network)) {
    if (!WALLET_NETWORKS.includes(input.network)) return false;
    out.network = input.network;
  }
  if (!absent(input.from)) {
    const from = checkWalletAddress(input.from);
    if (from === null) return false;
    out.from = from;
  }
  return true;
}
function checkWalletTransaction(tx) {
  if (!isPlainObject(tx) || !onlyKeys(tx, ["valid_until", "network", "from", "messages"])) return null;
  const out = { messages: [] };
  if (!absent(tx.valid_until)) {
    const v = tx.valid_until;
    if (typeof v !== "number" || !Number.isInteger(v) || v < 1 || v > 4294967295) return null;
    out.valid_until = v;
  }
  if (!walletTarget(tx, out)) return null;
  const messages = tx.messages;
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > MAX_WALLET_MESSAGES) return null;
  let total = 0;
  for (const m of messages) {
    if (!isPlainObject(m) || !onlyKeys(m, ["address", "amount", "payload", "stateInit"])) return null;
    const address = checkWalletDestination(m.address);
    if (address === null || typeof m.amount !== "string" || !AMOUNT.test(m.amount)) return null;
    const message = { address, amount: m.amount };
    for (const field of ["payload", "stateInit"]) {
      if (absent(m[field])) continue;
      if (!base64(m[field], MAX_WALLET_BOC_LENGTH)) return null;
      message[field] = m[field];
      total += m[field].length;
    }
    out.messages.push(message);
  }
  return total <= MAX_WALLET_BOC_TOTAL ? out : null;
}
const signText = (v, max) => typeof v === "string" && v.length > 0 && wellFormed(v) && !v.includes("\0") && utf8Length(v) <= max;
function checkSignDataPayload(payload) {
  if (!isPlainObject(payload)) return null;
  const common = ["type", "network", "from"];
  let out;
  switch (payload.type) {
    case "text":
      if (!onlyKeys(payload, [...common, "text"]) || !signText(payload.text, MAX_SIGN_DATA_LENGTH)) return null;
      out = { type: "text", text: payload.text };
      break;
    case "binary":
      if (!onlyKeys(payload, [...common, "bytes"]) || !base64(payload.bytes, MAX_SIGN_DATA_LENGTH)) return null;
      out = { type: "binary", bytes: payload.bytes };
      break;
    case "cell":
      if (!onlyKeys(payload, [...common, "schema", "cell"]) || !signText(payload.schema, MAX_SIGN_DATA_SCHEMA_BYTES) || !base64(payload.cell, MAX_SIGN_DATA_LENGTH)) return null;
      out = { type: "cell", schema: payload.schema, cell: payload.cell };
      break;
    default:
      return null;
  }
  return walletTarget(payload, out) ? out : null;
}
function requestRefusal(verdict) {
  switch (verdict) {
    case "foreground":
    case "background":
    case "held":
    case "granted":
      return null;
    case "busy":
      return "BUSY";
    case "rate-limited":
      return "RATE_LIMITED";
    default:
      return "NOT_ALLOWED";
  }
}
class RequestGate {
  inFlight = false;
  held = false;
  lastBackground = null;
  /** The call in flight went out on a press or the grant: its answer grants one wallet call. */
  granting = false;
  grantAt = null;
  get busy() {
    return this.inFlight;
  }
  decide(now, s) {
    if (!s.canQuery) return "disabled";
    if (s.withWallet && !s.wallet) return "no-wallet";
    if (this.inFlight) return "busy";
    if (s.gesture && s.visible) return this.out("foreground");
    if (!s.backgroundQuery || s.withWallet) return "no-activation";
    if (!s.visible) {
      this.inFlight = this.held = true;
      return "held";
    }
    if (this.lastBackground !== null && now - this.lastBackground < BACKGROUND_REQUEST_INTERVAL_MS) return "rate-limited";
    this.lastBackground = now;
    this.inFlight = true;
    return "background";
  }
  /** A wallet call (`sendTransaction`, `signData`): on a press, or on the grant within 10 s of its answer. */
  decideWallet(now, s) {
    if (!s.canQuery) return "disabled";
    if (!s.wallet) return "no-wallet";
    if (this.inFlight) return "busy";
    if (s.gesture && s.visible) return this.out("foreground");
    if (s.visible && this.grantAt !== null && now - this.grantAt <= WALLET_GRANT_MS) return this.out("granted");
    return "no-activation";
  }
  out(verdict) {
    this.inFlight = this.granting = true;
    this.grantAt = null;
    return verdict;
  }
  finish(answeredAt) {
    if (this.granting && answeredAt !== void 0) this.grantAt = answeredAt;
    this.inFlight = this.held = this.granting = false;
  }
  /**
   * The widget appeared on screen (it was hidden): its next background request may go out at once. True when a held
   * request goes out now, as this appearance's background request (the glue sends it; it stays in flight).
   */
  show(now) {
    this.lastBackground = null;
    if (!this.held) return false;
    this.held = false;
    this.lastBackground = now;
    return true;
  }
}
class HapticGate {
  tokens = HAPTIC_BURST;
  last = null;
  reported = null;
  /** A press is on since then. */
  down = null;
  /** The last press ended then. */
  lifted = null;
  /** The last series (haptics outside a touch) began then. */
  series = null;
  /** A finger or a mouse button went down on the widget (trusted input only). */
  press(now) {
    this.down = now;
  }
  /** The press ended: the finger was lifted or the press was cancelled. */
  release(now) {
    this.down = null;
    this.lifted = now;
  }
  decide(now, visible) {
    if (this.last !== null) this.tokens = Math.min(HAPTIC_BURST, this.tokens + Math.max(0, now - this.last) * HAPTIC_PER_SECOND / 1e3);
    this.last = now;
    if (this.down !== null && now - this.down > HAPTIC_PRESS_MAX_MS) this.release(this.down + HAPTIC_PRESS_MAX_MS);
    const touching = this.down !== null || this.lifted !== null && now - this.lifted <= HAPTIC_TOUCH_WINDOW_MS;
    let allowed = visible;
    if (allowed && !touching && !(this.series !== null && now - this.series < HAPTIC_SERIES_MS)) {
      const touchedSince = this.lifted !== null && (this.series === null || this.lifted > this.series);
      if (this.series === null || touchedSince || now - this.series >= HAPTIC_SERIES_GAP_MS) this.series = now;
      else allowed = false;
    }
    if (allowed && this.tokens >= 1) {
      this.tokens -= 1;
      return "play";
    }
    if (this.reported !== null && now - this.reported < HAPTIC_REPORT_MS) return "drop";
    this.reported = now;
    return "report";
  }
}
function checkThemeParams(params) {
  const out = {};
  if (typeof params !== "object" || params === null || Array.isArray(params)) return out;
  for (const key of THEME_KEYS) {
    const v = params[key];
    if (typeof v === "string" && /^#[0-9a-fA-F]{6}$/.test(v)) out[key] = v.toLowerCase();
  }
  return out;
}
function checkLocale(locale) {
  if (typeof locale !== "string" || locale.length === 0 || locale.length > MAX_LOCALE_LENGTH) return null;
  return /^[A-Za-z]{2,8}(-[A-Za-z0-9]{1,8})*$/.test(locale) ? locale : null;
}
function storageBytes(area) {
  let n = 0;
  for (const k of Object.keys(area)) n += utf8Length(k) + utf8Length(area[k]);
  return n;
}
function checkStorageArea(area) {
  if (typeof area !== "object" || area === null || Array.isArray(area)) return null;
  const out = {};
  for (const k of Object.keys(area)) {
    const v = area[k];
    if (typeof v !== "string") return null;
    Object.defineProperty(out, k, { value: v, enumerable: true, writable: true, configurable: true });
  }
  return storageBytes(out) <= STORAGE_QUOTA_BYTES ? out : null;
}
function checkStorageCommit(commit) {
  if (typeof commit !== "object" || commit === null || Array.isArray(commit)) return null;
  const out = {};
  for (const k of Object.keys(commit)) {
    if (k !== "local" && k !== "session") return null;
    const area = checkStorageArea(commit[k]);
    if (area === null) return null;
    out[k] = area;
  }
  return out;
}
const WIDGET_MESSAGE_KINDS = {
  /** The original in the private chat with the bot that sent it. */
  private: { isCopy: false, canQuery: true, backgroundQuery: true, chatType: "private" },
  /** An original the bot sent to a group (or a supergroup) it is a member of. */
  group: { isCopy: false, canQuery: true, backgroundQuery: false, chatType: "group" },
  /** An original sent via the bot (inline mode), here in a private chat between two users. */
  "via-bot": { isCopy: false, canQuery: true, backgroundQuery: false, chatType: "private" },
  /** An original the bot sent without `allow_queries` (here in its private chat): no requests anywhere, no network marker. */
  "no-queries": { isCopy: false, canQuery: false, backgroundQuery: false, chatType: "private" },
  /** A forwarded copy of a widget the bot sent with `fwd_allow_queries` (and so `allow_queries`). */
  "live-copy": { isCopy: true, canQuery: true, backgroundQuery: false, chatType: "private" },
  /** A forwarded copy of a widget sent without `fwd_allow_queries`. */
  copy: { isCopy: true, canQuery: false, backgroundQuery: false, chatType: "private" },
  /** An inline result in the list, before it is sent: data, no input, nothing about the user. */
  preview: { isCopy: false, canQuery: false, backgroundQuery: false, chatType: "private", preview: true }
};
function viewerFromList(list) {
  const [id, firstName, lastName, username, premium] = list.split(",").map((s) => s.trim());
  if (!id || !(Number(id) > 0)) return null;
  return {
    id: Number(id),
    ...firstName ? { firstName } : {},
    ...lastName ? { lastName } : {},
    ...username ? { username } : {},
    ...premium ? { isPremium: ["1", "true", "premium"].includes(premium) } : {}
  };
}
const DEFAULT_THEME_PARAMS = {
  light: {
    bg_color: "#ffffff",
    text_color: "#000000",
    hint_color: "#707579",
    link_color: "#3390ec",
    button_color: "#3390ec",
    button_text_color: "#ffffff",
    secondary_bg_color: "#f4f4f5",
    accent_text_color: "#3390ec",
    subtitle_text_color: "#707579",
    destructive_text_color: "#e53935",
    section_bg_color: "#ffffff",
    section_header_text_color: "#3390ec",
    section_separator_color: "#e7e7e7",
    header_bg_color: "#ffffff",
    bottom_bar_bg_color: "#ffffff"
  },
  dark: {
    bg_color: "#212121",
    text_color: "#ffffff",
    hint_color: "#aaaaaa",
    link_color: "#8774e1",
    button_color: "#8774e1",
    button_text_color: "#ffffff",
    secondary_bg_color: "#181818",
    accent_text_color: "#8774e1",
    subtitle_text_color: "#aaaaaa",
    destructive_text_color: "#ff595a",
    section_bg_color: "#212121",
    section_header_text_color: "#8774e1",
    section_separator_color: "#3d3d3d",
    header_bg_color: "#212121",
    bottom_bar_bg_color: "#212121"
  }
};
function completeThemeParams(params, scheme) {
  return { ...DEFAULT_THEME_PARAMS[scheme], ...checkThemeParams(params) };
}
const DEFAULT_TEXT_TOKENS = { fontSize: "15px", lineHeight: "1.35", padding: "8px 12px" };
const LENGTH = /^(0|[0-9]{1,4}(\.[0-9]{1,3})?(px|em|rem))$/;
const COLOR = /^#[0-9a-fA-F]{6}$/;
const GENERIC = /* @__PURE__ */ new Set(["system-ui", "sans-serif", "serif", "monospace", "ui-sans-serif", "ui-serif", "ui-monospace", "ui-rounded"]);
const FONT = /^(?:(normal|italic) )?(?:(normal|bold|[1-9]00) )?[0-9]{1,3}(?:\.[0-9]{1,2})?(?:px|em|rem)(?:\/[0-9]{1,3}(?:\.[0-9]{1,2})?(?:px|em|rem)?)? ([a-z-]+(?:, ?[a-z-]+)*)$/;
function opacity(v) {
  const s = typeof v === "number" ? String(v) : typeof v === "string" ? v : "";
  return /^(0(\.[0-9]{1,3})?|1(\.0{1,3})?|\.[0-9]{1,3})$/.test(s) ? s : null;
}
const padding = (v) => typeof v === "string" && /^\S+( \S+){0,3}$/.test(v) && v.split(" ").every((p) => LENGTH.test(p)) ? v : null;
function bounded(v, min, max, decimals, unit) {
  let n;
  if (typeof v === "number") n = v;
  else if (typeof v === "string" && new RegExp(`^[0-9]{1,2}(\\.[0-9]{1,${decimals}})?${unit}$`).test(v)) n = parseFloat(v);
  else return null;
  if (!Number.isFinite(n) || n < min || n > max) return null;
  const f = 10 ** decimals;
  return String(Math.round(n * f) / f) + unit;
}
const BUTTON_VARS = [
  ["bg", "--tg-button-bg", (v) => typeof v === "string" && COLOR.test(v) ? v.toLowerCase() : null],
  ["text", "--tg-button-text", (v) => typeof v === "string" && COLOR.test(v) ? v.toLowerCase() : null],
  ["radius", "--tg-button-radius", (v) => typeof v === "string" && LENGTH.test(v) ? v : null],
  ["font", "--tg-button-font", (v) => {
    const m = typeof v === "string" ? FONT.exec(v) : null;
    return m && m[3].split(",").every((f) => GENERIC.has(f.trim())) ? v : null;
  }],
  ["padding", "--tg-button-padding", padding],
  ["height", "--tg-button-height", (v) => typeof v === "string" && LENGTH.test(v) ? v : null],
  ["pressedOpacity", "--tg-button-pressed-opacity", opacity],
  ["disabledOpacity", "--tg-button-disabled-opacity", opacity]
];
const TEXT_VARS = [
  ["fontSize", "--tg-text-font-size", (v) => bounded(v, 8, 64, 2, "px")],
  ["lineHeight", "--tg-text-line-height", (v) => bounded(v, 1, 3, 3, "")],
  ["padding", "--tg-text-padding", padding]
];
const CONTENT_SAFE_AREA_FIELDS = ["top", "right", "bottom", "left", "cornerLeft", "cornerRight"];
const MAX_SAFE_AREA_INSET = 64;
const MAX_SAFE_AREA_CORNER = 200;
const NO_CONTENT_SAFE_AREA = Object.freeze({ top: 0, right: 0, bottom: 0, left: 0, cornerLeft: 0, cornerRight: 0 });
function checkContentSafeArea(area) {
  const a = typeof area === "object" && area !== null ? area : {};
  const out = { ...NO_CONTENT_SAFE_AREA };
  for (const field of CONTENT_SAFE_AREA_FIELDS) {
    const v = a[field];
    const max = field.startsWith("corner") ? MAX_SAFE_AREA_CORNER : MAX_SAFE_AREA_INSET;
    if (typeof v === "number" && Number.isFinite(v) && v >= 0 && v <= max) out[field] = Math.round(v * 100) / 100;
  }
  return out;
}
const SAFE_AREA_VARS = [
  ["top", "--tg-content-safe-area-inset-top"],
  ["right", "--tg-content-safe-area-inset-right"],
  ["bottom", "--tg-content-safe-area-inset-bottom"],
  ["left", "--tg-content-safe-area-inset-left"],
  ["cornerLeft", "--tg-content-safe-area-corner-left"],
  ["cornerRight", "--tg-content-safe-area-corner-right"]
];
const SAFE_AREA_ENV_VARIABLES = Object.freeze({
  "safe-area-inset-top": "--tg-content-safe-area-inset-top",
  "safe-area-inset-right": "--tg-content-safe-area-inset-right",
  "safe-area-inset-bottom": "--tg-content-safe-area-inset-bottom",
  "safe-area-inset-left": "--tg-content-safe-area-inset-left"
});
function contentSafeAreaVariables(area) {
  const a = checkContentSafeArea(area);
  const vars = {};
  for (const [field, name] of SAFE_AREA_VARS) vars[name] = a[field] + "px";
  return vars;
}
const THEME_VARIABLES = [
  ...THEME_KEYS.map((k) => "--tg-theme-" + k.replace(/_/g, "-")),
  "--tg-color-scheme",
  ...BUTTON_VARS.map(([, name]) => name),
  ...TEXT_VARS.map(([, name]) => name),
  ...SAFE_AREA_VARS.map(([, name]) => name)
];
function themeVariables(theme) {
  const t = typeof theme === "object" && theme !== null ? theme : {};
  const scheme = t.colorScheme === "dark" ? "dark" : "light";
  const params = completeThemeParams(t.params, scheme);
  const vars = {};
  for (const k of THEME_KEYS) vars["--tg-theme-" + k.replace(/_/g, "-")] = params[k];
  vars["--tg-color-scheme"] = scheme;
  const button = typeof t.button === "object" && t.button !== null ? t.button : {};
  for (const [field, name, check] of BUTTON_VARS) {
    const v = check(button[field]);
    if (v !== null) vars[name] = v;
  }
  const text = typeof t.text === "object" && t.text !== null ? t.text : {};
  for (const [field, name, check] of TEXT_VARS) vars[name] = check(text[field]) ?? DEFAULT_TEXT_TOKENS[field];
  return vars;
}
function toWidgetTheme(theme) {
  if (theme === "light" || theme === "dark") return { colorScheme: theme, params: {} };
  const t = typeof theme === "object" && theme !== null ? theme : {};
  const button = typeof t.button === "object" && t.button !== null ? t.button : void 0;
  const text = typeof t.text === "object" && t.text !== null ? t.text : void 0;
  return { colorScheme: t.colorScheme === "dark" ? "dark" : "light", params: checkThemeParams(t.params), ...button ? { button } : {}, ...text ? { text } : {} };
}
export {
  BACKGROUND_REQUEST_INTERVAL_MS,
  CHAT_TYPES,
  CONTENT_SAFE_AREA_FIELDS,
  DEFAULT_LOCALE,
  DEFAULT_RESIZE_ANCHOR,
  DEFAULT_TEXT_TOKENS,
  DEFAULT_THEME_PARAMS,
  HAPTIC_BURST,
  HAPTIC_IMPACT_STYLES,
  HAPTIC_NOTIFICATION_TYPES,
  HAPTIC_PER_SECOND,
  HAPTIC_PRESS_MAX_MS,
  HAPTIC_REPORT_MS,
  HAPTIC_SERIES_GAP_MS,
  HAPTIC_SERIES_MS,
  HAPTIC_TOUCH_WINDOW_MS,
  HapticGate,
  MAX_COPY_TEXT_LENGTH,
  MAX_HANDLERS_PER_EVENT,
  MAX_LINK_LENGTH,
  MAX_LOCALE_LENGTH,
  MAX_REQUEST_DATA_BYTES,
  MAX_REQUEST_ID,
  MAX_REQUEST_RESULT_BYTES,
  MAX_SAFE_AREA_CORNER,
  MAX_SAFE_AREA_INSET,
  MAX_SIGN_DATA_LENGTH,
  MAX_SIGN_DATA_SCHEMA_BYTES,
  MAX_VIEWER_ID,
  MAX_VIEWER_NAME_LENGTH,
  MAX_WALLET_BOC_LENGTH,
  MAX_WALLET_BOC_TOTAL,
  MAX_WALLET_MESSAGES,
  MAX_WIDGET_DATA_BYTES,
  NO_CONTENT_SAFE_AREA,
  PREVIEW_METHODS,
  PRIVILEGED_METHODS,
  REQUEST_ERRORS,
  RESIZE_ANCHORS,
  RequestGate,
  SAFE_AREA_ENV_VARIABLES,
  STORAGE_QUOTA_BYTES,
  TELEGRAM_HOSTS,
  THEME_KEYS,
  THEME_VARIABLES,
  VIEWER_FIELD_RULES,
  VIEWER_USERNAME,
  WALLET_GRANT_MS,
  WALLET_NETWORKS,
  WIDGET_MESSAGE_KINDS,
  allowedInPreview,
  checkBridgeCall,
  checkChatType,
  checkContentSafeArea,
  checkCopyText,
  checkHaptic,
  checkLink,
  checkLocale,
  checkRequestAnswer,
  checkRequestData,
  checkRequestOptions,
  checkResizeAnchor,
  checkSignDataPayload,
  checkStorageArea,
  checkStorageCommit,
  checkThemeParams,
  checkViewer,
  checkWalletAddress,
  checkWalletDestination,
  checkWalletTransaction,
  checkWidgetData,
  checkWidgetDataValue,
  completeThemeParams,
  contentSafeAreaVariables,
  requestFailure,
  requestRefusal,
  storageBytes,
  themeVariables,
  toWidgetTheme,
  utf8Length,
  viewerFromList,
  viewerUser,
  walletFailure
};
