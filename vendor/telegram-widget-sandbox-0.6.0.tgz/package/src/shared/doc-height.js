function measureDocHeight(doc) {
  return Math.ceil(doc.documentElement.getBoundingClientRect().height);
}
export {
  measureDocHeight
};
