import { PROFILE_CSS, PROFILE_IMAGES } from "./profile-tables";
import { SAFE_AREA_ENV_VARIABLES } from "./sdk-policy";
const CSS = PROFILE_CSS;
const PROPERTIES = new Set(CSS.properties);
const FUNCTIONS = new Set(CSS.functions);
const UNITS = new Set(CSS.units);
const FILTER_FUNCTIONS = new Set(CSS.filterFunctions);
const TRANSFORM_3D = new Set(CSS.transform3d);
const GENERIC_FONTS = new Set(CSS.fonts.generic);
const PSEUDO_CLASSES = /* @__PURE__ */ new Set([...CSS.pseudoClasses, ...Object.keys(CSS.pseudoRewrite)]);
const PSEUDO_ELEMENTS = new Set(CSS.pseudoElements);
const VALUES = CSS.values;
const REWRITE = CSS.rewrite;
const GLOBAL_KEYWORDS = /* @__PURE__ */ new Set(["inherit", "initial", "unset", "revert", "revert-layer"]);
const FONT_SIZE_KEYWORDS = /* @__PURE__ */ new Set(["xx-small", "x-small", "small", "medium", "large", "x-large", "xx-large", "xxx-large", "smaller", "larger"]);
const OVERFLOW = /* @__PURE__ */ new Set(["overflow", "overflow-x", "overflow-y"]);
const IMAGE_URL = new RegExp("^(?:#|data:(?:" + PROFILE_IMAGES.map((m) => m.replace(/[+.]/g, "\\$&")).join("|") + ")[;,])", "i");
function cssPropertyInProfile(name) {
  const p = name.toLowerCase();
  return p.startsWith("--") || PROPERTIES.has(p);
}
const cssFunctionInProfile = (name) => FUNCTIONS.has(name.toLowerCase());
const cssUnitInProfile = (unit) => UNITS.has(unit.toLowerCase());
const cssPseudoClassInProfile = (name) => PSEUDO_CLASSES.has(name.toLowerCase());
const cssPseudoElementInProfile = (name) => PSEUDO_ELEMENTS.has(name.toLowerCase());
const isGenericFont = (name) => GENERIC_FONTS.has(name.toLowerCase());
const IDENT_START = /[a-zA-Z_\-\u0080-￿\\]/;
const IDENT_CHAR = /[\w\-\u0080-￿\\]/;
function tokenize(s) {
  let i = 0;
  const readIdent = () => {
    const a = i;
    while (i < s.length && IDENT_CHAR.test(s[i])) i += s[i] === "\\" ? 2 : 1;
    return s.slice(a, i);
  };
  const list = (close) => {
    const out = [];
    while (i < s.length) {
      const c = s[i];
      if (/\s/.test(c)) {
        i++;
        continue;
      }
      if (close && c === close) {
        i++;
        return out;
      }
      if (c === ")" || c === "]" || c === "}" || c === ";" || c === "{") return null;
      if (c === '"' || c === "'") {
        let v = "";
        i++;
        while (i < s.length && s[i] !== c) {
          if (s[i] === "\\") i++;
          v += s[i++] ?? "";
        }
        if (i >= s.length) return null;
        i++;
        out.push({ t: "str", v });
        continue;
      }
      if (c === "#") {
        i++;
        readIdent();
        out.push({ t: "hash" });
        continue;
      }
      const num = /^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(s.slice(i));
      if (num && !(c === "-" && IDENT_START.test(s[i + 1] ?? "") && !/\d/.test(s[i + 1]))) {
        i += num[0].length;
        if (s[i] === "%") {
          i++;
          out.push({ t: "pct" });
        } else if (i < s.length && IDENT_START.test(s[i]) && !(s[i] === "-" && !IDENT_START.test(s[i + 1] ?? ""))) out.push({ t: "dim", unit: readIdent() });
        else out.push({ t: "num" });
        continue;
      }
      if (IDENT_START.test(c) && !(c === "-" && /\d/.test(s[i + 1] ?? ""))) {
        const v = readIdent();
        if (!v) return null;
        if (s[i] === "(") {
          i++;
          if (v.toLowerCase() === "url") {
            const a = i;
            const end = s.indexOf(")", i);
            if (end < 0) return null;
            i = end + 1;
            out.push({ t: "url", v: s.slice(a, end).trim().replace(/^(['"])(.*)\1$/, "$2") });
            continue;
          }
          const args = list(")");
          if (!args) return null;
          out.push({ t: "func", v: v.toLowerCase(), args });
          continue;
        }
        out.push({ t: "ident", v });
        continue;
      }
      if (c === "!") return null;
      out.push({ t: "delim", v: c });
      i++;
    }
    return close ? null : out;
  };
  return list(null);
}
function* deep(toks) {
  for (const t of toks) {
    yield t;
    if (t.t === "func") yield* deep(t.args);
  }
}
const hasVar = (toks) => [...deep(toks)].some((t) => t.t === "func" && (t.v === "var" || t.v === "env" || t.v === "attr"));
function splitCommas(toks) {
  const out = [[]];
  for (const t of toks) {
    if (t.t === "delim" && t.v === ",") out.push([]);
    else out[out.length - 1].push(t);
  }
  return out;
}
function familiesSupported(toks) {
  for (const group of splitCommas(toks)) {
    if (group.length === 0) return false;
    if (group.some((t) => t.t === "func")) continue;
    if (group.length !== 1 || group[0].t !== "ident") return false;
    const name = group[0].v.toLowerCase();
    if (!GENERIC_FONTS.has(name) && !GLOBAL_KEYWORDS.has(name)) return false;
  }
  return true;
}
function fontShorthandFamilyStart(items, kind) {
  for (let i = 0; i < items.length; i++) {
    if (!kind(items[i]).size) continue;
    let j = i + 1;
    if (j < items.length && kind(items[j]).slash) j += 2;
    return j;
  }
  return -1;
}
function tokKind(t) {
  const size = t.t === "dim" || t.t === "pct" || t.t === "ident" && FONT_SIZE_KEYWORDS.has(t.v.toLowerCase()) || t.t === "func" && ["calc", "min", "max", "clamp"].includes(t.v);
  return { size, slash: t.t === "delim" && t.v === "/" };
}
const envSupported = (args) => args[0]?.t === "ident" && Object.prototype.hasOwnProperty.call(SAFE_AREA_ENV_VARIABLES, args[0].v) && (args.length === 1 || args[1].t === "delim" && args[1].v === ",");
function valueTokensSupported(toks) {
  for (const t of deep(toks)) {
    if (t.t === "func" && (!FUNCTIONS.has(t.v) || t.v === "env" && !envSupported(t.args))) return false;
    if (t.t === "dim" && !UNITS.has(t.unit.toLowerCase())) return false;
    if (t.t === "url" && !IMAGE_URL.test(t.v)) return false;
  }
  return true;
}
function supportsDeclaration(property, value) {
  const prop = String(property).trim().toLowerCase();
  const text = String(value).trim();
  if (!prop || !text) return false;
  if (!cssPropertyInProfile(prop)) return false;
  const toks = tokenize(text);
  if (!toks || !toks.length) return false;
  if (!valueTokensSupported(toks)) return false;
  if (prop.startsWith("--")) return true;
  const idents = toks.filter((t) => t.t === "ident").map((t) => t.v.toLowerCase());
  if (toks.length === 1 && idents.length === 1 && GLOBAL_KEYWORDS.has(idents[0])) return true;
  const varUsed = hasVar(toks);
  const allowed = VALUES[prop];
  if (allowed && !varUsed && !(toks.length === 1 && idents.length === 1 && allowed.includes(idents[0]))) return false;
  const rewriteKey = OVERFLOW.has(prop) ? "overflow" : prop;
  if (REWRITE[rewriteKey] && idents.some((v) => Object.prototype.hasOwnProperty.call(REWRITE[rewriteKey], v))) return false;
  if (prop === "background-clip" && idents.includes("text")) return false;
  if (prop === "transform" && [...deep(toks)].some((t) => t.t === "func" && TRANSFORM_3D.has(t.v))) return false;
  if (prop === "rotate" && (idents.some((v) => v === "x" || v === "y" || v === "z") || toks.filter((t) => t.t === "num").length > 1) || (prop === "translate" || prop === "scale") && toks.filter((t) => t.t !== "delim").length > 2) return false;
  if ((prop === "filter" || prop === "backdrop-filter" || prop === "-webkit-backdrop-filter") && toks.some((t) => t.t === "func" && !FILTER_FUNCTIONS.has(t.v) && t.v !== "var" || t.t === "url")) return false;
  if (prop === "font-family" && !varUsed && !familiesSupported(toks)) return false;
  if (prop === "font" && !varUsed) {
    const start = fontShorthandFamilyStart(toks, tokKind);
    if (start >= 0 && !familiesSupported(toks.slice(start))) return false;
  }
  return true;
}
function supportsSelector(selector) {
  const s = String(selector).trim();
  if (!s || s.includes("&") || /[{};]/.test(s)) return false;
  const re = /(::?)(-?[a-zA-Z][\w-]*)/g;
  for (let m; m = re.exec(s.replace(/"[^"]*"|'[^']*'|\[[^\]]*\]/g, "")); ) {
    const ok = m[1] === "::" ? PSEUDO_ELEMENTS.has(m[2].toLowerCase()) : PSEUDO_CLASSES.has(m[2].toLowerCase());
    if (!ok) return false;
  }
  return true;
}
function supportsCondition(text) {
  const s = String(text);
  let i = 0;
  const ws = () => {
    while (i < s.length && /\s/.test(s[i])) i++;
  };
  const word = (w) => {
    ws();
    if (s.slice(i, i + w.length).toLowerCase() === w && !/[\w-]/.test(s[i + w.length] ?? "")) {
      i += w.length;
      return true;
    }
    return false;
  };
  const balanced = () => {
    let depth = 1;
    const a = i;
    let q = "";
    for (; i < s.length; i++) {
      const c = s[i];
      if (q) {
        if (c === "\\") i++;
        else if (c === q) q = "";
        continue;
      }
      if (c === '"' || c === "'") q = c;
      else if (c === "(") depth++;
      else if (c === ")" && --depth === 0) {
        i++;
        return s.slice(a, i - 1);
      }
    }
    return null;
  };
  const inParens = () => {
    ws();
    if (s.slice(i, i + 9).toLowerCase() === "selector(") {
      i += 9;
      const b2 = balanced();
      return b2 === null ? null : supportsSelector(b2);
    }
    const fn = /^[a-zA-Z-]+\(/.exec(s.slice(i));
    if (fn) {
      i += fn[0].length;
      return balanced() === null ? null : false;
    }
    if (s[i] !== "(") return null;
    i++;
    const save = i;
    const nested = condition();
    ws();
    if (nested !== null && s[i] === ")") {
      i++;
      return nested;
    }
    i = save;
    const b = balanced();
    if (b === null) return null;
    const colon = b.indexOf(":");
    if (colon <= 0) return false;
    const prop = b.slice(0, colon).trim();
    if (!/^-{0,2}[a-zA-Z_][\w-]*$/.test(prop)) return false;
    return supportsDeclaration(prop, b.slice(colon + 1));
  };
  const condition = () => {
    if (word("not")) {
      const v3 = inParens();
      return v3 === null ? null : !v3;
    }
    let v2 = inParens();
    if (v2 === null) return null;
    for (; ; ) {
      if (word("and")) {
        const r = inParens();
        if (r === null) return null;
        v2 = v2 && r;
      } else if (word("or")) {
        const r = inParens();
        if (r === null) return null;
        v2 = v2 || r;
      } else return v2;
    }
  };
  const v = condition();
  ws();
  return v === true && i === s.length;
}
function cssSupports(...args) {
  if (args.length >= 2) return supportsDeclaration(String(args[0]), String(args[1]));
  if (args.length === 1) {
    const text = String(args[0]).trim();
    if (!/^(?:not\b|\(|selector\()/i.test(text) && /^-{0,2}[a-zA-Z_][\w-]*\s*:/.test(text)) {
      const colon = text.indexOf(":");
      return supportsDeclaration(text.slice(0, colon), text.slice(colon + 1));
    }
    return supportsCondition(text);
  }
  return false;
}
export {
  cssFunctionInProfile,
  cssPropertyInProfile,
  cssPseudoClassInProfile,
  cssPseudoElementInProfile,
  cssSupports,
  cssUnitInProfile,
  fontShorthandFamilyStart,
  isGenericFont,
  supportsCondition,
  supportsDeclaration,
  supportsSelector
};
