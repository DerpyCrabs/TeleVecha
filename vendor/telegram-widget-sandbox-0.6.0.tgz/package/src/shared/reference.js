import { PROFILE_UA_STYLESHEET } from "./profile-tables.js";
import { checkContentSafeArea, contentSafeAreaVariables, themeVariables } from "./sdk-policy.js";
const declarations = (vars) => Object.entries(vars).map(([k, v]) => `${k}:${v}`).join(";");
const rootVars = (scheme) => declarations({ ...themeVariables({ colorScheme: scheme }), ...contentSafeAreaVariables(null) });
const REFERENCE_STYLESHEET = `${PROFILE_UA_STYLESHEET}:root{${rootVars("light")}}@media (prefers-color-scheme: dark){:root{${rootVars("dark")}}}`;
const REFERENCE_TIME_CORNER = { bottom: 24, corner: 64 };
function referenceSafeArea(rtl = false) {
  const { bottom, corner } = REFERENCE_TIME_CORNER;
  return checkContentSafeArea({ bottom, ...rtl ? { cornerLeft: corner } : { cornerRight: corner } });
}
const referenceSafeAreaCss = (area) => `:root{${declarations(contentSafeAreaVariables(area))}}`;
function timeCornerStyle(area) {
  const a = checkContentSafeArea(area);
  const corner = a.cornerRight || a.cornerLeft;
  if (!a.bottom || !corner) return "";
  const h = Math.min(18, a.bottom - 4);
  return `position:absolute;${a.cornerRight ? "right" : "left"}:6px;bottom:${(a.bottom - h) / 2}px;width:${corner - 12}px;height:${h}px;box-sizing:border-box;border-radius:${h / 2}px;background:rgba(0,0,0,.35);color:#fff;font:500 11px/${h}px system-ui,sans-serif;text-align:center;white-space:nowrap;overflow:hidden;z-index:2147483647`;
}
const REFERENCE_TIME_LABEL = "12:00 \u2713\u2713";
export {
  REFERENCE_STYLESHEET,
  REFERENCE_TIME_CORNER,
  REFERENCE_TIME_LABEL,
  referenceSafeArea,
  referenceSafeAreaCss,
  timeCornerStyle
};
