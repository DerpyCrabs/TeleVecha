const TOUCH_SLOP_PX = 10;
const HOLD_MS = 500;
const DOUBLE_TAP_MS = 300;
const DOUBLE_TAP_SLOP_PX = 40;
const EDGE_STRIP_PX = 20;
const NO_CLAIM = Object.freeze({ x: false, y: false, hold: false });
function claimOf(touchActions, prevented = false) {
  let x = prevented;
  for (const raw of touchActions) {
    const ta = raw.trim().toLowerCase();
    if (ta === "" || ta === "auto" || ta === "manipulation") continue;
    if (ta === "none") return { x: true, y: false, hold: true };
    if (!/\bpan-(x|left|right)\b/.test(ta)) x = true;
  }
  return { x, y: false, hold: false };
}
class GestureArbiter {
  press = null;
  lastTap = null;
  /** A primary pointerdown. `button` 2 with a mouse is the secondary click. A press still open is replaced. */
  down(t, x, y, claim, pointer = "touch", button = 0) {
    const edge = pointer !== "mouse" && x < EDGE_STRIP_PX;
    const last = this.lastTap;
    this.lastTap = null;
    const second = last !== null && t - last.t <= DOUBLE_TAP_MS && Math.hypot(x - last.x, y - last.y) <= DOUBLE_TAP_SLOP_PX;
    const p = { t0: t, x0: x, y0: y, claim: edge ? NO_CLAIM : claim, pointer, edge, second, locked: false, owner: "pending", gesture: "press" };
    this.press = p;
    if (pointer === "mouse" && button === 2) {
      return p.claim.hold ? this.decide(p, "widget", "menu-click", void 0, "contextmenu") : this.decide(p, "bubble", "menu-click", "menu");
    }
    return this.verdict(p);
  }
  /** A move of the press's pointer. Null when no press is open. */
  move(t, x, y) {
    const p = this.press;
    if (!p) return null;
    const held = this.holdFirst(p, t);
    if (held) return held;
    const dx = x - p.x0, dy = y - p.y0;
    if (p.locked || Math.hypot(dx, dy) <= TOUCH_SLOP_PX) return this.verdict(p);
    p.locked = true;
    const horizontal = Math.abs(dx) > Math.abs(dy);
    if (p.owner === "widget" && p.gesture === "hold") return horizontal ? this.verdict(p) : this.decide(p, "bubble", "drag-y", "scroll");
    if (p.owner !== "pending") return this.verdict(p);
    const gesture = horizontal ? "drag-x" : "drag-y";
    if (p.pointer === "mouse" || horizontal && p.claim.x) return this.decide(p, "widget", gesture);
    return this.decide(p, "bubble", gesture, horizontal ? p.edge ? "back" : "swipe" : "scroll");
  }
  /** The hold timer: call it at `holdDeadline()`. Null when no press is open. */
  tick(t) {
    const p = this.press;
    if (!p) return null;
    return this.holdFirst(p, t) ?? this.verdict(p);
  }
  /** The pointerup. A press still undecided is a tap, or the second tap of a double tap. Null when no press is open. */
  up(t, x, y) {
    const p = this.press;
    if (!p) return null;
    const v = this.move(t, x, y);
    this.press = null;
    if (p.owner !== "pending") return v.cancel || v.event ? v : this.verdict(p);
    if (p.second) return this.decide(p, "widget", "double-tap", void 0, "dblclick");
    this.lastTap = { t, x: p.x0, y: p.y0 };
    return this.decide(p, "widget", "tap");
  }
  /** The platform cancelled the press (a scroll, the client's own recognizer): it is over, and no double tap continues it. */
  cancel() {
    this.press = null;
    this.lastTap = null;
  }
  /** When `tick` may turn the open press into a hold, or null. */
  holdDeadline() {
    const p = this.press;
    return p && p.owner === "pending" && p.pointer !== "mouse" ? p.t0 + HOLD_MS : null;
  }
  holdFirst(p, t) {
    if (p.owner !== "pending" || p.pointer === "mouse" || t - p.t0 < HOLD_MS) return null;
    return p.claim.hold ? this.decide(p, "widget", "hold", void 0, "contextmenu") : this.decide(p, "bubble", "hold", "menu");
  }
  decide(p, owner, gesture, action, event) {
    p.owner = owner;
    p.gesture = gesture;
    p.action = action;
    const v = this.verdict(p);
    v.cancel = owner === "bubble";
    if (event) v.event = event;
    return v;
  }
  verdict(p) {
    const v = { owner: p.owner, gesture: p.gesture, cancel: false };
    if (p.action) v.action = p.action;
    if (p.edge) v.edge = true;
    return v;
  }
}
export {
  DOUBLE_TAP_MS,
  DOUBLE_TAP_SLOP_PX,
  EDGE_STRIP_PX,
  GestureArbiter,
  HOLD_MS,
  NO_CLAIM,
  TOUCH_SLOP_PX,
  claimOf
};
