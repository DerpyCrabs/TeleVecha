class AnimationState {
  scripted = /* @__PURE__ */ new Map();
  cssIds = /* @__PURE__ */ new WeakMap();
  cssById = /* @__PURE__ */ new Map();
  cssSeq = 0;
}
const KEYFRAME_MEMBERS = /* @__PURE__ */ new Set(["offset", "easing", "composite", "computedOffset"]);
function cssAnimationList(state, el, subtree, idOf) {
  const { cssIds, cssById } = state;
  const out = [];
  const index = /* @__PURE__ */ new Map();
  for (const a of el.getAnimations({ subtree })) {
    const isAnimation = typeof CSSAnimation !== "undefined" && a instanceof CSSAnimation;
    const isTransition = typeof CSSTransition !== "undefined" && a instanceof CSSTransition;
    if (!isAnimation && !isTransition || a.currentTime === null) continue;
    let origin = cssIds.get(a);
    if (origin === void 0) {
      origin = ++state.cssSeq;
      cssIds.set(a, origin);
      cssById.set(origin, new WeakRef(a));
    }
    const target = a.effect?.target ?? null;
    const id = target ? idOf(target) : 0;
    if (!id) continue;
    const t = a.effect.getTiming();
    const n = index.get(id) ?? 0;
    index.set(id, n + 1);
    out.push({
      kind: isAnimation ? "animation" : "transition",
      id,
      name: isAnimation ? a.animationName : a.transitionProperty,
      index: n,
      origin,
      currentTime: a.currentTime,
      playbackRate: a.playbackRate,
      paused: a.playState === "paused",
      duration: typeof t.duration === "number" ? t.duration : 0,
      delay: t.delay,
      iterations: t.iterations === Infinity ? null : t.iterations,
      direction: t.direction,
      fill: t.fill,
      easing: t.easing
    });
  }
  return out;
}
const camel = (n) => n.startsWith("--") ? n : n === "float" ? "cssFloat" : n.replace(/^-(webkit|moz|ms)-/, "$1-").replace(/-([a-z])/g, (_, c) => c.toUpperCase());
function applyAnims(state, now, anims, nodeById) {
  const { scripted, cssById } = state;
  const offset = performance.now() - Number(now);
  for (const r of anims) {
    if ("css" in r) {
      const a2 = cssById.get(r.css.origin)?.deref();
      if (!a2 || a2.effect?.target !== nodeById(r.target)) continue;
      try {
        if (r.cancelled) a2.cancel();
        else {
          a2.playbackRate = r.playbackRate;
          if (r.holdTime !== null) {
            a2.pause();
            a2.currentTime = r.holdTime;
          } else a2.startTime = r.startTime + offset;
        }
      } catch {
      }
      continue;
    }
    const old = scripted.get(r.aid);
    if ("remove" in r) {
      if (old) {
        old.cancel();
        scripted.delete(r.aid);
      }
      continue;
    }
    const el = nodeById(r.target);
    if (!(el instanceof Element)) {
      if (old) {
        old.cancel();
        scripted.delete(r.aid);
      }
      continue;
    }
    const frames = r.keyframes.map((k) => {
      const o = {};
      for (const name of Object.keys(k.values)) {
        const key = camel(name);
        if (!KEYFRAME_MEMBERS.has(key)) o[key] = k.values[name];
      }
      o.offset = k.offset;
      o.easing = k.easing;
      if (k.composite) o.composite = k.composite;
      return o;
    });
    const t = r.timing;
    const timing = { duration: t.duration, delay: t.delay, endDelay: t.endDelay, iterations: t.iterations === null ? Infinity : t.iterations, iterationStart: t.iterationStart, direction: t.direction, fill: t.fill, easing: t.easing };
    let a = old;
    try {
      const effect = a?.effect;
      if (!a || !effect || effect.target !== el) {
        if (a) a.cancel();
        a = new Animation(new KeyframeEffect(el, frames, { composite: r.composite, iterationComposite: r.iterationComposite, ...timing }), document.timeline);
        scripted.set(r.aid, a);
      } else {
        effect.setKeyframes(frames);
        effect.updateTiming(timing);
        effect.composite = r.composite;
        if ("iterationComposite" in effect) effect.iterationComposite = r.iterationComposite;
      }
      a.playbackRate = r.playbackRate;
      if (r.holdTime !== null) {
        a.pause();
        a.currentTime = r.holdTime;
      } else {
        a.startTime = r.startTime + offset;
      }
    } catch {
      try {
        a?.cancel();
      } catch {
      }
      scripted.delete(r.aid);
    }
  }
}
export {
  AnimationState,
  applyAnims,
  cssAnimationList
};
