function rendererCsp(nonce) {
  return [
    "default-src 'none'",
    `script-src 'nonce-${nonce}'`,
    "style-src 'unsafe-inline'",
    "img-src data: blob:",
    "font-src data:",
    "media-src data: blob:",
    "connect-src 'none'",
    "frame-src 'none'",
    "child-src 'none'",
    "worker-src 'none'",
    "form-action 'none'",
    "base-uri 'none'"
  ].join("; ");
}
function makeNonce() {
  const bytes = crypto.getRandomValues(new Uint8Array(18));
  return btoa(String.fromCharCode(...bytes)).replace(/[+/=]/g, "x");
}
function buildSrcdoc(rendererJs, nonce) {
  const js = rendererJs.replace(/<\/(script)/gi, "<\\/$1").replace(/<!--/g, "<\\!--");
  return `<!DOCTYPE html><html><head><meta http-equiv="Content-Security-Policy" content="${rendererCsp(nonce)}"><meta http-equiv="x-dns-prefetch-control" content="off"><script nonce="${nonce}">${js}<\/script></head><body></body></html>`;
}
export {
  buildSrcdoc,
  makeNonce,
  rendererCsp
};
