const TOUCH_ACTION_CLAIM = "--tw-touch-action";
const VERTICAL = /* @__PURE__ */ new Set(["pan-y", "pan-up", "pan-down"]);
function engineTouchAction(value) {
  const words = value.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (words.length === 0) return value;
  if (words.length === 1 && ["auto", "manipulation", "inherit", "initial", "unset", "revert", "revert-layer", "pan-y"].includes(words[0])) return value;
  if (words.length === 1 && words[0] === "none") return "pan-y";
  if (words.includes("pan-y")) return value;
  return [...words.filter((w) => !VERTICAL.has(w)), "pan-y"].join(" ");
}
export {
  TOUCH_ACTION_CLAIM,
  engineTouchAction
};
