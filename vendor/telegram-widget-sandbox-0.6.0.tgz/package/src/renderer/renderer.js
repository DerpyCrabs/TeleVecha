import { createRenderer, toBase64 } from "./core";
import { measureDocHeight } from "../shared/doc-height";
const doc = document;
let schemeStyle = null;
function frameColorScheme(scheme) {
  if (!schemeStyle) {
    schemeStyle = doc.createElement("style");
    doc.head.appendChild(schemeStyle);
  }
  schemeStyle.textContent = `@layer tw-ua{:where(html){color-scheme:${scheme}}}`;
}
function documentEnv() {
  return {
    doc,
    root: doc,
    roots: () => ({ html: doc.documentElement, head: doc.head, body: doc.body }),
    origin: () => null,
    viewport: () => ({ innerWidth: window.innerWidth, innerHeight: window.innerHeight, dpr: window.devicePixelRatio }),
    docHeight: () => measureDocHeight(doc),
    matchMedia: (query) => matchMedia(query).matches,
    onViewportResize: (cb) => {
      window.addEventListener("resize", cb);
      return () => window.removeEventListener("resize", cb);
    },
    onColorSchemeChange: (cb) => {
      const mq = matchMedia("(prefers-color-scheme: dark)");
      mq.addEventListener("change", cb);
      return () => mq.removeEventListener("change", cb);
    },
    // The web's frame only: WebViews are top-level documents over the bubble.
    ...__TW_TRANSPORT__ === "port" ? { frameColorScheme } : {}
  };
}
document.currentScript?.remove();
const core = createRenderer(documentEnv());
const onMessage = (msg) => core.onMessage(msg);
if (__TW_TRANSPORT__ === "webkit" || __TW_TRANSPORT__ === "android") {
  const handler = __TW_TRANSPORT__ === "webkit" ? window.webkit?.messageHandlers?.tw : window.tw;
  const start = () => {
    window.__twReceive = (json) => onMessage(JSON.parse(json));
    core.init((msg) => {
      if (msg.type === "result" && msg.binary) {
        handler.postMessage(JSON.stringify({ ...msg, binary: void 0, binaryBase64: toBase64(msg.binary) }));
        return;
      }
      handler.postMessage(JSON.stringify(msg));
    });
    handler.postMessage(JSON.stringify({ type: "ready" }));
  };
  if (doc.readyState === "loading") doc.addEventListener("DOMContentLoaded", start, { once: true });
  else start();
} else {
  const onWindowMessage = (e) => {
    if (e.source !== window.parent || !e.data || e.data.type !== "tw-init" || !e.ports[0]) return;
    window.removeEventListener("message", onWindowMessage);
    const port = e.ports[0];
    core.init((msg, transfer) => port.postMessage(msg, transfer));
    port.onmessage = (ev) => onMessage(ev.data);
  };
  window.addEventListener("message", onWindowMessage);
  const announce = () => window.parent.postMessage({ type: "tw-renderer-ready" }, "*");
  if (doc.readyState === "loading") doc.addEventListener("DOMContentLoaded", announce, { once: true });
  else announce();
}
