import { EVENT_TYPES } from "../shared/protocol";
import { PROFILE_UA_STYLESHEET } from "../shared/profile-tables";
import { THEME_VARIABLES, contentSafeAreaVariables, themeVariables } from "../shared/sdk-policy";
import { GestureArbiter, claimOf } from "../shared/gesture-policy";
import { PaintCounter, animationPaint, boxPaint, boxShadowBlurred, boxShadowWithoutBlur, hidesSubtree } from "../shared/paint-policy";
import { AnimationState, applyAnims, cssAnimationList } from "./web-animations";
import { TOUCH_ACTION_CLAIM, engineTouchAction } from "./touch-action";
const SVG_NS = "http://www.w3.org/2000/svg";
const uncurry = (f) => (self, ...args) => f.apply(self, args);
const getter = (proto, name) => {
  const g = Object.getOwnPropertyDescriptor(proto, name).get;
  return (self) => g.call(self);
};
const setter = (proto, name) => {
  const s = Object.getOwnPropertyDescriptor(proto, name).set;
  return (self, v) => s.call(self, v);
};
const createElement = uncurry(Document.prototype.createElement);
const createElementNS = uncurry(Document.prototype.createElementNS);
const createTextNode = uncurry(Document.prototype.createTextNode);
const setAttribute = uncurry(Element.prototype.setAttribute);
const getAttribute = uncurry(Element.prototype.getAttribute);
const removeAttribute = uncurry(Element.prototype.removeAttribute);
const closest = uncurry(Element.prototype.closest);
const getBoundingClientRect = uncurry(Element.prototype.getBoundingClientRect);
const getClientRects = uncurry(Element.prototype.getClientRects);
const insertBefore = uncurry(Node.prototype.insertBefore);
const removeChild = uncurry(Node.prototype.removeChild);
const parentNodeOf = getter(Node.prototype, "parentNode");
const firstChildOf = getter(Node.prototype, "firstChild");
const nextSiblingOf = getter(Node.prototype, "nextSibling");
const localNameOf = getter(Element.prototype, "localName");
const setTextContent = setter(Node.prototype, "textContent");
const setCharData = setter(CharacterData.prototype, "data");
const htmlStyleOf = getter(HTMLElement.prototype, "style");
const svgStyleOf = getter(SVGElement.prototype, "style");
const styleOf = (el) => el instanceof SVGElement ? svgStyleOf(el) : htmlStyleOf(el);
const sheetOf = getter(HTMLStyleElement.prototype, "sheet");
const isConnectedOf = getter(Node.prototype, "isConnected");
const matches = uncurry(Element.prototype.matches);
const getAnimationsOf = uncurry(Element.prototype.getAnimations);
const FORBIDDEN_TAGS = /* @__PURE__ */ new Set([
  "script",
  "iframe",
  "frame",
  "frameset",
  "object",
  "embed",
  "link",
  "meta",
  "base",
  "portal",
  "noscript",
  "set",
  "template",
  "audio",
  "video",
  "source",
  "track",
  // Outside the profile (form controls, dialogs): the validator drops or replaces them.
  "input",
  "select",
  "option",
  "optgroup",
  "textarea",
  "datalist",
  "fieldset",
  "progress",
  "meter",
  "form",
  "dialog"
]);
const FORBIDDEN_ATTRS = /* @__PURE__ */ new Set(["srcdoc", "srcset", "action", "formaction", "ping", "background", "nonce", "target", "http-equiv"]);
const scrollTopSet = setter(Element.prototype, "scrollTop");
const scrollLeftSet = setter(Element.prototype, "scrollLeft");
const rectJson = (r, o) => {
  const dx = o?.x ?? 0, dy = o?.y ?? 0;
  return { x: r.x - dx, y: r.y - dy, width: r.width, height: r.height, top: r.top - dy, left: r.left - dx, right: r.right - dx, bottom: r.bottom - dy };
};
const matrixJson = (m) => m ? { a: m.a, b: m.b, c: m.c, d: m.d, e: m.e, f: m.f } : null;
const ALWAYS_FORWARD = /* @__PURE__ */ new Set(["click", "load", "error", "toggle"]);
const THROTTLED = /* @__PURE__ */ new Set(["pointermove", "mousemove"]);
const ALL_EVENTS = [...EVENT_TYPES];
const ENGINE_GESTURES = /* @__PURE__ */ new Set(["dblclick", "contextmenu"]);
const MOUSE_COMPAT = /* @__PURE__ */ new Set(["mousedown", "mouseup", "mousemove", "click"]);
const ENTER_LEAVE = ["pointerenter", "pointerleave", "mouseenter", "mouseleave"];
const PAINT_ANIMATION_EVENTS = ["animationstart", "animationend", "animationcancel", "transitionstart", "transitionend", "transitioncancel"];
const PAINT_INPUT_EVENTS = ["pointerover", "pointerout", "pointerdown", "pointerup", "pointercancel", "toggle"];
const noop = () => {
};
const SWALLOWED = ["keydown", "keyup", "keypress", "beforeinput", "input", "contextmenu", "mousedown", "focusin", "submit", "selectstart"];
function decodeBase64(b64) {
  const bin = atob(b64);
  const out = new Uint8ClampedArray(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function toBase64(buf) {
  const bytes = new Uint8Array(buf);
  let bin = "";
  for (let i = 0; i < bytes.length; i += 32768) bin += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + 32768)));
  return btoa(bin);
}
function createRenderer(env) {
  const doc = env.doc;
  const root = env.root;
  const elementFromPoint = root instanceof Document ? uncurry(Document.prototype.elementFromPoint) : uncurry(ShadowRoot.prototype.elementFromPoint);
  let send = () => {
  };
  const post = (msg, transfer = []) => send(msg, transfer);
  const violation = (detail) => post({ type: "violation", detail });
  let HTML;
  let HEAD;
  let BODY;
  const nodes = /* @__PURE__ */ new Map();
  const ids = /* @__PURE__ */ new WeakMap();
  const animations = new AnimationState();
  function register(id, node) {
    nodes.set(id, node);
    ids.set(node, id);
  }
  function forget(node) {
    const id = ids.get(node);
    if (id !== void 0) {
      nodes.delete(id);
      ids.delete(node);
      canvases.delete(id);
      if (node instanceof Element) resizeObserver.unobserve(node);
      if (node instanceof HTMLCanvasElement) {
        canvasPixelsTotal -= canvasPixels.get(node) ?? 0;
        canvasPixels.delete(node);
      }
      if (node instanceof HTMLStyleElement) widgetStyles.delete(node);
    }
    for (let c = firstChildOf(node); c; c = nextSiblingOf(c)) forget(c);
  }
  const CANVAS_PIXELS_MAX = 4096 * 4096;
  const canvasPixels = /* @__PURE__ */ new Map();
  let canvasPixelsTotal = 0;
  function fitCanvas(el, w, h) {
    const others = canvasPixelsTotal - (canvasPixels.get(el) ?? 0);
    if (!(others + w * h <= CANVAS_PIXELS_MAX)) {
      violation(`canvas ${w}\xD7${h}: a widget's canvases hold at most ${CANVAS_PIXELS_MAX} pixels together`);
      return false;
    }
    canvasPixels.set(el, w * h);
    canvasPixelsTotal = others + w * h;
    return true;
  }
  function canvasSizeFits(el, name, value) {
    if (!(el instanceof HTMLCanvasElement) || name !== "width" && name !== "height") return true;
    const parsed = /^[\t\n\f\r ]*\+?(\d+)/.exec(value ?? "");
    const n = parsed ? Number(parsed[1]) : name === "width" ? 300 : 150;
    return fitCanvas(el, name === "width" ? n : el.width, name === "height" ? n : el.height);
  }
  function idOf(node) {
    for (let n = node; n; n = parentNodeOf(n)) {
      const id = ids.get(n);
      if (id !== void 0) return id;
    }
    return 0;
  }
  function applyAttr(el, name, value) {
    const lower = name.toLowerCase();
    if (lower.startsWith("on") || FORBIDDEN_ATTRS.has(lower)) return violation(`attribute ${name}`);
    if (el instanceof HTMLCanvasElement && (lower === "width" || lower === "height") && getAttribute(el, lower) === value) return;
    if (!canvasSizeFits(el, lower, value)) return;
    setAttribute(el, name, value);
    if (lower === "style") widenTouchAction(styleOf(el));
  }
  function widenTouchAction(style) {
    const value = style.getPropertyValue("touch-action");
    if (!value) return;
    const priority = style.getPropertyPriority("touch-action");
    style.setProperty(TOUCH_ACTION_CLAIM, value, priority);
    const engine = engineTouchAction(value);
    if (engine !== value) style.setProperty("touch-action", engine, priority);
  }
  function ownTouchAction(cs) {
    const own = cs.getPropertyValue(TOUCH_ACTION_CLAIM).trim();
    const words = (v) => v.trim().toLowerCase().split(/\s+/).sort().join(" ");
    return own && words(cs.touchAction) === words(engineTouchAction(own)) ? own : cs.touchAction;
  }
  function widenSheet(el) {
    if (!(el instanceof HTMLStyleElement)) return;
    const sheet = sheetOf(el);
    if (!sheet) return;
    const walk = (rules) => {
      for (let i = 0; i < rules.length; i++) {
        const r = rules[i];
        if (r.style) widenTouchAction(r.style);
        if (r.cssRules) walk(r.cssRules);
      }
    };
    walk(sheet.cssRules);
  }
  function applyOp(op) {
    switch (op.op) {
      case "el": {
        const tag = op.tag.toLowerCase();
        if (FORBIDDEN_TAGS.has(tag)) return violation(`element <${op.tag}>`);
        let el;
        if (op.adopt) canvasDirty = true;
        if (op.adopt === "html") el = HTML;
        else if (op.adopt === "head") el = HEAD;
        else if (op.adopt === "body") el = BODY;
        else el = op.ns === "svg" ? createElementNS(doc, SVG_NS, op.tag) : createElement(doc, op.tag);
        if (tag === "img" && !op.adopt) for (const type of ["load", "error"]) el.addEventListener(type, onDetachedImage);
        register(op.id, el);
        if (el instanceof HTMLCanvasElement && !fitCanvas(el, 300, 150)) {
          el.width = 0;
          el.height = 0;
        }
        for (const [name, value] of op.attrs) applyAttr(el, name, value);
        return;
      }
      case "text":
        return register(op.id, createTextNode(doc, op.data));
      case "comment":
        return;
    }
    const node = nodes.get(op.id);
    if (!node) return;
    if (node === HTML || node === BODY || op.op === "css" || (op.op === "ins" || op.op === "rm") && node instanceof HTMLStyleElement) canvasDirty = true;
    switch (op.op) {
      case "attr":
        applyAttr(node, op.name, op.value);
        if (node === HTML && op.name.toLowerCase() === "style") applyThemeVariables();
        return;
      case "rattr":
        if (!canvasSizeFits(node, op.name.toLowerCase(), null)) return;
        removeAttribute(node, op.name);
        if (node === HTML && op.name.toLowerCase() === "style") applyThemeVariables();
        return;
      case "data":
        return setCharData(node, op.data);
      case "ins": {
        if (node === HTML || node === HEAD || node === BODY) return;
        if (op.parent === 0) {
          const p = parentNodeOf(node);
          if (p) removeChild(p, node);
          return;
        }
        const parent = nodes.get(op.parent);
        if (!parent) return;
        const ref = op.before === null ? null : nodes.get(op.before) ?? null;
        insertBefore(parent, node, ref && parentNodeOf(ref) === parent ? ref : null);
        widenSheet(node);
        return;
      }
      case "rm": {
        if (node === HTML || node === HEAD || node === BODY) return;
        const p = parentNodeOf(node);
        if (p) removeChild(p, node);
        forget(node);
        return;
      }
      case "style": {
        if (node === HTML && THEME_VARIABLES.includes(op.name)) return;
        const style = styleOf(node);
        if (op.name === "touch-action") style.removeProperty(TOUCH_ACTION_CLAIM);
        if (op.value === "") style.removeProperty(op.name);
        else style.setProperty(op.name, op.value, op.important ? "important" : "");
        if (op.name === "touch-action") widenTouchAction(style);
        return;
      }
      case "css":
        if (localNameOf(node) === "style") {
          setTextContent(node, op.text);
          widenSheet(node);
        }
        return;
      case "prop":
        return applyProp(node, op.name, op.value);
      case "call":
        return applyCall(node, op.method, op.args);
      case "canvas":
        if (node instanceof HTMLCanvasElement) replay(op.id, node, op.cmds);
        return;
    }
  }
  function applyProp(el, name, value) {
    switch (name) {
      case "scrollTop":
        return scrollTopSet(el, value);
      case "scrollLeft":
        return scrollLeftSet(el, value);
    }
  }
  const METHOD_IMPL = {
    scrollTo: (el, a) => Element.prototype.scrollTo.call(el, a[0], a[1]),
    scrollBy: (el, a) => Element.prototype.scrollBy.call(el, a[0], a[1]),
    setPointerCapture: (el, a) => {
      if (!ownPointers.has(a[0])) return;
      try {
        Element.prototype.setPointerCapture.call(el, a[0]);
      } catch {
      }
    },
    releasePointerCapture: (el, a) => {
      try {
        Element.prototype.releasePointerCapture.call(el, a[0]);
      } catch {
      }
    },
    observeResize: (el) => resizeObserver.observe(el),
    unobserveResize: (el) => resizeObserver.unobserve(el)
  };
  function applyCall(el, method, args) {
    const impl = Object.prototype.hasOwnProperty.call(METHOD_IMPL, method) ? METHOD_IMPL[method] : null;
    if (impl) impl(el, args);
  }
  const canvases = /* @__PURE__ */ new Map();
  function canvasState(id, el) {
    let st = canvases.get(id);
    if (!st) {
      const ctx = HTMLCanvasElement.prototype.getContext.call(el, "2d");
      if (!ctx) return null;
      st = { ctx, objects: /* @__PURE__ */ new Map(), paths: /* @__PURE__ */ new Map() };
      canvases.set(id, st);
    }
    return st;
  }
  function resolveArg(st, a) {
    if (a && typeof a === "object" && !Array.isArray(a)) {
      if ("g" in a) return st.objects.get(a.g) ?? void 0;
      if ("p" in a) return st.paths.get(a.p) ?? void 0;
      if ("n" in a) return nodes.get(a.n);
      if ("b64" in a) {
        try {
          return new ImageData(decodeBase64(a.b64), a.w, a.h);
        } catch {
          return void 0;
        }
      }
    }
    return a;
  }
  function replay(id, el, cmds) {
    const st = canvasState(id, el);
    if (!st) return;
    const ctx = st.ctx;
    for (const cmd of cmds) {
      try {
        const [kind, name, ...rest] = cmd;
        switch (kind) {
          case "c": {
            const args = rest.map((a) => resolveArg(st, a));
            if (args.includes(void 0)) break;
            ctx[name](...args);
            break;
          }
          case "s":
            ctx[name] = resolveArg(st, rest[0]);
            break;
          case "r":
            if (!fitCanvas(el, name, rest[0])) {
              el.width = el.width;
              break;
            }
            el.width = name;
            el.height = rest[0];
            break;
          case "g": {
            const [type, ...args] = rest;
            let obj = null;
            if (type === "linear") obj = ctx.createLinearGradient(...args);
            else if (type === "radial") obj = ctx.createRadialGradient(...args);
            else if (type === "conic") obj = ctx.createConicGradient(...args);
            else if (type === "pattern") {
              const src = resolveArg(st, args[0]);
              if (src) obj = ctx.createPattern(src, args[1] ?? "repeat");
            }
            st.objects.set(name, obj);
            break;
          }
          case "gs":
            st.objects.get(name)?.addColorStop(rest[0], rest[1]);
            break;
          case "pn":
            st.paths.set(name, typeof rest[0] === "string" ? new Path2D(rest[0]) : new Path2D());
            break;
          case "pc": {
            const path = st.paths.get(name);
            const [method, ...args] = rest;
            if (path) path[method](...args.map((a) => resolveArg(st, a)));
            break;
          }
        }
      } catch {
      }
    }
  }
  let scratch = null;
  function answer(q) {
    const el = "id" in q ? nodes.get(q.id) : null;
    if ("id" in q && !(el instanceof Element)) return { result: { error: "no such element" } };
    switch (q.q) {
      case "rect":
        return { result: rectJson(getBoundingClientRect(el), env.origin()) };
      case "rects": {
        const o = env.origin();
        return { result: Array.from(getClientRects(el), (r) => rectJson(r, o)) };
      }
      case "box": {
        const g = (name) => getter(Element.prototype, name)(el);
        const html = el instanceof HTMLElement;
        const h = (name) => html ? getter(HTMLElement.prototype, name)(el) : 0;
        return {
          result: {
            offsetWidth: h("offsetWidth"),
            offsetHeight: h("offsetHeight"),
            offsetTop: h("offsetTop"),
            offsetLeft: h("offsetLeft"),
            offsetParent: html ? idOf(h("offsetParent")) : 0,
            clientWidth: g("clientWidth"),
            clientHeight: g("clientHeight"),
            clientTop: g("clientTop"),
            clientLeft: g("clientLeft"),
            scrollWidth: g("scrollWidth"),
            scrollHeight: g("scrollHeight"),
            scrollTop: g("scrollTop"),
            scrollLeft: g("scrollLeft")
          }
        };
      }
      case "cs": {
        const cs = getComputedStyle(el, q.pseudo ?? null);
        const touchAction = () => ownTouchAction(cs);
        if (q.prop) return { result: q.prop === "touch-action" ? touchAction() : cs.getPropertyValue(q.prop) };
        const out = {};
        for (let i = 0; i < cs.length; i++) if (cs[i] !== TOUCH_ACTION_CLAIM) out[cs[i]] = cs.getPropertyValue(cs[i]);
        out["touch-action"] = touchAction();
        return { result: out };
      }
      case "svg": {
        try {
          const args = q.args ?? [];
          switch (q.method) {
            case "getBBox": {
              const b = el.getBBox();
              return { result: { x: b.x, y: b.y, width: b.width, height: b.height } };
            }
            case "getCTM":
              return { result: matrixJson(el[q.method]()) };
            case "getScreenCTM": {
              const m = matrixJson(el.getScreenCTM());
              const o = env.origin();
              if (m && o) {
                m.e -= o.x;
                m.f -= o.y;
              }
              return { result: m };
            }
            case "getPointAtLength": {
              const p = el.getPointAtLength(args[0] ?? 0);
              return { result: { x: p.x, y: p.y } };
            }
            case "getComputedTextLength":
            case "getTotalLength":
            case "getNumberOfChars":
              return { result: el[q.method]() };
            case "getSubStringLength":
              return { result: el.getSubStringLength(args[0] ?? 0, args[1] ?? 0) };
          }
        } catch (e) {
          return { result: { error: String(e) } };
        }
        return { result: { error: "unsupported" } };
      }
      case "measureText": {
        scratch ??= HTMLCanvasElement.prototype.getContext.call(createElement(doc, "canvas"), "2d");
        scratch.font = "10px sans-serif";
        scratch.font = q.font;
        const m = scratch.measureText(q.text);
        return {
          result: {
            width: m.width,
            actualBoundingBoxLeft: m.actualBoundingBoxLeft,
            actualBoundingBoxRight: m.actualBoundingBoxRight,
            actualBoundingBoxAscent: m.actualBoundingBoxAscent,
            actualBoundingBoxDescent: m.actualBoundingBoxDescent,
            fontBoundingBoxAscent: m.fontBoundingBoxAscent,
            fontBoundingBoxDescent: m.fontBoundingBoxDescent
          }
        };
      }
      case "imageData": {
        const st = canvasState(q.id, el);
        if (!st) return { result: { error: "no context" } };
        const data = st.ctx.getImageData(q.x, q.y, q.w, q.h);
        const buf = data.data.buffer.slice(0);
        return { result: { width: data.width, height: data.height }, binary: buf };
      }
      case "canvasCall": {
        const st = canvasState(q.id, el);
        if (!st) return { result: { error: "no context" } };
        const args = (q.args ?? []).map((a) => resolveArg(st, a));
        try {
          switch (q.method) {
            case "isPointInPath":
            case "isPointInStroke":
              return { result: st.ctx[q.method](...args) };
            case "getTransform":
              return { result: matrixJson(st.ctx.getTransform()) };
            case "getLineDash":
              return { result: st.ctx.getLineDash() };
            case "toDataURL":
              return { result: HTMLCanvasElement.prototype.toDataURL.call(el, ...args) };
          }
        } catch (e) {
          return { result: { error: String(e) } };
        }
        return { result: { error: "unsupported" } };
      }
      case "elementFromPoint": {
        const o = env.origin();
        return { result: idOf(elementFromPoint(root, q.x + (o?.x ?? 0), q.y + (o?.y ?? 0))) };
      }
      case "validity": {
        const v = el.validity;
        if (!v) return { result: { valid: true, message: "" } };
        const out = { message: el.validationMessage };
        for (const k of ["valid", "valueMissing", "typeMismatch", "patternMismatch", "tooLong", "tooShort", "rangeUnderflow", "rangeOverflow", "stepMismatch", "badInput", "customError"]) out[k] = v[k];
        return { result: out };
      }
      case "matchMedia":
        return { result: { matches: env.matchMedia(q.query) } };
      case "viewport":
        return { result: env.viewport() };
      case "anims":
        return { result: { list: cssAnimationList(animations, el, q.subtree === true, idOf) } };
    }
  }
  let interest = /* @__PURE__ */ new Set();
  let preventKeys = /* @__PURE__ */ new Set();
  const pendingMoves = /* @__PURE__ */ new Map();
  let moveFrame = 0;
  let frameReq = 0;
  let frozen = false;
  function serialize(e, targetId) {
    const ev = { type: e.type, targetId };
    const t = e.target;
    const o = env.origin();
    if (e instanceof MouseEvent) {
      ev.clientX = e.clientX;
      ev.clientY = e.clientY;
      ev.offsetX = e.offsetX;
      ev.offsetY = e.offsetY;
      ev.pageX = e.pageX;
      ev.pageY = e.pageY;
      ev.movementX = e.movementX;
      ev.movementY = e.movementY;
      if (o) {
        ev.clientX -= o.x;
        ev.clientY -= o.y;
        ev.pageX = ev.clientX;
        ev.pageY = ev.clientY;
      }
      ev.button = e.button;
      ev.buttons = e.buttons;
      ev.detail = e.detail;
      if (e.relatedTarget) ev.relatedId = idOf(e.relatedTarget);
    }
    if (e instanceof PointerEvent) {
      ev.pointerId = e.pointerId;
      ev.pointerType = e.pointerType;
      ev.isPrimary = e.isPrimary;
      ev.pressure = e.pressure;
    }
    if (e instanceof MouseEvent) {
      const m = e;
      ev.modifiers = (m.altKey ? 1 : 0) | (m.ctrlKey ? 2 : 0) | (m.metaKey ? 4 : 0) | (m.shiftKey ? 8 : 0);
    }
    if (t instanceof HTMLImageElement && e.type === "load") {
      ev.naturalWidth = t.naturalWidth;
      ev.naturalHeight = t.naturalHeight;
    }
    if (t instanceof HTMLDetailsElement && e.type === "toggle") ev.open = t.open;
    return ev;
  }
  function gestureClaim(el, targetId) {
    const values = [];
    for (let n = el ?? HTML; n; n = n === HTML ? null : parentNodeOf(n)) {
      if (!(n instanceof Element)) break;
      const cs = getComputedStyle(n);
      values.push(cs.getPropertyValue(TOUCH_ACTION_CLAIM).trim() || cs.touchAction);
    }
    return claimOf(values, preventKeys.has(`${targetId}:pointerdown`) || preventKeys.has(`${targetId}:touchstart`));
  }
  const arbiter = new GestureArbiter();
  let bubbleMode = null;
  let rtl = false;
  let pressPointer = -1;
  let pressEv = null;
  let holdTimer = 0;
  let takenPointer = -1;
  let dropClick = false;
  let pendingDblclick = null;
  let pressAsTouch = false;
  let clickAsTouch = false;
  function pressPoint(e) {
    const o = env.origin();
    const cx = e.clientX - (o?.x ?? 0), cy = e.clientY - (o?.y ?? 0);
    return { x: rtl ? HTML.clientWidth - cx : cx, y: cy, cx, cy };
  }
  function clearHold() {
    if (holdTimer) {
      clearTimeout(holdTimer);
      holdTimer = 0;
    }
  }
  function scheduleHold() {
    clearHold();
    const at = arbiter.holdDeadline();
    if (at === null) return;
    holdTimer = setTimeout(() => {
      holdTimer = 0;
      if (frozen) return;
      const v = arbiter.tick(Math.max(performance.now(), at));
      if (v && pressEv) settle(v, pressEv);
    }, Math.max(0, at - performance.now()) + 1);
  }
  function track(e, targetEl, targetId, ev) {
    const type = e.type;
    if (type === "pointerdown") {
      if (!e.isPrimary) return null;
      dropClick = false;
      pendingDblclick = null;
      const claim = gestureClaim(targetEl, targetId);
      post({ type: "gesture", wants: claim.y, x: claim.x, y: claim.y, hold: claim.hold });
      const kind = bubbleMode?.touch && e.button !== 2 ? "touch" : e.pointerType === "mouse" ? "mouse" : e.pointerType === "pen" ? "pen" : "touch";
      pressAsTouch = clickAsTouch = kind === "touch" && e.pointerType === "mouse";
      if (pressAsTouch) ev.pointerType = "touch";
      const p2 = pressPoint(e);
      pressPointer = e.pointerId;
      pressEv = ev;
      const v = arbiter.down(e.timeStamp, p2.x, p2.y, claim, kind, e.button);
      scheduleHold();
      return v;
    }
    if (e.pointerId !== pressPointer) return null;
    const p = pressPoint(e);
    if (pressAsTouch) ev.pointerType = "touch";
    pressEv = ev;
    if (type === "pointermove") return arbiter.move(e.timeStamp, p.x, p.y);
    clearHold();
    pressPointer = -1;
    pressAsTouch = false;
    if (type === "pointerup") return arbiter.up(e.timeStamp, p.x, p.y);
    arbiter.cancel();
    return null;
  }
  function settle(v, base) {
    if (v.event === "contextmenu") forward({ ...base, type: "contextmenu" }, true);
    else if (v.event === "dblclick") pendingDblclick = { ...base, type: "dblclick", detail: 2 };
    if (!v.cancel || !bubbleMode || base.pointerId === void 0) return;
    forward({ ...base, type: "pointercancel", button: -1, buttons: 0 }, true);
    takenPointer = base.pointerId;
    ownPointers.delete(base.pointerId);
    clearHold();
    pressPointer = -1;
    pressAsTouch = clickAsTouch = false;
    arbiter.cancel();
    post({ type: "bubble", action: v.action ?? "menu", gesture: v.gesture, x: base.clientX ?? 0, y: base.clientY ?? 0, edge: v.edge === true });
  }
  function forward(ev, trusted) {
    if (!ALWAYS_FORWARD.has(ev.type) && !interest.has(ev.type)) return;
    if (THROTTLED.has(ev.type)) {
      const key = ev.type + ":" + (ev.pointerId ?? 0);
      const previous = pendingMoves.get(key);
      if (previous) {
        ev.movementX = (previous.movementX ?? 0) + (ev.movementX ?? 0);
        ev.movementY = (previous.movementY ?? 0) + (ev.movementY ?? 0);
      }
      pendingMoves.set(key, ev);
      if (!moveFrame) {
        moveFrame = requestAnimationFrame(() => {
          moveFrame = 0;
          for (const m of pendingMoves.values()) post({ type: "event", ev: m, trusted: false });
          pendingMoves.clear();
        });
      }
      return;
    }
    if (pendingMoves.size) {
      for (const m of pendingMoves.values()) post({ type: "event", ev: m, trusted: false });
      pendingMoves.clear();
    }
    post({ type: "event", ev, trusted });
  }
  function onDetachedImage(e) {
    if (!root.contains(e.currentTarget)) onEvent(e);
  }
  function onEvent(e) {
    const type = e.type;
    const target = e.target instanceof Node ? e.target : null;
    const targetEl = target instanceof Element ? target : null;
    if (type === "click" && targetEl && closest(targetEl, "a, area")) e.preventDefault();
    if (type === "click" && e.detail === 0 && e.isTrusted) {
      e.preventDefault();
      return;
    }
    if (frozen) return;
    const targetId = target === root || target === null ? ids.get(HTML) ?? 0 : idOf(target);
    if (!targetId) return;
    if (preventKeys.size && e.cancelable && preventKeys.has(`${targetId}:${type}`)) e.preventDefault();
    if (ENGINE_GESTURES.has(type)) return;
    let verdict = null;
    let ev = null;
    if (e instanceof PointerEvent && (type === "pointerdown" || type === "pointermove" || type === "pointerup" || type === "pointercancel")) {
      if ((type === "pointerup" || type === "pointercancel") && e.isPrimary && e.isTrusted) post({ type: "release" });
      if (e.pointerId === takenPointer) {
        if (type === "pointerup" || type === "pointercancel") {
          takenPointer = -1;
          dropClick = type === "pointerup";
        }
        return;
      }
      ev = serialize(e, targetId);
      verdict = track(e, targetEl, targetId, ev);
      if (verdict?.cancel && bubbleMode && type === "pointerup") {
        settle(verdict, ev);
        takenPointer = -1;
        dropClick = true;
        return;
      }
      if (type === "pointerup" && bubbleMode?.touch && verdict && (verdict.gesture === "drag-x" || verdict.gesture === "drag-y" || verdict.gesture === "hold")) dropClick = true;
    } else if (MOUSE_COMPAT.has(type) && (takenPointer !== -1 || dropClick && type !== "mousemove")) return;
    const mayScroll = type === "pointerdown" ? e instanceof PointerEvent && isFingerOrPen(e) : (type === "mousedown" || type === "mouseup") && changedFingerDown;
    const trusted = e.isTrusted && !mayScroll && (changedOwn || type !== "pointerup" && type !== "mouseup");
    if (ev) forward(ev, trusted);
    else if (ALWAYS_FORWARD.has(type) || interest.has(type)) {
      const out = serialize(e, targetId);
      if (type === "click" && clickAsTouch && out.pointerType === "mouse") {
        out.pointerType = "touch";
        clickAsTouch = false;
      }
      forward(out, trusted);
    }
    if (verdict && ev) settle(verdict, ev);
    if (type === "click" && pendingDblclick) {
      const dbl = pendingDblclick;
      pendingDblclick = null;
      forward({ ...serialize(e, targetId), type: "dblclick", detail: 2, pointerId: dbl.pointerId, pointerType: dbl.pointerType }, e.isTrusted);
    }
  }
  let lastSize = "";
  let lastViewport = "";
  function reportSize() {
    const viewport = env.viewport();
    const msg = { type: "size", width: HTML.clientWidth, height: env.docHeight(), ...viewport };
    const key = JSON.stringify(msg);
    if (key !== lastSize) {
      lastSize = key;
      post(msg);
    }
    const vp = viewport.innerWidth + "x" + viewport.innerHeight;
    if (vp !== lastViewport) {
      lastViewport = vp;
      paintEverything();
    }
    if (paintPending && isConnectedOf(HTML)) {
      paintPending = false;
      schedulePaint();
    }
  }
  const resizeObserver = new ResizeObserver((entries) => {
    const out = [];
    for (const entry of entries) {
      const id = ids.get(entry.target);
      if (id !== void 0) out.push({ id, width: entry.contentRect.width, height: entry.contentRect.height });
    }
    if (out.length) post({ type: "resize", entries: out });
  });
  let paintOn = true;
  let paintReports = false;
  let lastPaintReport = "";
  const paint = new PaintCounter();
  const paintDirty = /* @__PURE__ */ new Set();
  const paintDirtySelf = /* @__PURE__ */ new Set();
  let paintAll = true;
  let paintFrame = 0;
  let paintPending = false;
  let paintStopped = false;
  let paintSheets = { siblings: false, structural: false, hover: false, active: false, styleAttr: false };
  const PAINT_STYLE_PROPS = /^--|opacity|filter|box-shadow|^display$|^all$/i;
  const PAINT_STYLE_TEXT = /--|\\|(?:opacity|filter|box-shadow|display|all)\s*:/i;
  const inlineHeavy = /* @__PURE__ */ new WeakSet();
  let pseudoSelector = "";
  let paintSheetsDirty = true;
  const widgetStyles = /* @__PURE__ */ new Set();
  const styleConnected = /* @__PURE__ */ new WeakMap();
  const scriptedCounted = /* @__PURE__ */ new Map();
  let scriptedPaint = /* @__PURE__ */ new WeakMap();
  const scriptedListened = /* @__PURE__ */ new WeakSet();
  const BEFORE = 1, AFTER = 2;
  const backdropOf = (cs) => cs.getPropertyValue("backdrop-filter") || cs.getPropertyValue("-webkit-backdrop-filter");
  function schedulePaint() {
    if (paintFrame || !paintOn || paintStopped || frozen) return;
    paintFrame = requestAnimationFrame(countPaint);
  }
  function paintChanged(el, siblings = false) {
    if (!paintOn || paintStopped || !(el instanceof Element)) return;
    const parent = siblings && (paintSheets.siblings || paintSheets.structural) ? parentNodeOf(el) : null;
    paintDirty.add(parent instanceof Element && ids.has(parent) ? parent : el);
    schedulePaint();
  }
  function paintEverything() {
    if (!paintOn || paintStopped) return;
    paintAll = true;
    schedulePaint();
  }
  function paintBefore(op) {
    if (op.op !== "rm" && op.op !== "ins") return;
    const node = nodes.get(op.id);
    if (!node || node === HTML || node === HEAD || node === BODY) return;
    const parent = parentNodeOf(node);
    if (!parent) return;
    if (node instanceof Element) clearBoxes(node);
    if (paintSheets.siblings || paintSheets.structural) paintChanged(parent);
  }
  function paintAfter(op) {
    switch (op.op) {
      case "el": {
        const el = nodes.get(op.id);
        if (el instanceof HTMLStyleElement) widgetStyles.add(el);
        if (el instanceof Element) {
          for (const [name, value] of op.attrs) if (name.toLowerCase() === "style" && PAINT_STYLE_TEXT.test(value)) inlineHeavy.add(el);
        }
        if (op.adopt) paintChanged(el);
        return;
      }
      case "style": {
        if (!paintSheets.styleAttr && !PAINT_STYLE_PROPS.test(op.name)) return;
        const el = nodes.get(op.id);
        if (el instanceof Element) inlineHeavy.add(el);
        paintChanged(el, true);
        return;
      }
      case "attr":
      case "rattr": {
        const el = nodes.get(op.id);
        if (!(el instanceof Element)) return;
        if (el instanceof HTMLStyleElement) {
          paintSheetsDirty = true;
          paintEverything();
          return;
        }
        if (op.name.toLowerCase() === "style") {
          const had = inlineHeavy.has(el), has = op.op === "attr" && PAINT_STYLE_TEXT.test(op.value);
          if (has) inlineHeavy.add(el);
          else inlineHeavy.delete(el);
          if (!had && !has && !paintSheets.styleAttr) return;
        }
        paintChanged(el, true);
        return;
      }
      case "ins": {
        if (op.parent === 0) return;
        const node = nodes.get(op.id);
        if (node instanceof Element) paintChanged(node, true);
        else if (node && paintSheets.structural) paintChanged(parentNodeOf(node), true);
        return;
      }
      case "data":
        if (paintSheets.structural) paintChanged(parentNodeOf(nodes.get(op.id) ?? null), true);
        return;
      case "css":
        paintSheetsDirty = true;
        paintEverything();
        return;
    }
  }
  function refreshSheets() {
    let changed = paintSheetsDirty;
    for (const el of widgetStyles) {
      const on = isConnectedOf(el);
      if (styleConnected.get(el) !== on) {
        styleConnected.set(el, on);
        changed = true;
      }
    }
    if (!changed) return;
    paintSheetsDirty = false;
    paintAll = true;
    const flags = { siblings: false, structural: false, hover: false, active: false, styleAttr: false };
    const pseudo = [];
    const inspect = (selector) => {
      const bare = selector.replace(/"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'/g, '""').replace(/\[[^\]]*\]/g, "[]");
      if (/[+~]/.test(bare.replace(/:nth-[a-z-]+\([^)]*\)/gi, ""))) flags.siblings = true;
      if (/:(nth-|first-child|last-child|only-child|first-of-type|last-of-type|only-of-type|empty)/i.test(bare)) flags.structural = true;
      if (/:hover/i.test(bare)) flags.hover = true;
      if (/:active/i.test(bare)) flags.active = true;
      if (/\[\s*style\b/i.test(selector)) flags.styleAttr = true;
      if (!/::?(before|after)\b/i.test(bare)) return;
      let depth = 0, from = 0;
      const parts = [];
      for (let i = 0; i <= selector.length; i++) {
        const c = selector[i];
        if (c === "(") depth++;
        else if (c === ")") depth--;
        else if (c === "," && depth === 0 || c === void 0) {
          parts.push(selector.slice(from, i));
          from = i + 1;
        }
      }
      for (const part of parts) {
        if (!/::?(before|after)\b/i.test(part)) continue;
        pseudo.push(part.replace(/(^|[\s>+~(,])::?(before|after)\b/gi, "$1*").replace(/::?(before|after)\b/gi, "").trim() || "*");
      }
    };
    const walk = (rules) => {
      for (let i = 0; i < rules.length; i++) {
        const r = rules[i];
        if (typeof r.selectorText === "string") inspect(r.selectorText);
        if (r.cssRules) walk(r.cssRules);
      }
    };
    for (const el of widgetStyles) {
      const sheet = sheetOf(el);
      if (sheet) try {
        walk(sheet.cssRules);
      } catch {
      }
    }
    paintSheets = flags;
    pseudoSelector = pseudo.join(",");
    if (pseudoSelector) try {
      matches(HTML, pseudoSelector);
    } catch {
      pseudoSelector = "*";
    }
  }
  function clearBoxes(el) {
    const id = ids.get(el);
    if (id !== void 0) {
      paint.removeBox(id * 4);
      paint.removeBox(id * 4 + BEFORE);
      paint.removeBox(id * 4 + AFTER);
    }
    for (let c = firstChildOf(el); c; c = nextSiblingOf(c)) if (c instanceof Element) clearBoxes(c);
  }
  function buttonState(el) {
    if (!(el instanceof HTMLButtonElement)) return void 0;
    if (getAttribute(el, "disabled") !== null) return "disabled";
    return matches(el, ":active") ? "pressed" : void 0;
  }
  function stylePaint(cs, display, pseudo, el) {
    return boxPaint({ display, content: pseudo ? cs.content : void 0, boxShadow: cs.boxShadow, filter: cs.filter, backdropFilter: backdropOf(cs), opacity: cs.opacity, button: el ? buttonState(el) : void 0 }, pseudo);
  }
  function pseudoPaint(el, key, which) {
    const cs = getComputedStyle(el, which);
    paint.setBox(key, stylePaint(cs, cs.display, true));
  }
  function scanBoxes(el, hidden) {
    const id = ids.get(el);
    if (id === void 0) return;
    if (hidden) return clearBoxes(el);
    const cs = getComputedStyle(el);
    const display = cs.display;
    if (hidesSubtree(display)) return clearBoxes(el);
    const key = id * 4;
    paint.setBox(key, stylePaint(cs, display, false, el));
    if (pseudoSelector && matches(el, pseudoSelector)) {
      pseudoPaint(el, key + BEFORE, "::before");
      pseudoPaint(el, key + AFTER, "::after");
    } else {
      paint.setBox(key + BEFORE, null);
      paint.setBox(key + AFTER, null);
    }
    for (let c = firstChildOf(el); c; c = nextSiblingOf(c)) if (c instanceof Element) scanBoxes(c, false);
  }
  function hiddenAt(n, memo) {
    if (!(n instanceof Element)) return false;
    let v = memo.get(n);
    if (v !== void 0) return v;
    v = hidesSubtree(getComputedStyle(n).display) || n !== HTML && hiddenAt(parentNodeOf(n), memo);
    memo.set(n, v);
    return v;
  }
  function coveredByDirty(el) {
    for (let p = el === HTML ? null : parentNodeOf(el); p instanceof Element; p = p === HTML ? null : parentNodeOf(p)) if (paintDirty.has(p)) return true;
    return false;
  }
  function syncScriptedPaint() {
    for (const [aid, key] of scriptedCounted) {
      if (animations.scripted.has(aid)) continue;
      paint.endAnimation(key, "w:" + aid);
      scriptedCounted.delete(aid);
    }
    for (const [aid, a] of animations.scripted) {
      if (!scriptedListened.has(a)) {
        scriptedListened.add(a);
        a.addEventListener("finish", schedulePaint);
        a.addEventListener("cancel", schedulePaint);
      }
      const name = "w:" + aid;
      let key = -1;
      let p = null;
      const effect = a.effect;
      const id = a.playState === "running" && effect?.target ? ids.get(effect.target) : void 0;
      if (id !== void 0) {
        p = scriptedPaint.get(a);
        if (p === void 0) {
          let frames = [];
          try {
            frames = effect.getKeyframes();
          } catch {
          }
          p = animationPaint(frames);
          scriptedPaint.set(a, p);
        }
        if (p) key = id * 4;
      }
      const was = scriptedCounted.get(aid);
      if (was !== void 0 && (was !== key || !paint.animating(was, name))) {
        paint.endAnimation(was, name);
        scriptedCounted.delete(aid);
        const target = nodes.get(Math.floor(was / 4));
        if (target instanceof Element) {
          paintDirtySelf.add(target);
          schedulePaint();
        }
      }
      if (p && key >= 0 && !paint.animating(key, name)) {
        paint.startAnimation(key, name, p);
        scriptedCounted.set(aid, key);
      }
    }
  }
  function countPaint() {
    paintFrame = 0;
    if (!paintOn || paintStopped || frozen || !HTML || !ids.has(HTML)) return;
    if (!isConnectedOf(HTML)) {
      paintPending = true;
      return;
    }
    refreshSheets();
    if (paintAll) {
      paintAll = false;
      paintDirty.clear();
      paintDirtySelf.clear();
      scanBoxes(HTML, false);
    } else {
      const memo = /* @__PURE__ */ new Map();
      for (const el of paintDirty) {
        if (!ids.has(el) || !isConnectedOf(el) || coveredByDirty(el)) continue;
        scanBoxes(el, el !== HTML && hiddenAt(parentNodeOf(el), memo));
      }
      for (const el of paintDirtySelf) {
        const id = ids.get(el);
        if (id === void 0 || paintDirty.has(el) || !isConnectedOf(el) || coveredByDirty(el) || hiddenAt(el, memo)) continue;
        const cs = getComputedStyle(el);
        paint.setBox(id * 4, stylePaint(cs, cs.display, false, el));
        if (pseudoSelector && matches(el, pseudoSelector)) {
          pseudoPaint(el, id * 4 + BEFORE, "::before");
          pseudoPaint(el, id * 4 + AFTER, "::after");
        }
      }
      paintDirty.clear();
      paintDirtySelf.clear();
    }
    if (animations.scripted.size || scriptedCounted.size) syncScriptedPaint();
    if (paintReports) {
      const key = paint.heavy + ":" + paint.backdrop;
      if (key !== lastPaintReport) {
        lastPaintReport = key;
        post({ type: "paint", heavy: paint.heavy, backdrop: paint.backdrop });
      }
    }
    const verdict = paint.check();
    if (verdict) stopPaint(verdict);
  }
  function onPaintAnimation(e) {
    if (!paintOn || paintStopped || frozen) return;
    const el = e.target;
    const id = el instanceof Element ? ids.get(el) : void 0;
    if (id === void 0) return;
    const ev = e;
    const pseudo = ev.pseudoElement || "";
    const slot = pseudo === "" ? 0 : pseudo === "::before" ? BEFORE : pseudo === "::after" ? AFTER : -1;
    if (slot < 0) return;
    const key = id * 4 + slot;
    const transition = e.type.startsWith("transition");
    const name = transition ? "t:" + ev.propertyName : "a:" + ev.animationName;
    if (e.type === "animationstart" || e.type === "transitionstart") {
      const p = cssAnimationPaint(el, transition, transition ? ev.propertyName : ev.animationName, pseudo);
      if (!p) return;
      paint.startAnimation(key, name, p);
    } else {
      if (!paint.animating(key, name)) return;
      paint.endAnimation(key, name);
      paintDirtySelf.add(el);
    }
    schedulePaint();
  }
  function cssAnimationPaint(el, transition, name, pseudo) {
    const Kind = transition ? typeof CSSTransition === "undefined" ? null : CSSTransition : typeof CSSAnimation === "undefined" ? null : CSSAnimation;
    if (Kind) {
      for (const a of getAnimationsOf(el, pseudo ? { subtree: true } : void 0)) {
        if (!(a instanceof Kind) || (transition ? a.transitionProperty : a.animationName) !== name) continue;
        const effect = a.effect;
        if (!effect || effect.target !== el || (effect.pseudoElement ?? "") !== pseudo) continue;
        try {
          return animationPaint(effect.getKeyframes());
        } catch {
          break;
        }
      }
    }
    return transition ? animationPaint([{ offset: 0, [name]: null }, { offset: 1, [name]: null }]) : null;
  }
  function onPaintInput(e) {
    if (!paintOn || paintStopped || frozen) return;
    const type = e.type;
    if (type === "toggle") return paintChanged(e.target, true);
    if (type === "pointerover" || type === "pointerout") {
      if (!paintSheets.hover) return;
      const a = chainOf(e.target), b = chainOf(e.relatedTarget);
      const inA = new Set(a), inB = new Set(b);
      for (const el of a) if (!inB.has(el)) paintChanged(el, true);
      for (const el of b) if (!inA.has(el)) paintChanged(el, true);
      return;
    }
    for (const el of chainOf(e.target)) {
      if (paintSheets.active) paintChanged(el, true);
      else {
        paintDirtySelf.add(el);
        schedulePaint();
      }
    }
  }
  function chainOf(t) {
    const out = [];
    for (let n = t instanceof Element ? t : null; n instanceof Element; n = n === HTML ? null : parentNodeOf(n)) if (ids.has(n)) out.push(n);
    return out;
  }
  function stopPaint(v) {
    paintStopped = true;
    if (paintFrame) {
      cancelAnimationFrame(paintFrame);
      paintFrame = 0;
    }
    drawWithoutEffects();
    post({ type: "limit", code: v.code, count: v.count });
  }
  const NO_EFFECTS_CSS = "@layer tw-no-effects{*,::before,::after{filter:none!important;-webkit-backdrop-filter:none!important;backdrop-filter:none!important;transition:none!important}:not(button[disabled]),::before,::after{opacity:1!important}::before,::after{box-shadow:none!important}}";
  function drawWithoutEffects() {
    try {
      for (const a of getAnimationsOf(HTML, { subtree: true })) {
        try {
          if (typeof CSSTransition !== "undefined" && a instanceof CSSTransition) a.cancel();
          else a.pause();
        } catch {
        }
      }
    } catch {
    }
    const fixes = [];
    const visit = (el) => {
      if (!ids.has(el)) return;
      const cs = getComputedStyle(el);
      if (hidesSubtree(cs.display)) return;
      const style = styleOf(el);
      if (parseFloat(cs.opacity) === 0) fixes.push([style, "visibility", "hidden"]);
      if (boxShadowBlurred(cs.boxShadow)) fixes.push([style, "box-shadow", boxShadowWithoutBlur(cs.boxShadow)]);
      for (const prop of ["filter", "backdrop-filter", "-webkit-backdrop-filter", "opacity"]) {
        if (style.getPropertyValue(prop) && !(prop === "opacity" && buttonState(el) === "disabled")) fixes.push([style, prop, ""]);
      }
      for (let c = firstChildOf(el); c; c = nextSiblingOf(c)) if (c instanceof Element) visit(c);
    };
    visit(HTML);
    const sheet = createElement(doc, "style");
    setTextContent(sheet, NO_EFFECTS_CSS);
    insertBefore(HEAD, sheet, firstChildOf(HEAD));
    for (const [style, prop, value] of fixes) {
      if (value) style.setProperty(prop, value, "important");
      else style.removeProperty(prop);
    }
  }
  function onMessage(msg) {
    switch (msg.type) {
      case "ops":
        if (paintStopped) break;
        for (const op of msg.ops) {
          try {
            if (paintOn) paintBefore(op);
            applyOp(op);
          } catch (e) {
            violation("op failed: " + String(e));
          }
          if (paintOn) try {
            paintAfter(op);
          } catch {
          }
        }
        syncCanvas();
        reportSize();
        break;
      case "query": {
        let res;
        try {
          res = answer(msg.query);
        } catch (e) {
          res = { result: { error: String(e) } };
        }
        post({ type: "result", qid: msg.qid, result: res.result, binary: res.binary }, res.binary ? [res.binary] : []);
        break;
      }
      case "listen":
        interest = new Set(msg.types);
        break;
      case "preventDefault":
        preventKeys = new Set(msg.keys);
        break;
      case "anim":
        if (paintStopped) break;
        try {
          applyAnims(animations, msg.now, msg.anims, (id) => nodes.get(id));
        } catch (e) {
          violation("anim failed: " + String(e));
        }
        scriptedPaint = /* @__PURE__ */ new WeakMap();
        schedulePaint();
        break;
      case "requestFrame":
        if (frozen || paintStopped || frameReq) break;
        frameReq = requestAnimationFrame((time) => {
          frameReq = 0;
          post({ type: "frame", time });
        });
        break;
      case "frozen":
        freeze(String(msg.reason), !!msg.fatal);
        break;
      case "arbitrate":
        rtl = msg.rtl === true;
        bubbleMode = msg.bubble === true ? { touch: msg.touch === true, rtl } : null;
        break;
      case "theme":
        themeVars = themeVariables(msg.theme);
        applyThemeVariables();
        env.frameColorScheme?.(themeVars["--tg-color-scheme"] === "dark" ? "dark" : "light");
        canvasDirty = true;
        syncCanvas();
        paintEverything();
        break;
      case "safeArea":
        safeAreaVars = contentSafeAreaVariables(msg.inset);
        applyThemeVariables();
        paintEverything();
        break;
      case "policy": {
        const on = msg.policy !== "compat";
        paintReports = msg.paintReports === true;
        lastPaintReport = "";
        if (on && !paintOn) paintAll = true;
        paintOn = on;
        if (!on && paintFrame) {
          cancelAnimationFrame(paintFrame);
          paintFrame = 0;
        }
        schedulePaint();
        break;
      }
    }
  }
  let themeVars = {};
  let safeAreaVars = contentSafeAreaVariables(null);
  function applyThemeVariables() {
    if (!HTML) return;
    const style = styleOf(HTML);
    for (const name of THEME_VARIABLES) {
      const v = themeVars[name] ?? safeAreaVars[name];
      if (v === void 0) style.removeProperty(name);
      else style.setProperty(name, v, "important");
    }
  }
  let canvasDirty = true;
  const CANVAS_PROPS = ["background-color", "background-image", "background-position", "background-size", "background-repeat", "background-origin", "background-clip"];
  const transparentColor = (c) => c === "transparent" || /^rgba\(\s*0,\s*0,\s*0,\s*0\s*\)$/.test(c);
  function syncCanvas() {
    const canvas = env.canvas;
    if (!canvas || !canvasDirty || !HTML || !BODY) return;
    canvasDirty = false;
    const root2 = getComputedStyle(HTML);
    const src = root2.backgroundImage !== "none" || !transparentColor(root2.backgroundColor) ? root2 : getComputedStyle(BODY);
    const style = styleOf(canvas);
    for (const p of CANVAS_PROPS) style.setProperty(p, src.getPropertyValue(p));
  }
  function selectable(t) {
    let el = t instanceof Element ? t : t instanceof Node ? t.parentElement : null;
    while (el) {
      const cs = getComputedStyle(el);
      const v = cs.userSelect || cs.webkitUserSelect;
      if (v && v !== "auto") return v !== "none";
      if (el === HTML) return false;
      el = el.parentElement;
    }
    return false;
  }
  function freeze(reason, fatal) {
    if (frozen) return;
    frozen = true;
    if (frameReq) {
      cancelAnimationFrame(frameReq);
      frameReq = 0;
    }
    if (moveFrame) {
      cancelAnimationFrame(moveFrame);
      moveFrame = 0;
    }
    pendingMoves.clear();
    setAttribute(HTML, "data-tw-frozen", fatal ? "fatal" : "paused");
    const style = createElement(doc, "style");
    setTextContent(style, "[data-tw-frozen]{pointer-events:none}[data-tw-frozen=fatal]{filter:grayscale(.3)}[data-tw-badge]{position:fixed;right:6px;bottom:6px;z-index:2147483647;font:11px/1.3 system-ui,sans-serif;color:#fff;background:rgba(60,60,60,.75);padding:2px 7px;border-radius:9px;pointer-events:none;user-select:none}");
    insertBefore(HEAD, style, null);
    const badge = createElement(doc, "div");
    setAttribute(badge, "data-tw-badge", fatal ? "fatal" : "paused");
    setTextContent(badge, reason);
    insertBefore(BODY, badge, null);
  }
  let sizeObservers = [];
  let offViewport = null;
  function swallow(e) {
    if (e.type === "mousedown" || e.type === "selectstart") {
      if (e.cancelable && !selectable(e.target)) e.preventDefault();
      return;
    }
    if (e.type === "focusin") {
      const t = e.target;
      if (t instanceof HTMLElement || t instanceof SVGElement) (t instanceof SVGElement ? SVGElement.prototype.blur : HTMLElement.prototype.blur).call(t);
      return;
    }
    if (e.cancelable) e.preventDefault();
  }
  const ownPointers = /* @__PURE__ */ new Set();
  let changedOwn = false;
  const fingersDown = /* @__PURE__ */ new Set();
  let changedFingerDown = false;
  const isFingerOrPen = (e) => e.pointerType === "touch" || e.pointerType === "pen";
  function pressedHere(e) {
    if (!e.isTrusted) return;
    const id = e.pointerId;
    ownPointers.add(id);
    if (isFingerOrPen(e)) fingersDown.add(id);
    changedOwn = true;
    changedFingerDown = fingersDown.has(id);
  }
  function buttonsChanged(e) {
    if (!e.isTrusted || e.button === -1) return;
    const id = e.pointerId;
    changedOwn = ownPointers.has(id);
    changedFingerDown = fingersDown.has(id);
  }
  function letGo(e) {
    const id = e.pointerId;
    changedOwn = ownPointers.delete(id);
    fingersDown.delete(id);
    changedFingerDown = false;
  }
  function init(s) {
    send = s;
    ({ html: HTML, head: HEAD, body: BODY } = env.roots());
    const ua = createElement(doc, "style");
    setTextContent(ua, PROFILE_UA_STYLESHEET);
    insertBefore(HEAD, ua, firstChildOf(HEAD));
    root.addEventListener("pointerdown", pressedHere, true);
    root.addEventListener("pointermove", buttonsChanged, true);
    window.addEventListener("pointerup", letGo, true);
    window.addEventListener("pointercancel", letGo, true);
    for (const type of SWALLOWED) root.addEventListener(type, swallow, { capture: true, passive: false });
    for (const type of ALL_EVENTS) root.addEventListener(type, onEvent, { capture: true, passive: false });
    if (root instanceof ShadowRoot) for (const type of ENTER_LEAVE) root.host.addEventListener(type, noop, true);
    for (const type of ["auxclick", "dragstart", "dblclick"]) root.addEventListener(type, (e) => e.preventDefault(), true);
    for (const type of PAINT_ANIMATION_EVENTS) root.addEventListener(type, onPaintAnimation, true);
    for (const type of PAINT_INPUT_EVENTS) root.addEventListener(type, onPaintInput, true);
    sizeObservers = [new ResizeObserver(reportSize), new ResizeObserver(reportSize)];
    sizeObservers[0].observe(HTML);
    sizeObservers[1].observe(BODY);
    const offResize = env.onViewportResize(reportSize);
    const offScheme = env.onColorSchemeChange(() => post({ type: "media" }));
    offViewport = () => {
      offResize();
      offScheme();
    };
    reportSize();
  }
  function destroy() {
    for (const type of ALL_EVENTS) root.removeEventListener(type, onEvent, { capture: true });
    for (const type of SWALLOWED) root.removeEventListener(type, swallow, { capture: true });
    root.removeEventListener("pointerdown", pressedHere, true);
    root.removeEventListener("pointermove", buttonsChanged, true);
    window.removeEventListener("pointerup", letGo, true);
    window.removeEventListener("pointercancel", letGo, true);
    ownPointers.clear();
    fingersDown.clear();
    if (root instanceof ShadowRoot) for (const type of ENTER_LEAVE) root.host.removeEventListener(type, noop, true);
    for (const type of PAINT_ANIMATION_EVENTS) root.removeEventListener(type, onPaintAnimation, true);
    for (const type of PAINT_INPUT_EVENTS) root.removeEventListener(type, onPaintInput, true);
    if (paintFrame) {
      cancelAnimationFrame(paintFrame);
      paintFrame = 0;
    }
    for (const o of sizeObservers) o.disconnect();
    sizeObservers = [];
    offViewport?.();
    offViewport = null;
    resizeObserver.disconnect();
    if (frameReq) {
      cancelAnimationFrame(frameReq);
      frameReq = 0;
    }
    if (moveFrame) {
      cancelAnimationFrame(moveFrame);
      moveFrame = 0;
    }
    clearHold();
    send = () => {
    };
  }
  return { init, onMessage, destroy };
}
export {
  createRenderer,
  toBase64
};
