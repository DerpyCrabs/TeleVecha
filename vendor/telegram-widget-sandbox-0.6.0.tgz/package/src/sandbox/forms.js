import { callMethod, markDirty } from "./capture";
import { document } from "./dom";
import { unsupported } from "./host";
import { elQuery } from "./layout";
const activePointers = /* @__PURE__ */ new Set();
const pointerCaptures = /* @__PURE__ */ new Map();
function pointerEventTarget(target, event) {
  const id = Number(event.pointerId) || 1;
  if (event.type === "pointerdown") {
    activePointers.add(id);
    pointerCaptures.delete(id);
  }
  if (["pointermove", "pointerup", "pointercancel"].includes(event.type)) {
    const captured = pointerCaptures.get(id);
    if (captured?.isConnected) return captured;
    pointerCaptures.delete(id);
  }
  return target;
}
function finishPointerEvent(event) {
  if (event.type === "pointerup" || event.type === "pointercancel") {
    const id = Number(event.pointerId) || 1;
    activePointers.delete(id);
    pointerCaptures.delete(id);
  }
}
const STATE = /* @__PURE__ */ Symbol("tw.state");
function st(el) {
  return el[STATE] ?? Object.defineProperty(el, STATE, { value: { dirty: /* @__PURE__ */ new Set() }, enumerable: false })[STATE];
}
function setState(el, name, value) {
  const s = st(el);
  s[name] = value;
  s.dirty.add(name);
  markDirty(el);
}
function emitProps(el, id, push, isNew) {
  const s = el[STATE];
  if (!s) return;
  const names = isNew ? ["value", "checked", "selectedIndex", "indeterminate"].filter((n) => s[n] !== void 0) : [...s.dirty];
  for (const name of names) push({ op: "prop", id, name, value: s[name] });
  s.dirty.clear();
}
const tag = (el) => el.localName;
const optionsOf = (select) => [...select.querySelectorAll("option")];
function formOwner(el) {
  const id = el.getAttribute("form");
  if (id !== null) {
    const owner = document.getElementById(id);
    return owner?.localName === "form" ? owner : null;
  }
  return el.closest("form");
}
function controlDisabled(el) {
  if (el.hasAttribute("disabled")) return true;
  for (let parent = el.parentElement; parent; parent = parent.parentElement) {
    if (parent.localName !== "fieldset" || !parent.hasAttribute("disabled")) continue;
    const legend = [...parent.children].find((child) => child.localName === "legend");
    if (!legend?.contains(el)) return true;
  }
  return false;
}
function activateFormControl(target) {
  const control = target?.closest?.("button,input");
  if (!control || controlDisabled(control)) return;
  const attr = (control.getAttribute("type") ?? "").toLowerCase();
  const type = control.localName === "button" && !["button", "reset"].includes(attr) ? "submit" : attr;
  if (!["submit", "image"].includes(type)) return;
  const form = formOwner(control);
  if (!form) return;
  if (form.hasAttribute("novalidate") || control.hasAttribute("formnovalidate") || form.checkValidity()) form.requestSubmit(control);
}
function selectIndex(select) {
  const s = st(select);
  if (s.selectedIndex !== void 0) return s.selectedIndex;
  const opts = optionsOf(select);
  const i = opts.findIndex((o) => o.hasAttribute("selected"));
  if (i >= 0) return i;
  return select.hasAttribute("multiple") || !opts.length ? -1 : 0;
}
function optionValue(o) {
  return o.hasAttribute("value") ? o.getAttribute("value") : (o.textContent ?? "").trim().replace(/\s+/g, " ");
}
function inputDefault(el) {
  const attr = el.getAttribute("value");
  const type = (el.getAttribute("type") ?? "text").toLowerCase();
  if (type === "range") {
    const min = parseFloat(el.getAttribute("min") ?? "0") || 0;
    let max = parseFloat(el.getAttribute("max") ?? "100");
    if (isNaN(max)) max = 100;
    const v = attr === null ? max < min ? min : min + (max - min) / 2 : Math.min(Math.max(parseFloat(attr) || 0, min), Math.max(max, min));
    return String(v);
  }
  if (attr !== null) return attr;
  if (type === "color") return "#000000";
  if (type === "checkbox" || type === "radio") return "on";
  return "";
}
function radioGroup(el) {
  const name = el.getAttribute("name");
  if (!name) return [];
  const root = el.closest("form") ?? document;
  return [...root.querySelectorAll("input[type=radio]")].filter((r) => r !== el && r.getAttribute("name") === name);
}
function imageSize(el, dim) {
  if (el.isConnected) {
    const rendered = parseFloat(globalThis.getComputedStyle(el)[dim]);
    if (Number.isFinite(rendered)) return Math.trunc(rendered);
  }
  const attr = parseInt(el.getAttribute(dim) ?? "", 10);
  if (attr >= 0) return attr;
  return (dim === "width" ? st(el).naturalWidth : st(el).naturalHeight) ?? 0;
}
function applyEventState(el, ev) {
  const t = tag(el);
  if (t === "input") {
    const s = st(el);
    if (ev.value !== void 0) s.value = ev.value;
    if (ev.checked !== void 0) {
      s.checked = ev.checked;
      if (ev.checked && (el.getAttribute("type") ?? "").toLowerCase() === "radio") for (const r of radioGroup(el)) st(r).checked = false;
    }
  } else if (t === "textarea") {
    if (ev.value !== void 0) st(el).value = ev.value;
  } else if (t === "select") {
    if (ev.selectedIndex !== void 0) st(el).selectedIndex = ev.selectedIndex;
  } else if (t === "img" && (ev.type === "load" || ev.type === "error")) {
    const s = st(el);
    s.naturalWidth = ev.type === "load" ? ev.naturalWidth : 0;
    s.naturalHeight = ev.type === "load" ? ev.naturalHeight : 0;
    s.doneSrc = el.getAttribute("src") ?? "";
  } else if (t === "details" && ev.type === "toggle") {
    if (ev.open) el.setAttribute("open", "");
    else el.removeAttribute("open");
  }
}
function isChecked(el) {
  return st(el).checked ?? el.hasAttribute("checked");
}
function controlValue(el) {
  const t = tag(el);
  if (t === "input") return st(el).value ?? inputDefault(el);
  if (t === "textarea") return st(el).value ?? el.textContent ?? "";
  if (t === "select") {
    const o = optionsOf(el)[selectIndex(el)];
    return o ? optionValue(o) : "";
  }
  if (t === "option") return optionValue(el);
  return el.getAttribute("value") ?? "";
}
function formControls(form) {
  return [...form.querySelectorAll("input, select, textarea, button, output, fieldset")];
}
class FormData {
  _e = [];
  constructor(form) {
    if (!form) return;
    for (const el of formControls(form)) {
      const name = el.getAttribute("name");
      if (!name || el.hasAttribute("disabled")) continue;
      const t = tag(el);
      const type = (el.getAttribute("type") ?? "").toLowerCase();
      if (t === "button" || t === "fieldset" || t === "output" || type === "submit" || type === "button" || type === "reset" || type === "image" || type === "file") continue;
      if ((type === "checkbox" || type === "radio") && !isChecked(el)) continue;
      this._e.push([name, controlValue(el)]);
    }
  }
  append(k, v) {
    this._e.push([String(k), String(v)]);
  }
  set(k, v) {
    this.delete(k);
    this.append(k, v);
  }
  delete(k) {
    this._e = this._e.filter(([n]) => n !== k);
  }
  get(k) {
    return this._e.find(([n]) => n === k)?.[1] ?? null;
  }
  getAll(k) {
    return this._e.filter(([n]) => n === k).map(([, v]) => v);
  }
  has(k) {
    return this._e.some(([n]) => n === k);
  }
  forEach(cb) {
    for (const [k, v] of this._e) cb(v, k, this);
  }
  entries() {
    return this._e.map((e) => [...e])[Symbol.iterator]();
  }
  keys() {
    return this._e.map(([k]) => k)[Symbol.iterator]();
  }
  values() {
    return this._e.map(([, v]) => v)[Symbol.iterator]();
  }
  [Symbol.iterator]() {
    return this.entries();
  }
}
function define(proto, props) {
  for (const [name, d] of Object.entries(props)) {
    Object.defineProperty(proto, name, typeof d === "function" ? { value: d, writable: true, configurable: true } : { configurable: true, ...d });
  }
}
const reflectString = (attr, dflt = "") => ({
  get() {
    return this.getAttribute(attr) ?? dflt;
  },
  set(v) {
    this.setAttribute(attr, String(v));
  }
});
const reflectBool = (attr) => ({
  get() {
    return this.hasAttribute(attr);
  },
  set(v) {
    if (v) this.setAttribute(attr, "");
    else this.removeAttribute(attr);
  }
});
const reflectNumber = (attr, dflt) => ({
  get() {
    const n = parseInt(this.getAttribute(attr) ?? "", 10);
    return isNaN(n) ? dflt : n;
  },
  set(v) {
    this.setAttribute(attr, String(v));
  }
});
function validity(el) {
  return elQuery(el, { q: "validity" }, { valid: true, message: "" });
}
function installForms(protoOf, HTMLElementProto, ElementProto) {
  const sample = document.createElement("div");
  const generic = {
    hidden: reflectBool("hidden"),
    title: reflectString("title"),
    lang: reflectString("lang"),
    dir: reflectString("dir"),
    tabIndex: reflectNumber("tabindex", -1),
    draggable: reflectBool("draggable"),
    disabled: reflectBool("disabled"),
    name: reflectString("name"),
    type: reflectString("type"),
    placeholder: reflectString("placeholder"),
    readOnly: reflectBool("readonly"),
    required: reflectBool("required"),
    multiple: reflectBool("multiple"),
    min: reflectString("min"),
    max: reflectString("max"),
    step: reflectString("step"),
    pattern: reflectString("pattern"),
    maxLength: reflectNumber("maxlength", -1),
    minLength: reflectNumber("minlength", -1),
    htmlFor: reflectString("for"),
    alt: reflectString("alt"),
    src: reflectString("src"),
    href: reflectString("href"),
    target: reflectString("target"),
    rel: reflectString("rel"),
    colSpan: reflectNumber("colspan", 1),
    rowSpan: reflectNumber("rowspan", 1),
    open: reflectBool("open"),
    contentEditable: reflectString("contenteditable", "inherit"),
    accessKey: reflectString("accesskey"),
    autofocus: reflectBool("autofocus"),
    noValidate: reflectBool("novalidate"),
    role: reflectString("role"),
    ariaLabel: reflectString("aria-label"),
    ariaHidden: reflectString("aria-hidden"),
    ariaExpanded: reflectString("aria-expanded"),
    ariaSelected: reflectString("aria-selected"),
    ariaChecked: reflectString("aria-checked"),
    ariaPressed: reflectString("aria-pressed")
  };
  for (const [name, d] of Object.entries(generic)) if (!(name in sample)) define(HTMLElementProto, { [name]: d });
  const ownByName = /* @__PURE__ */ new Map();
  const inheritedByName = /* @__PURE__ */ new Map();
  const unscopableByTag = /* @__PURE__ */ new Map();
  const lookup = (proto, name) => {
    for (let p = proto; p; p = Object.getPrototypeOf(p)) {
      const d = Object.getOwnPropertyDescriptor(p, name);
      if (d) return d;
    }
    return void 0;
  };
  const descriptorOf = (el, name) => ownByName.get(name)?.get(el.localName) ?? inheritedByName.get(name);
  const dispatcher = (name) => ({
    configurable: true,
    get() {
      const d = descriptorOf(this, name);
      if (!d) return void 0;
      return d.get ? d.get.call(this) : d.value;
    },
    set(v) {
      const d = descriptorOf(this, name);
      if (d?.set) return d.set.call(this, v);
      if (d && !d.get && !d.writable) return;
      if (d?.get) return;
      Object.defineProperty(this, name, { value: v, writable: true, enumerable: true, configurable: true });
    }
  });
  const unscopablesBefore = HTMLElementProto[Symbol.unscopables];
  Object.defineProperty(HTMLElementProto, Symbol.unscopables, {
    configurable: true,
    get() {
      const tag2 = this && typeof this.localName === "string" ? this.localName : "";
      let hidden = unscopableByTag.get(tag2);
      if (!hidden) {
        hidden = Object.assign(/* @__PURE__ */ Object.create(null), unscopablesBefore);
        for (const [name, own] of ownByName) if (!own.has(tag2) && !inheritedByName.get(name)) hidden[name] = true;
        unscopableByTag.set(tag2, hidden);
      }
      return hidden;
    }
  });
  const defineOwn = (tag2, props) => {
    const proto = protoOf(tag2);
    if (proto !== HTMLElementProto) return define(proto, props);
    unscopableByTag.clear();
    for (const [name, d] of Object.entries(props)) {
      let own = ownByName.get(name);
      if (!own) {
        ownByName.set(name, own = /* @__PURE__ */ new Map());
        inheritedByName.set(name, lookup(HTMLElementProto, name));
        Object.defineProperty(HTMLElementProto, name, dispatcher(name));
      }
      own.set(tag2, typeof d === "function" ? { value: d, writable: true, configurable: true } : { configurable: true, ...d });
    }
  };
  define(ElementProto, {
    focus() {
      callMethod(this, "focus");
    },
    blur() {
      callMethod(this, "blur");
    },
    scrollIntoView(options = true) {
      const o = options != null && (typeof options === "object" || typeof options === "function") ? options : {};
      const enumIndex = (value, values, fallback) => {
        if (value === void 0) return fallback;
        const index = values.indexOf(String(value));
        if (index < 0) throw new TypeError("Invalid scrollIntoView option");
        return index;
      };
      const behavior = enumIndex(o.behavior, ["auto", "instant", "smooth"], 0);
      const block = enumIndex(o.block, ["start", "center", "end", "nearest"], options != null && typeof options !== "object" && typeof options !== "function" && !options ? 2 : 0);
      const container = enumIndex(o.container, ["all", "nearest"], 0);
      const inline = enumIndex(o.inline, ["start", "center", "end", "nearest"], 3);
      callMethod(this, "scrollIntoView", [block, inline, behavior, container]);
    },
    scrollTo(x, y) {
      const o = typeof x === "object" && x ? x : { left: x, top: y };
      callMethod(this, "scrollTo", [Number(o.left) || 0, Number(o.top) || 0]);
    },
    scrollBy(x, y) {
      const o = typeof x === "object" && x ? x : { left: x, top: y };
      callMethod(this, "scrollBy", [Number(o.left) || 0, Number(o.top) || 0]);
    },
    setPointerCapture(id) {
      id = Number(id) || 0;
      if (!activePointers.has(id) || !this.isConnected) return;
      pointerCaptures.set(id, this);
      callMethod(this, "setPointerCapture", [id]);
    },
    releasePointerCapture(id) {
      id = Number(id) || 0;
      if (pointerCaptures.get(id) !== this) return;
      pointerCaptures.delete(id);
      callMethod(this, "releasePointerCapture", [id]);
    },
    hasPointerCapture(id) {
      return pointerCaptures.get(Number(id)) === this;
    },
    showPopover() {
      callMethod(this, "showPopover");
    },
    hidePopover() {
      callMethod(this, "hidePopover");
    },
    togglePopover() {
      callMethod(this, "togglePopover");
    },
    requestFullscreen() {
      unsupported("Element.requestFullscreen");
      return Promise.reject(new Error("Fullscreen is not available"));
    },
    animate() {
      unsupported("Element.animate (Web Animations API)");
      const done = Promise.resolve();
      return { finished: done, ready: done, cancel() {
      }, finish() {
      }, play() {
      }, pause() {
      }, reverse() {
      }, onfinish: null, addEventListener() {
      }, removeEventListener() {
      }, playState: "finished", currentTime: 0 };
    },
    getAnimations() {
      return [];
    },
    attachShadow() {
      unsupported("Element.attachShadow (shadow DOM is not rendered)");
      throw new Error("NotSupportedError: shadow DOM is not available");
    }
  });
  const input = protoOf("input");
  define(input, {
    value: { get() {
      return controlValue(this);
    }, set(v) {
      setState(this, "value", v === null ? "" : String(v));
    } },
    defaultValue: reflectString("value"),
    checked: { get() {
      return isChecked(this);
    }, set(v) {
      setState(this, "checked", !!v);
      if (v && this.type === "radio") for (const r of radioGroup(this)) st(r).checked = false;
    } },
    defaultChecked: reflectBool("checked"),
    indeterminate: { get() {
      return st(this).indeterminate ?? false;
    }, set(v) {
      setState(this, "indeterminate", !!v);
    } },
    type: { get() {
      return (this.getAttribute("type") ?? "text").toLowerCase();
    }, set(v) {
      this.setAttribute("type", String(v));
    } },
    valueAsNumber: {
      get() {
        const v = controlValue(this);
        return v === "" ? NaN : Number(v);
      },
      set(v) {
        setState(this, "value", String(v));
      }
    },
    valueAsDate: { get() {
      const v = controlValue(this);
      const d = new Date(v);
      return v && !isNaN(d.getTime()) ? d : null;
    } },
    files: { get() {
      return null;
    } },
    select() {
      callMethod(this, "select");
    },
    setSelectionRange(a, b) {
      callMethod(this, "setSelectionRange", [Number(a) || 0, Number(b) || 0]);
    },
    selectionStart: { get() {
      return controlValue(this).length;
    }, set() {
    } },
    selectionEnd: { get() {
      return controlValue(this).length;
    }, set() {
    } },
    stepUp(n = 1) {
      setState(this, "value", String((Number(controlValue(this)) || 0) + n * (Number(this.getAttribute("step")) || 1)));
    },
    stepDown(n = 1) {
      setState(this, "value", String((Number(controlValue(this)) || 0) - n * (Number(this.getAttribute("step")) || 1)));
    }
  });
  defineOwn("textarea", {
    value: { get() {
      return controlValue(this);
    }, set(v) {
      setState(this, "value", v === null ? "" : String(v));
    } },
    defaultValue: { get() {
      return this.textContent;
    }, set(v) {
      this.textContent = v;
    } },
    select() {
      callMethod(this, "select");
    },
    setSelectionRange(a, b) {
      callMethod(this, "setSelectionRange", [Number(a) || 0, Number(b) || 0]);
    },
    rows: reflectNumber("rows", 2),
    cols: reflectNumber("cols", 20)
  });
  defineOwn("select", {
    options: { get() {
      return optionsOf(this);
    } },
    length: { get() {
      return optionsOf(this).length;
    } },
    selectedIndex: { get() {
      return selectIndex(this);
    }, set(v) {
      setState(this, "selectedIndex", Number(v) | 0);
    } },
    selectedOptions: { get() {
      const o = optionsOf(this)[selectIndex(this)];
      return o ? [o] : [];
    } },
    value: {
      get() {
        return controlValue(this);
      },
      set(v) {
        setState(this, "selectedIndex", optionsOf(this).findIndex((o) => optionValue(o) === String(v)));
      }
    },
    add(option, before) {
      this.insertBefore(option, typeof before === "number" ? optionsOf(this)[before] ?? null : before ?? null);
    },
    item(i) {
      return optionsOf(this)[i] ?? null;
    }
  });
  defineOwn("option", {
    value: { get() {
      return optionValue(this);
    }, set(v) {
      this.setAttribute("value", String(v));
    } },
    text: { get() {
      return (this.textContent ?? "").trim();
    }, set(v) {
      this.textContent = v;
    } },
    label: { get() {
      return this.getAttribute("label") ?? (this.textContent ?? "").trim();
    }, set(v) {
      this.setAttribute("label", String(v));
    } },
    index: { get() {
      const s = this.closest("select");
      return s ? optionsOf(s).indexOf(this) : 0;
    } },
    selected: {
      get() {
        const s = this.closest("select");
        return s ? optionsOf(s)[selectIndex(s)] === this : this.hasAttribute("selected");
      },
      set(v) {
        const s = this.closest("select");
        if (!s) return v ? this.setAttribute("selected", "") : this.removeAttribute("selected");
        if (v) setState(s, "selectedIndex", optionsOf(s).indexOf(this));
        else if (optionsOf(s)[selectIndex(s)] === this) setState(s, "selectedIndex", s.hasAttribute("multiple") ? -1 : 0);
      }
    },
    defaultSelected: reflectBool("selected")
  });
  for (const t of ["input", "textarea", "select", "button", "output", "fieldset"]) {
    defineOwn(t, {
      form: { get() {
        return formOwner(this);
      } },
      labels: { get() {
        const id = this.getAttribute("id");
        return [...document.querySelectorAll("label")].filter((l) => l.contains(this) || id && l.getAttribute("for") === id);
      } },
      validity: { get() {
        return validity(this);
      } },
      validationMessage: { get() {
        return validity(this).message ?? "";
      } },
      willValidate: { get() {
        return true;
      } },
      checkValidity() {
        return validity(this).valid !== false;
      },
      reportValidity() {
        return validity(this).valid !== false;
      },
      setCustomValidity() {
        unsupported("setCustomValidity");
      }
    });
  }
  defineOwn("button", {
    type: { get() {
      return (this.getAttribute("type") ?? "submit").toLowerCase();
    }, set(v) {
      this.setAttribute("type", String(v));
    } },
    value: reflectString("value")
  });
  defineOwn("label", { control: { get() {
    const f = this.getAttribute("for");
    return f ? document.getElementById(f) : this.querySelector("input, select, textarea, button");
  } } });
  for (const t of ["progress", "meter"]) {
    defineOwn(t, {
      value: { get() {
        return Number(this.getAttribute("value") ?? 0);
      }, set(v) {
        this.setAttribute("value", String(v));
      } },
      max: { get() {
        return Number(this.getAttribute("max") ?? 1);
      }, set(v) {
        this.setAttribute("max", String(v));
      } }
    });
  }
  defineOwn("output", { value: { get() {
    return this.textContent;
  }, set(v) {
    this.textContent = v;
  } } });
  defineOwn("form", {
    elements: {
      get() {
        const list = formControls(this);
        for (const el of list) {
          const n = el.getAttribute("name") || el.getAttribute("id");
          if (n && !(n in list)) list[n] = el;
        }
        list.namedItem = (n) => list[n] ?? null;
        return list;
      }
    },
    length: { get() {
      return formControls(this).length;
    } },
    reset() {
      for (const el of formControls(this)) {
        const s = el[STATE];
        if (s) {
          s.value = s.checked = s.selectedIndex = void 0;
          s.dirty.clear();
        }
      }
      callMethod(this, "reset");
      this.dispatchEvent(new globalThis.Event("reset", { bubbles: true }));
    },
    submit() {
      unsupported("form.submit() (navigation is disabled; handle the submit event instead)");
    },
    requestSubmit(submitter) {
      this.dispatchEvent(new globalThis.SubmitEvent("submit", { bubbles: true, cancelable: true, submitter }));
    },
    checkValidity() {
      return formControls(this).every((el) => typeof el.checkValidity !== "function" || el.checkValidity());
    },
    reportValidity() {
      return this.checkValidity();
    },
    action: reflectString("action"),
    method: reflectString("method", "get")
  });
  defineOwn("dialog", {
    showModal() {
      this.setAttribute("open", "");
      callMethod(this, "showModal");
    },
    show() {
      this.setAttribute("open", "");
    },
    close(value) {
      if (value !== void 0) this.returnValue = value;
      this.removeAttribute("open");
      callMethod(this, "close");
      this.dispatchEvent(new globalThis.Event("close"));
    },
    returnValue: { value: "", writable: true }
  });
  defineOwn("img", {
    naturalWidth: { get() {
      return st(this).naturalWidth ?? 0;
    } },
    naturalHeight: { get() {
      return st(this).naturalHeight ?? 0;
    } },
    complete: { get() {
      const src = this.getAttribute("src");
      return !src || st(this).doneSrc === src;
    } },
    // The rendered size when the image is rendered, else the attribute, else the natural size (HTML's width/height IDL attributes).
    width: { get() {
      return imageSize(this, "width");
    }, set(v) {
      this.setAttribute("width", String(Number(v) >>> 0));
    } },
    height: { get() {
      return imageSize(this, "height");
    }, set(v) {
      this.setAttribute("height", String(Number(v) >>> 0));
    } },
    decode() {
      return Promise.resolve();
    }
  });
  const rowsOf = (root) => {
    const out = [];
    for (const c of root.children) {
      if (c.localName === "tr") out.push(c);
      else if (["thead", "tbody", "tfoot"].includes(c.localName)) {
        for (const r of c.children) if (r.localName === "tr") out.push(r);
      }
    }
    return out;
  };
  const insertRow = function(index = -1) {
    const tr = document.createElement("tr");
    const rows = rowsOf(this);
    let section2 = this;
    if (this.localName === "table") section2 = [...this.children].filter((c) => c.localName === "tbody").pop() ?? this.appendChild(document.createElement("tbody"));
    if (index < 0 || index >= rows.length) section2.appendChild(tr);
    else rows[index].parentNode.insertBefore(tr, rows[index]);
    return tr;
  };
  const deleteRow = function(index) {
    const rows = rowsOf(this);
    rows[index < 0 ? rows.length + index : index]?.remove();
  };
  const section = (name) => function() {
    let s = [...this.children].find((c) => c.localName === name);
    if (!s) {
      s = document.createElement(name);
      if (name === "thead") this.insertBefore(s, this.firstChild);
      else this.appendChild(s);
    }
    return s;
  };
  defineOwn("table", {
    rows: { get() {
      return rowsOf(this);
    } },
    tBodies: { get() {
      return [...this.children].filter((c) => c.localName === "tbody");
    } },
    tHead: { get() {
      return [...this.children].find((c) => c.localName === "thead") ?? null;
    } },
    tFoot: { get() {
      return [...this.children].find((c) => c.localName === "tfoot") ?? null;
    } },
    caption: { get() {
      return [...this.children].find((c) => c.localName === "caption") ?? null;
    } },
    insertRow,
    deleteRow,
    createTHead: section("thead"),
    createTBody: section("tbody"),
    createTFoot: section("tfoot")
  });
  for (const t of ["thead", "tbody", "tfoot"]) defineOwn(t, { rows: { get() {
    return rowsOf(this);
  } }, insertRow, deleteRow });
  defineOwn("tr", {
    cells: { get() {
      return [...this.children].filter((c) => c.localName === "td" || c.localName === "th");
    } },
    rowIndex: { get() {
      const t = this.closest("table");
      return t ? rowsOf(t).indexOf(this) : -1;
    } },
    sectionRowIndex: { get() {
      return this.parentNode ? rowsOf(this.parentNode).indexOf(this) : -1;
    } },
    insertCell(index = -1) {
      const td = document.createElement("td");
      const cells = this.cells;
      this.insertBefore(td, index < 0 || index >= cells.length ? null : cells[index]);
      return td;
    },
    deleteCell(index) {
      const cells = this.cells;
      cells[index < 0 ? cells.length + index : index]?.remove();
    }
  });
  for (const t of ["td", "th"]) defineOwn(t, { cellIndex: { get() {
    return this.parentNode ? this.parentNode.cells.indexOf(this) : -1;
  } } });
}
function syntheticToggle(el) {
  if (tag(el) !== "input") return false;
  const type = (el.getAttribute("type") ?? "").toLowerCase();
  if (type === "checkbox") el.checked = !el.checked;
  else if (type === "radio") el.checked = true;
  else return false;
  return true;
}
export {
  FormData,
  activateFormControl,
  applyEventState,
  controlValue,
  emitProps,
  finishPointerEvent,
  installForms,
  isChecked,
  pointerEventTarget,
  syntheticToggle
};
