const hostFn = __host;
const hostBin = __hostBinary;
const hostCanvas = typeof __hostCanvas === "function" ? __hostCanvas : null;
const hostOps = typeof __hostOps === "function" ? __hostOps : null;
let stagedCanvas = [];
function stageCanvas(words, strings) {
  return stagedCanvas.push({ words, strings }) - 1;
}
function stagedCanvasCount() {
  return stagedCanvas.length;
}
function sendStagedCanvas() {
  if (!stagedCanvas.length || !hostCanvas) return;
  const staged = stagedCanvas;
  stagedCanvas = [];
  for (let k = 0; k < staged.length; k++) hostCanvas(k, staged[k].words, staged[k].strings);
}
const host = (kind, arg) => hostFn(kind, arg);
const hostBinary = () => hostBin();
function diag(kind, detail) {
  hostFn("diag", kind + ":" + detail);
}
const seenUnsupported = /* @__PURE__ */ new Set();
function unsupported(api) {
  if (seenUnsupported.has(api)) return;
  seenUnsupported.add(api);
  diag("unsupported", api);
}
const cache = /* @__PURE__ */ new Map();
const counters = { cacheHits: 0, missed: 0 };
let flushHook = () => {
};
function setFlushHook(fn) {
  flushHook = fn;
}
function invalidateLayout(keepBoxes = false) {
  if (!keepBoxes) {
    cache.clear();
    return;
  }
  for (const key of cache.keys()) if (!key.startsWith('{"q":"box",')) cache.delete(key);
}
function query(q, cacheable = true) {
  flushHook();
  const key = cacheable ? JSON.stringify(q) : "";
  if (cacheable) {
    const hit = cache.get(key);
    if (hit !== void 0) {
      counters.cacheHits++;
      return hit;
    }
  }
  let result;
  try {
    result = JSON.parse(hostFn("query", JSON.stringify(q)));
  } catch {
    result = { error: "bad result" };
  }
  if (cacheable) cache.set(key, result);
  return result;
}
export {
  counters,
  diag,
  host,
  hostBinary,
  hostCanvas,
  hostOps,
  invalidateLayout,
  query,
  sendStagedCanvas,
  setFlushHook,
  stageCanvas,
  stagedCanvasCount,
  unsupported
};
