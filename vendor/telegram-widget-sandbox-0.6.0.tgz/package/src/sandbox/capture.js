import { DOCUMENT_ID } from "../shared/protocol";
import { document, domHooks, exposeNode, quietly, SVG_NS } from "./dom";
import { OpWriter } from "./binary-ops";
import { boxNeutral } from "./box-neutral";
import { counters, host, hostOps, invalidateLayout, sendStagedCanvas } from "./host";
import { canonicalKey, canonicalMap, canonicalValue, forgetSentStyle, parseDeclarations, pendingStyles, setRawAttrValueSetter, styleImplOf } from "./style";
import { PROFILE_METHODS } from "../shared/profile-tables";
const RENDERER_METHODS = new Set(PROFILE_METHODS);
const ID = /* @__PURE__ */ Symbol("tw.id");
const stringifyOps = JSON.stringify;
let nextId = DOCUMENT_ID + 1;
const byId = /* @__PURE__ */ new Map();
const mirror = /* @__PURE__ */ new Map();
const strays = /* @__PURE__ */ new Set();
let generation = 0;
const domGeneration = () => generation;
const dirty = /* @__PURE__ */ new Set();
let ops = [];
const PARTIAL_BATCH_OPS = 1e3;
let partialSent = 0;
function enableBinaryOps(on) {
  if (on && hostOps && Array.isArray(ops) && !ops.length) ops = new OpWriter(hostOps);
}
let postOps = [];
let hooks;
function setHooks(h) {
  hooks = h;
}
document[ID] = DOCUMENT_ID;
byId.set(DOCUMENT_ID, document);
mirror.set(DOCUMENT_ID, { parent: 0, kids: [], attrs: null, data: null });
function markDirty(node) {
  if (node) dirty.add(node);
}
function idOf(node) {
  return node[ID] ?? (node[ID] = nextId++);
}
function nodeById(id) {
  return exposeNode(byId.get(id) ?? null);
}
function mirroredId(node) {
  const id = node?.[ID];
  return id !== void 0 && mirror.has(id) ? id : 0;
}
const renderable = (n) => n.nodeType === 1 || n.nodeType === 3 || n.nodeType === 8;
const opaque = (n) => n.nodeType === 1 && n.localName === "script";
function* childrenOf(node) {
  if (node.nodeType === 9) {
    if (node.documentElement) yield node.documentElement;
    return;
  }
  if (opaque(node)) return;
  for (let c = node.firstChild; c; c = c.nextSibling) if (renderable(c)) yield c;
}
function readAttrs(el) {
  const out = /* @__PURE__ */ new Map();
  for (const a of el.attributes) out.set(a.name, String(a.value ?? ""));
  return out;
}
function hasPendingRecords() {
  return records.length > 0;
}
function pushProp(node, name, value) {
  dirty.add(node);
  postOps.push({ op: "prop", node, name, value });
}
const observers = /* @__PURE__ */ new Set();
domHooks.observing = () => observers.size > 0;
domHooks.markDirty = (node) => dirty.add(node);
let records = [];
function record(rec) {
  if (observers.size) records.push({ addedNodes: [], removedNodes: [], attributeName: null, oldValue: null, previousSibling: null, nextSibling: null, ...rec });
}
class MutationObserverImpl {
  _cb;
  _obs = [];
  _queue = [];
  constructor(cb) {
    this._cb = cb;
  }
  observe(target, options = {}) {
    const o = { ...options };
    if (o.attributeFilter || o.attributeOldValue) o.attributes = o.attributes ?? true;
    this._obs = this._obs.filter((x) => x.target !== target);
    this._obs.push({ target, options: o });
    observers.add(this);
  }
  disconnect() {
    this._obs = [];
    this._queue = [];
    observers.delete(this);
  }
  takeRecords() {
    return this._queue.splice(0);
  }
}
function wants(o, rec) {
  const { target, options } = o;
  if (rec.target !== target && !(options.subtree && target.contains?.(rec.target))) return false;
  if (rec.type === "childList") return !!options.childList;
  if (rec.type === "attributes") return !!options.attributes && (!options.attributeFilter || options.attributeFilter.includes(rec.attributeName));
  return !!options.characterData;
}
function deliverMutationRecords(report) {
  if (!records.length) return false;
  const batch = records;
  records = [];
  let ran = false;
  for (const obs of [...observers]) {
    const mine = batch.filter((rec) => obs._obs.some((o) => wants(o, rec)));
    if (!mine.length) continue;
    ran = true;
    try {
      obs._cb(mine, obs);
    } catch (e) {
      report(e);
    }
  }
  return ran;
}
function createNode(node) {
  const id = idOf(node);
  byId.set(id, node);
  if (node.nodeType === 1) {
    forgetSentStyle(node);
    const attrs = readAttrs(node);
    const m = { parent: 0, kids: [], attrs, data: null };
    mirror.set(id, m);
    const op = { op: "el", id, tag: node.localName };
    if (node.namespaceURI === SVG_NS) op.ns = "svg";
    if (attrs.size) op.attrs = Object.fromEntries(attrs);
    ops.push(op);
    hooks.elementCreated(node, id);
    for (const [name, value] of attrs) hooks.attributeChanged(node, name, value);
    hooks.elementSynced(node, id, (o) => postOps.push(o), true);
    for (const c of childrenOf(node)) {
      const known = c[ID];
      const cid = known !== void 0 && mirror.has(known) ? known : createNode(c);
      mirror.get(cid).parent = id;
      strays.delete(cid);
      m.kids.push(cid);
      ops.push({ op: "ins", parent: id, id: cid, before: null });
      sendIfLarge();
    }
  } else {
    const data = String(node.data ?? "");
    mirror.set(id, { parent: 0, kids: [], attrs: null, data });
    ops.push({ op: node.nodeType === 3 ? "text" : "comment", id, data });
  }
  return id;
}
function ensureCreated(node) {
  return mirroredId(node) || createNode(node);
}
function holdsMoved(id) {
  const node = byId.get(id);
  for (const k of mirror.get(id)?.kids ?? []) {
    if (mirror.get(k)?.parent !== id) continue;
    if (byId.get(k)?.parentNode !== node || holdsMoved(k)) return true;
  }
  return false;
}
function strayUnder(id) {
  for (const s of strays) {
    let p = mirror.get(s)?.parent;
    for (let n = 0; p && n < mirror.size; n++, p = mirror.get(p)?.parent) if (p === id) return true;
  }
  return false;
}
function purge(id) {
  const m = mirror.get(id);
  if (!m) return;
  strays.delete(id);
  mirror.delete(id);
  byId.delete(id);
  for (const k of m.kids) if (mirror.get(k)?.parent === id) purge(k);
}
function syncAttrs(el, id, m) {
  const attrs = m.attrs;
  let count = 0;
  for (const a of el.attributes) {
    const name = a.name;
    const value = String(a.value ?? "");
    count++;
    const old = attrs.get(name);
    if (old === value) continue;
    attrs.set(name, value);
    if (observers.size) record({ type: "attributes", target: el, attributeName: name, oldValue: old ?? null });
    if (name === "style" && old !== void 0) emitStyleDiff(id, old, value, el);
    else {
      if (name === "style") forgetSentStyle(el);
      ops.push({ op: "attr", id, name, value });
    }
    hooks.attributeChanged(el, name, value);
  }
  if (attrs.size <= count) return;
  const seen = /* @__PURE__ */ new Set();
  for (const a of el.attributes) seen.add(a.name);
  for (const [name, old] of attrs) {
    if (seen.has(name)) continue;
    attrs.delete(name);
    if (name === "style") forgetSentStyle(el);
    if (observers.size) record({ type: "attributes", target: el, attributeName: name, oldValue: old });
    ops.push({ op: "rattr", id, name });
    hooks.attributeChanged(el, name, null);
  }
}
let parsedNow = /* @__PURE__ */ new Map();
let parsedBefore = /* @__PURE__ */ new Map();
function parsedStyle(text) {
  return parsedNow.get(text) ?? parsedBefore.get(text) ?? parseDeclarations(text);
}
function emitStyleDiff(id, oldText, newText, el) {
  const impl = styleImplOf(el);
  const before = impl && impl._sent !== null && impl._sentText === oldText ? impl._sent : parsedStyle(oldText);
  const after = parsedStyle(newText);
  parsedNow.set(newText, after);
  for (const [name, d] of after) {
    const o = before.get(name);
    if (!o || o.value !== d.value || o.important !== d.important) ops.push({ op: "style", id, name, value: d.value, important: d.important || void 0 });
  }
  for (const name of before.keys()) if (!after.has(name)) ops.push({ op: "style", id, name, value: "" });
  if (impl) {
    impl._keys = null;
    if (impl._text === newText && !impl._reparsed && canonicalMap(impl._map)) {
      impl._sent = new Map(after);
      impl._sentText = newText;
    } else {
      impl._sent = null;
      impl._sentText = null;
      impl._reparsed = false;
    }
  }
}
function keyStillCanonical(name, map) {
  const d = map.get(name);
  return d === void 0 || canonicalKey(name) && canonicalValue(d.value);
}
function sendStyleKey(id, name, map, sent) {
  const d = map.get(name);
  const was = sent.get(name);
  if (d !== void 0) {
    if (was === void 0 || was.value !== d.value || was.important !== d.important) {
      ops.push({ op: "style", id, name, value: d.value, important: d.important || void 0 });
      sent.set(name, d);
    }
  } else if (was !== void 0) {
    ops.push({ op: "style", id, name, value: "" });
    sent.delete(name);
  }
}
function syncPendingStyles() {
  const pending = [...pendingStyles];
  pendingStyles.clear();
  for (const impl of pending) {
    const el = impl._el;
    const keys = impl._keys;
    impl._keys = null;
    if (keys === null || dirty.has(el)) continue;
    const id = el[ID];
    const m = id === void 0 ? void 0 : mirror.get(id);
    const text = impl._attrText();
    const told = m?.attrs?.get("style");
    let fallback = !m || text === null || text !== impl._text || told !== impl._sentText || impl._reparsed || impl._sent === null;
    if (!fallback) {
      if (typeof keys === "string") fallback = !keyStillCanonical(keys, impl._map);
      else for (const k of keys) if (!keyStillCanonical(k, impl._map)) {
        fallback = true;
        break;
      }
    }
    if (fallback) {
      impl._sentText = null;
      if (m) dirty.add(el);
      continue;
    }
    if (told === text) continue;
    m.attrs.set("style", text);
    if (observers.size) record({ type: "attributes", target: el, attributeName: "style", oldValue: told ?? null });
    const sent = impl._sent;
    if (typeof keys === "string") sendStyleKey(id, keys, impl._map, sent);
    else for (const k of keys) sendStyleKey(id, k, impl._map, sent);
    impl._sentText = text;
    hooks.attributeChanged(el, "style", text);
    hooks.elementSynced(el, id, (o) => postOps.push(o), false);
  }
}
function reuseSoleText(node, id, oldId) {
  const old = byId.get(oldId);
  const next = node.firstChild;
  const m = mirror.get(oldId);
  if (!old || !next || old === next || old.nodeType !== 3 || next.nodeType !== 3 || next.nextSibling || old.isConnected) return false;
  if (!m || m.parent !== id) return false;
  if (next[ID] !== void 0 && mirror.has(next[ID])) return false;
  delete old[ID];
  next[ID] = oldId;
  byId.set(oldId, next);
  record({ type: "childList", target: node, addedNodes: [next], removedNodes: [old] });
  const data = String(next.data ?? "");
  if (data !== m.data) {
    m.data = data;
    ops.push({ op: "data", id: oldId, data });
  }
  return true;
}
function syncChildren(node, id, m) {
  if (node.nodeType !== 9) {
    let i = 0;
    let c = opaque(node) ? null : node.firstChild;
    for (; c; c = c.nextSibling) {
      if (!renderable(c)) continue;
      const cid = c[ID];
      if (cid === void 0 || cid !== m.kids[i] || mirror.get(cid)?.parent !== id) break;
      i++;
    }
    if (!c && i === m.kids.length) return;
    if (m.kids.length === 1 && reuseSoleText(node, id, m.kids[0])) return;
  }
  const children = [];
  const live = [];
  const liveSet = /* @__PURE__ */ new Set();
  for (const c of childrenOf(node)) {
    const cid = c[ID];
    const known = cid !== void 0 && mirror.has(cid) ? cid : 0;
    children.push(c);
    live.push(known);
    if (known) liveSet.add(known);
  }
  const old = m.kids.filter((k) => mirror.get(k)?.parent === id);
  const kept = [];
  const gone = [];
  for (const k of old) {
    if (liveSet.has(k)) {
      kept.push(k);
      continue;
    }
    const kn = byId.get(k);
    const early = !!kn && kn.parentNode === null && !holdsMoved(k) && !strayUnder(k);
    if (early) {
      ops.push({ op: "rm", id: k });
      purge(k);
    }
    gone.push([k, kn, early]);
  }
  const added = [];
  for (let i = 0; i < live.length; i++) {
    if (live[i] && mirror.has(live[i])) continue;
    live[i] = createNode(children[i]);
    added.push(children[i]);
    sendIfLarge();
  }
  const removed = [];
  for (const [k, kn, early] of gone) {
    if (!early) {
      if (mirror.get(k)?.parent !== id) continue;
      if (!kn || !kn.isConnected) {
        ops.push({ op: "rm", id: k });
        purge(k);
        sendIfLarge();
      } else strays.add(k);
    }
    removed.push(kn);
  }
  let j = kept.length - 1;
  const moved = /* @__PURE__ */ new Set();
  let before = null;
  for (let i = live.length - 1; i >= 0; i--) {
    const cid = live[i];
    while (j >= 0 && moved.has(kept[j])) j--;
    if (j >= 0 && kept[j] === cid) j--;
    else {
      ops.push({ op: "ins", parent: id, id: cid, before });
      const cm = mirror.get(cid);
      if (cm.parent === id) moved.add(cid);
      else if (cm.parent !== 0 && !added.includes(byId.get(cid))) added.push(byId.get(cid));
      cm.parent = id;
      strays.delete(cid);
      sendIfLarge();
    }
    before = cid;
  }
  m.kids = live;
  if (added.length || removed.length) record({ type: "childList", target: node, addedNodes: added, removedNodes: removed });
}
function syncNode(node) {
  const id = node[ID];
  const m = id === void 0 ? void 0 : mirror.get(id);
  if (!m) {
    if (node?.nodeType === 1 && node.localName === "img" && !node.isConnected && node.getAttribute("src")) ensureCreated(node);
    return;
  }
  if (node.nodeType === 1) {
    syncAttrs(node, id, m);
    syncChildren(node, id, m);
    hooks.elementSynced(node, id, (o) => postOps.push(o), false);
  } else if (id === DOCUMENT_ID) {
    syncChildren(node, id, m);
  } else {
    const data = String(node.data ?? "");
    if (data !== m.data) {
      record({ type: "characterData", target: node, oldValue: m.data });
      m.data = data;
      ops.push({ op: "data", id, data });
    }
  }
}
function walkAll(node) {
  syncNode(node);
  sendIfLarge();
  for (const c of childrenOf(node)) walkAll(c);
}
function callMethod(node, method, args = []) {
  if (!RENDERER_METHODS.has(method)) return;
  dirty.add(node);
  postOps.push({ op: "call", node, method, args });
}
let lastFullSync = 0;
function flush(full = false) {
  quietly(() => flushNow(full));
}
function flushNow(full) {
  if (!dirty.size && !postOps.length && !full && !pendingStyles.size) {
    hooks.flushExtra((o) => ops.push(o));
    if (ops.length) send();
    return;
  }
  if (pendingStyles.size) syncPendingStyles();
  for (let i = 0; i < 8 && dirty.size; i++) {
    const batch = [...dirty];
    dirty.clear();
    for (const node of batch) if (node) {
      syncNode(node);
      sendIfLarge();
    }
  }
  if (full) {
    const before = partialSent + ops.length;
    walkAll(document);
    counters.missed += partialSent + ops.length - before;
    dirty.clear();
  }
  for (const o of postOps) {
    if (o.node) {
      const id = mirroredId(o.node);
      if (id) {
        const { node: _n, ...rest } = o;
        ops.push({ ...rest, id });
      }
    } else ops.push(o);
  }
  postOps = [];
  hooks.flushExtra((o) => ops.push(o));
  if (parsedNow.size) {
    parsedBefore = parsedNow;
    parsedNow = /* @__PURE__ */ new Map();
  }
  if (ops.length) send();
}
function send() {
  if (ops instanceof OpWriter) {
    invalidateLayout(ops.length > 0 && ops.boxNeutral);
    sendStagedCanvas();
    ops.flush();
    return;
  }
  const batch = ops;
  ops = [];
  invalidateLayout(batch.length > 0 && batch.every(boxNeutral));
  const json = stringifyOps(batch);
  sendStagedCanvas();
  host("ops", json);
}
function sendIfLarge() {
  if (ops.length < PARTIAL_BATCH_OPS) return;
  partialSent += ops.length;
  if (ops instanceof OpWriter) {
    invalidateLayout(ops.boxNeutral);
    ops.flush();
    return;
  }
  const batch = ops;
  ops = [];
  invalidateLayout(batch.every(boxNeutral));
  host("ops", stringifyOps(batch));
}
function flushTick() {
  generation++;
  const now = Date.now();
  const full = now - lastFullSync > 500;
  if (full) lastFullSync = now;
  flush(full);
}
const SELF_METHODS = [
  "appendChild",
  "insertBefore",
  "removeChild",
  "replaceChild",
  "append",
  "prepend",
  "replaceChildren",
  "normalize",
  "setAttribute",
  "setAttributeNS",
  "removeAttribute",
  "removeAttributeNS",
  "toggleAttribute",
  "setAttributeNode",
  "removeAttributeNode",
  "insertAdjacentElement",
  "insertAdjacentText",
  "insertAdjacentHTML"
];
const PARENT_METHODS = ["before", "after", "replaceWith", "remove", "insertAdjacentElement", "insertAdjacentText", "insertAdjacentHTML"];
const LIVE_GETTERS = ["classList", "dataset", "relList", "part"];
const SKIP_SETTERS = /* @__PURE__ */ new Set(["scrollTop", "scrollLeft", "value", "checked", "selectedIndex", "selected", "indeterminate", "onclick"]);
const TREE_SETTERS = /* @__PURE__ */ new Set(["className", "innerHTML", "outerHTML", "textContent", "innerText", "outerText"]);
const elementLike = (x) => !!x && typeof x === "object" && (x.nodeType === 1 || x.nodeType === 11);
function treeKind(name) {
  if (name === "setAttribute" || name === "removeAttribute" || name === "toggleAttribute") return 1;
  if (name === "appendChild" || name === "insertBefore" || name === "removeChild" || name === "replaceChild") return 2;
  if (name === "append" || name === "prepend" || name === "before" || name === "after") return 2;
  if (name === "remove" || name === "replaceWith") return 3;
  if (name === "normalize" || name === "insertAdjacentText") return 4;
  if (name === "replaceChildren") return 5;
  return 0;
}
function changesTree(kind, self, a, b) {
  switch (kind) {
    case 0:
      return true;
    case 1:
      return String(a).toLowerCase() === "class";
    case 2:
      return elementLike(a) || elementLike(b);
    case 3:
      return self.nodeType === 1 || elementLike(a) || elementLike(b);
    case 5:
      return !!self.firstElementChild || elementLike(a) || elementLike(b);
    default:
      return false;
  }
}
function markArgs(args) {
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a && typeof a === "object" && a.nodeType) dirty.add(a.parentNode);
  }
}
function collectPrototypes(samples) {
  const protos = /* @__PURE__ */ new Set();
  for (const s of samples) {
    for (let p = Object.getPrototypeOf(s); p && p !== Object.prototype; p = Object.getPrototypeOf(p)) protos.add(p);
  }
  return [...protos];
}
function installDirtyTracking(protos, tokenListProto) {
  const tokenOwner = /* @__PURE__ */ new WeakMap();
  const attrProto = Object.getPrototypeOf(document.createAttribute("x"));
  const attrValue = Object.getOwnPropertyDescriptor(attrProto, "value");
  if (attrValue?.set) {
    const set = attrValue.set;
    setRawAttrValueSetter((attr, value) => set.call(attr, value));
  }
  for (const proto of protos) {
    for (const name of Object.getOwnPropertyNames(proto)) {
      const d = Object.getOwnPropertyDescriptor(proto, name);
      if (!d.configurable) continue;
      if (typeof d.value === "function") {
        const self = SELF_METHODS.includes(name);
        const parent = PARENT_METHODS.includes(name);
        if (!self && !parent) continue;
        const orig = d.value;
        const kind = treeKind(name);
        Object.defineProperty(proto, name, {
          ...d,
          // Arity-specialized: most DOM calls take one or two arguments, so no
          // rest array is allocated for them. Strict, so `arguments` is not a
          // mapped object (quickjs-ng < 0.13 frees mapped arguments' var refs
          // too early, issue #1400).
          value: function(a, b) {
            "use strict";
            const n = arguments.length;
            if (n > 2 || changesTree(kind, this, a, b)) generation++;
            if (self) dirty.add(this);
            if (parent) dirty.add(this.parentNode);
            if (n > 2) {
              markArgs(arguments);
              return orig.apply(this, arguments);
            }
            if (n > 0 && a && typeof a === "object" && a.nodeType) dirty.add(a.parentNode);
            if (n > 1 && b && typeof b === "object" && b.nodeType) dirty.add(b.parentNode);
            return n === 0 ? orig.call(this) : n === 1 ? orig.call(this, a) : orig.call(this, a, b);
          }
        });
      } else if (d.set && !SKIP_SETTERS.has(name) && !name.startsWith("on")) {
        const set = d.set;
        const live = LIVE_GETTERS.includes(name) && d.get;
        const get = d.get;
        const tree = TREE_SETTERS.has(name);
        const text = name === "textContent" || name === "innerText";
        Object.defineProperty(proto, name, {
          ...d,
          get: live ? function() {
            dirty.add(this);
            const v = get.call(this);
            if (v && typeof v === "object") tokenOwner.set(v, this);
            return v;
          } : get,
          set: function(v) {
            if (tree && (!text || this.firstElementChild)) generation++;
            dirty.add(this);
            if (this.nodeType === 2) dirty.add(this.ownerElement);
            if (name === "outerHTML") dirty.add(this.parentNode);
            set.call(this, v);
          }
        });
      } else if (d.get && LIVE_GETTERS.includes(name)) {
        const get = d.get;
        Object.defineProperty(proto, name, {
          ...d,
          get: function() {
            dirty.add(this);
            const v = get.call(this);
            if (v && typeof v === "object") tokenOwner.set(v, this);
            return v;
          }
        });
      }
    }
  }
  if (tokenListProto) {
    for (const name of ["add", "remove", "toggle", "replace"]) {
      const orig = tokenListProto[name];
      if (typeof orig !== "function") continue;
      tokenListProto[name] = function(...args) {
        generation++;
        dirty.add(tokenOwner.get(this));
        return orig.apply(this, args);
      };
    }
  }
}
export {
  ID,
  MutationObserverImpl as MutationObserver,
  callMethod,
  collectPrototypes,
  deliverMutationRecords,
  domGeneration,
  enableBinaryOps,
  ensureCreated,
  flush,
  flushTick,
  hasPendingRecords,
  idOf,
  installDirtyTracking,
  markDirty,
  mirroredId,
  nodeById,
  pushProp,
  setHooks
};
