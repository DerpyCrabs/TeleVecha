import { parse } from "parse5";
import { build, document } from "./dom";
const KEEP = "data-morph-keep";
function isScript(n) {
  return n.nodeType === 1 && n.localName === "script";
}
function sameKind(a, b) {
  if (a.nodeType !== b.nodeType) return false;
  if (a.nodeType !== 1) return true;
  return a.localName === b.localName && a.namespaceURI === b.namespaceURI;
}
function syncAttributes(live, next) {
  const wanted = /* @__PURE__ */ new Map();
  for (const attr of Array.from(next.attributes ?? [])) wanted.set(attr.name, attr.value);
  for (const attr of Array.from(live.attributes ?? [])) {
    if (!wanted.has(attr.name)) live.removeAttribute(attr.name);
  }
  for (const [name, value] of wanted) {
    if (live.getAttribute(name) !== value) live.setAttribute(name, value);
  }
}
function morphNode(live, next) {
  if (live.nodeType === 3 || live.nodeType === 8) {
    if (live.data !== next.data) live.data = next.data;
    return;
  }
  syncAttributes(live, next);
  if (isScript(live) || live.hasAttribute(KEEP)) return;
  if (live.localName === "template" && live.content && next.content) {
    morphChildren(live.content, next.content);
    return;
  }
  morphChildren(live, next);
}
function morphChildren(live, next) {
  const wanted = Array.from(next.childNodes).filter((n) => !isScript(n));
  const pool = Array.from(live.childNodes).filter((n) => !isScript(n));
  const byId = /* @__PURE__ */ new Map();
  for (const n of pool) {
    const id = n.nodeType === 1 ? n.getAttribute("id") : null;
    if (id && !byId.has(id)) byId.set(id, n);
  }
  const used = /* @__PURE__ */ new Set();
  const matched = [];
  for (const n of wanted) {
    const id = n.nodeType === 1 ? n.getAttribute("id") : null;
    let hit = id ? byId.get(id) : void 0;
    if (hit && (used.has(hit) || !sameKind(hit, n))) hit = void 0;
    if (!hit) {
      hit = pool.find((c) => !used.has(c) && sameKind(c, n) && !(c.nodeType === 1 && c.getAttribute("id") && c.getAttribute("id") !== id));
    }
    if (hit) used.add(hit);
    matched.push(hit);
  }
  for (const n of pool) if (!used.has(n)) live.removeChild(n);
  let cursor = live.firstChild;
  const advance = () => {
    while (cursor && isScript(cursor)) cursor = cursor.nextSibling;
  };
  advance();
  for (let i = 0; i < wanted.length; i++) {
    const hit = matched[i];
    if (hit) {
      morphNode(hit, wanted[i]);
      if (hit !== cursor) live.insertBefore(hit, cursor);
      else cursor = cursor.nextSibling;
    } else {
      live.insertBefore(wanted[i], cursor);
    }
    advance();
  }
}
function morphDocument(html) {
  const p5 = parse(html);
  const root = p5.childNodes.find((n) => n.tagName === "html");
  if (!root) return false;
  const head = document.createElement("div");
  const body = document.createElement("div");
  const bodyAttrs = document.createElement("div");
  for (const c of root.childNodes) {
    if (c.tagName === "head") {
      build(c, head, true);
    } else if (c.tagName === "body") {
      build(c, body, true);
      for (const a of c.attrs ?? []) bodyAttrs.setAttribute(a.name, a.value);
    }
  }
  morphChildren(document.head, head);
  syncAttributes(document.body, bodyAttrs);
  morphChildren(document.body, body);
  return true;
}
export {
  morphDocument
};
