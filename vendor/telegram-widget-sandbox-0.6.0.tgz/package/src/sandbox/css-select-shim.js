import * as real from "css-select";
export * from "css-select";
const pseudoHooks = {};
const STATE_PSEUDOS = ["checked", "focus-visible", "focus-within", "focus", "indeterminate", "hover", "active", "visited", "placeholder-shown", "default"];
const PREFIX = "tw-";
const RE = new RegExp(`:(${STATE_PSEUDOS.join("|")})(?![\\w-])`, "g");
function rewriteSelector(selector) {
  if (!selector.includes(":")) return selector;
  let out = "";
  let i = 0;
  while (i < selector.length) {
    const ch = selector[i];
    if (ch === '"' || ch === "'") {
      const end = selector.indexOf(ch, i + 1);
      const stop = end < 0 ? selector.length : end + 1;
      out += selector.slice(i, stop);
      i = stop;
      continue;
    }
    const next = Math.min(...['"', "'"].map((q) => {
      const p = selector.indexOf(q, i);
      return p < 0 ? selector.length : p;
    }));
    out += selector.slice(i, next).replace(RE, `:${PREFIX}$1`);
    i = next;
  }
  return out;
}
function withPseudos(options) {
  const pseudos = { ...options?.pseudos };
  for (const name of STATE_PSEUDOS) pseudos[PREFIX + name] = (el) => pseudoHooks[name]?.(el) ?? false;
  return { ...options, pseudos };
}
const sel = (s) => typeof s === "string" ? rewriteSelector(s) : s;
function compile(selector, options) {
  return real.compile(sel(selector), withPseudos(options));
}
function is(element, selector, options) {
  return real.is(element, sel(selector), withPseudos(options));
}
function selectAll(query, elements, options) {
  return real.selectAll(sel(query), elements, withPseudos(options));
}
function selectOne(query, elements, options) {
  return real.selectOne(sel(query), elements, withPseudos(options));
}
export {
  compile,
  is,
  pseudoHooks,
  rewriteSelector,
  selectAll,
  selectOne
};
