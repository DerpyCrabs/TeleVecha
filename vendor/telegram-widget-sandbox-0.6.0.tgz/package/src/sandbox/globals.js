import { callMethod } from "./capture";
import { addEventListener, dispatchEvent, Event, EventTarget, removeEventListener } from "./events";
import { diag, host, invalidateLayout, query, unsupported } from "./host";
import { PROFILE_VERSION } from "../shared/profile-tables";
import { cssSupports } from "../shared/css-supports";
import {
  CONTENT_SAFE_AREA_FIELDS,
  DEFAULT_LOCALE,
  DEFAULT_RESIZE_ANCHOR,
  HAPTIC_IMPACT_STYLES,
  HAPTIC_NOTIFICATION_TYPES,
  MAX_HANDLERS_PER_EVENT,
  NO_CONTENT_SAFE_AREA,
  REQUEST_ERRORS,
  STORAGE_QUOTA_BYTES,
  checkChatType,
  checkContentSafeArea,
  checkCopyText,
  checkLink,
  checkLocale,
  checkRequestData,
  checkRequestOptions,
  checkResizeAnchor,
  checkSignDataPayload,
  checkViewer,
  checkWalletTransaction,
  checkWidgetDataValue,
  completeThemeParams,
  utf8Length
} from "../shared/sdk-policy";
const G = globalThis;
let reportError = (e) => {
  if (e instanceof Error && e.name === "InternalError" && /out of memory|interrupted/.test(e.message)) throw e;
  const text = e instanceof Error ? `${e.name}: ${e.message}${e.stack ? "\n" + e.stack : ""}` : String(e);
  host("log", "error:Uncaught " + text);
  try {
    const ev = new G.ErrorEvent("error", { message: String(e?.message ?? e), error: e, cancelable: true });
    dispatchEvent.call(G, ev);
  } catch {
  }
};
function fmt(v, depth = 0) {
  if (typeof v === "string") return depth ? JSON.stringify(v) : v;
  if (v === null || v === void 0 || typeof v === "number" || typeof v === "boolean" || typeof v === "bigint") return String(v);
  if (typeof v === "function") return `[Function ${v.name || "anonymous"}]`;
  if (typeof v === "symbol") return v.toString();
  if (v instanceof Error) return `${v.name}: ${v.message}${v.stack ? "\n" + v.stack : ""}`;
  if (v.nodeType === 1) return `<${v.localName}${v.id ? "#" + v.id : ""}${v.getAttribute?.("class") ? "." + String(v.getAttribute("class")).trim().replace(/\s+/g, ".") : ""}>`;
  if (v.nodeType) return v.nodeName ?? "[Node]";
  if (depth > 3) return Array.isArray(v) ? "[\u2026]" : "{\u2026}";
  try {
    if (Array.isArray(v)) return "[" + v.slice(0, 50).map((x) => fmt(x, depth + 1)).join(", ") + (v.length > 50 ? ", \u2026" : "") + "]";
    if (v instanceof Map) return "Map(" + v.size + ") " + fmt(Object.fromEntries([...v].slice(0, 20)), depth + 1);
    if (v instanceof Set) return "Set(" + v.size + ") " + fmt([...v], depth + 1);
    const keys = Object.keys(v);
    return "{" + keys.slice(0, 30).map((k) => `${k}: ${fmt(v[k], depth + 1)}`).join(", ") + (keys.length > 30 ? ", \u2026" : "") + "}";
  } catch {
    return "[Object]";
  }
}
function installConsole() {
  const out = (level) => (...args) => host("log", level + ":" + args.map((a) => fmt(a)).join(" "));
  const timers2 = /* @__PURE__ */ new Map();
  G.console = {
    log: out("log"),
    info: out("info"),
    warn: out("warn"),
    error: out("error"),
    debug: out("debug"),
    trace: out("debug"),
    table: out("log"),
    dir: out("log"),
    group: out("log"),
    groupCollapsed: out("log"),
    groupEnd() {
    },
    clear() {
    },
    assert(cond, ...args) {
      if (!cond) out("error")("Assertion failed:", ...args);
    },
    count() {
    },
    countReset() {
    },
    time(label = "default") {
      timers2.set(label, Number(host("now")));
    },
    timeEnd(label = "default") {
      const t = timers2.get(label);
      if (t !== void 0) out("log")(`${label}: ${(Number(host("now")) - t).toFixed(2)} ms`);
      timers2.delete(label);
    },
    timeLog(label = "default") {
      const t = timers2.get(label);
      if (t !== void 0) out("log")(`${label}: ${(Number(host("now")) - t).toFixed(2)} ms`);
    }
  };
}
const timers = /* @__PURE__ */ new Map();
let timerSeq = 1;
let maxTimers = 64;
let timerLimitReported = false;
function configureLimits(limits) {
  if (Number.isFinite(limits.maxTimers) && limits.maxTimers > 0) maxTimers = Math.floor(limits.maxTimers);
}
function setTimer(fn, delay, args, interval) {
  if (timers.size >= maxTimers) {
    if (!timerLimitReported) {
      timerLimitReported = true;
      diag("timer-limit", `widget holds ${timers.size} live timers (max ${maxTimers}); further ${interval ? "setInterval" : "setTimeout"} calls throw RangeError`);
    }
    throw new RangeError(`too many timers (max ${maxTimers})`);
  }
  const id = timerSeq++;
  const ms = Math.max(Number(delay) || 0, interval ? 4 : 0);
  timers.set(id, { fn, args, interval, delay: ms });
  host("timer", JSON.stringify([id, ms]));
  return id;
}
function clearTimer(id) {
  if (timers.delete(Number(id))) host("clearTimer", String(Number(id)));
}
function hostTimer(fn, ms) {
  const id = timerSeq++;
  timers.set(id, { fn, args: [], interval: false, delay: ms });
  host("timer", JSON.stringify([id, ms]));
  return id;
}
const clearHostTimer = clearTimer;
function fireTimer(id) {
  const t = timers.get(id);
  if (!t) return;
  if (t.interval) host("timer", JSON.stringify([id, t.delay]));
  else timers.delete(id);
  try {
    if (typeof t.fn === "function") t.fn(...t.args);
    else (0, eval)(String(t.fn));
  } catch (e) {
    reportError(e);
  }
}
let hidden = false;
const isHidden = () => hidden;
function setHidden(h) {
  if (hidden === h) return false;
  hidden = h;
  return true;
}
let frameCallbacks = /* @__PURE__ */ new Map();
let frameSeq = 1;
let frameHook = null;
function setFrameHook(hook) {
  frameHook = hook;
}
function fireFrame() {
  const batch = frameCallbacks;
  frameCallbacks = /* @__PURE__ */ new Map();
  const now = G.performance.now();
  const run = () => {
    for (const cb of batch.values()) {
      try {
        cb(now);
      } catch (e) {
        reportError(e);
      }
    }
  };
  const hooked = frameHook ? frameHook(now) : null;
  if (hooked) {
    hooked(run);
    return;
  }
  run();
}
let originTime = 0;
const timeOrigin = () => originTime;
const DOM_EXCEPTION_CODES = { IndexSizeError: 1, HierarchyRequestError: 3, NotFoundError: 8, NotSupportedError: 9, InvalidStateError: 11, SyntaxError: 12, SecurityError: 18, NetworkError: 19, AbortError: 20, QuotaExceededError: 22, TimeoutError: 23, DataCloneError: 25 };
class DOMException extends Error {
  constructor(message = "", name = "Error") {
    super(String(message));
    Object.defineProperty(this, "name", { value: String(name), writable: true, configurable: true });
  }
  get code() {
    return DOM_EXCEPTION_CODES[this.name] ?? 0;
  }
}
const storageData = { local: /* @__PURE__ */ new Map(), session: /* @__PURE__ */ new Map() };
const storageUsed = { local: 0, session: 0 };
const storageDirty = /* @__PURE__ */ new Set();
function areaBytes(m) {
  let n = 0;
  for (const [k, v] of m) n += utf8Length(k) + utf8Length(v);
  return n;
}
function preloadStorage(storage) {
  const s = typeof storage === "object" && storage !== null ? storage : {};
  for (const area of ["local", "session"]) {
    const m = storageData[area];
    m.clear();
    const src = s[area];
    if (typeof src === "object" && src !== null) for (const k of Object.keys(src)) {
      const v = src[k];
      if (typeof v === "string") m.set(k, v);
    }
    storageUsed[area] = areaBytes(m);
    if (storageUsed[area] > STORAGE_QUOTA_BYTES) {
      m.clear();
      storageUsed[area] = 0;
    }
  }
  storageDirty.clear();
}
function takeStorageCommit() {
  if (!storageDirty.size) return null;
  const commit = {};
  for (const area of storageDirty) commit[area] = Object.fromEntries(storageData[area]);
  storageDirty.clear();
  return commit;
}
function makeStorage(area) {
  const data = storageData[area];
  const setItem = (key, value) => {
    const k = String(key), v = String(value);
    const old = data.get(k);
    if (old === v) return;
    const used = storageUsed[area] - (old === void 0 ? 0 : utf8Length(k) + utf8Length(old)) + utf8Length(k) + utf8Length(v);
    if (used > STORAGE_QUOTA_BYTES) throw new DOMException(`Setting the value of '${k.slice(0, 64)}' exceeded the quota (${STORAGE_QUOTA_BYTES} bytes per area)`, "QuotaExceededError");
    data.set(k, v);
    storageUsed[area] = used;
    storageDirty.add(area);
  };
  const removeItem = (key) => {
    const k = String(key);
    const old = data.get(k);
    if (old === void 0) return;
    data.delete(k);
    storageUsed[area] -= utf8Length(k) + utf8Length(old);
    storageDirty.add(area);
  };
  const api = {
    getItem: (k) => data.has(String(k)) ? data.get(String(k)) : null,
    setItem,
    removeItem,
    clear: () => {
      if (!data.size) return;
      data.clear();
      storageUsed[area] = 0;
      storageDirty.add(area);
    },
    key: (i) => [...data.keys()][i] ?? null
  };
  return new Proxy(api, {
    get: (t, p) => p === "length" ? data.size : typeof p === "string" && !(p in t) ? data.get(p) : t[p],
    set: (t, p, v) => {
      if (typeof p === "string") setItem(p, v);
      return true;
    },
    has: (t, p) => p in t || typeof p === "string" && data.has(p),
    deleteProperty: (t, p) => {
      if (typeof p === "string") removeItem(p);
      return true;
    },
    ownKeys: () => [...data.keys()],
    getOwnPropertyDescriptor: (t, p) => typeof p === "string" && data.has(p) ? { value: data.get(p), writable: true, enumerable: true, configurable: true } : void 0
  });
}
let locale = DEFAULT_LOCALE;
function setLocale(l) {
  locale = checkLocale(l) ?? DEFAULT_LOCALE;
}
const intlCache = /* @__PURE__ */ new Map();
function intl(req) {
  if (req.locale === void 0 || req.locale === null) req.locale = locale;
  const key = JSON.stringify(req);
  let v = intlCache.get(key);
  if (v === void 0) {
    v = String(host("intl", key) ?? "");
    if (intlCache.size > 5e3) intlCache.clear();
    intlCache.set(key, v);
  }
  return v;
}
const parse = (s, fallback) => {
  try {
    return JSON.parse(s);
  } catch {
    return fallback;
  }
};
const DATE_FIELDS = ["weekday", "year", "month", "day"];
const TIME_FIELDS = ["dayPeriod", "hour", "minute", "second", "fractionalSecondDigits"];
function dateTimeOptions(opts, required, defaults) {
  const o = opts !== null && (typeof opts === "object" || typeof opts === "function") ? { ...opts } : {};
  const has = (keys) => keys.some((k) => o[k] !== void 0);
  if (o.dateStyle !== void 0 || o.timeStyle !== void 0) return o;
  if (required !== "time" && has(DATE_FIELDS)) return o;
  if (required !== "date" && has(TIME_FIELDS)) return o;
  if (defaults !== "time") o.year = o.month = o.day = "numeric";
  if (defaults !== "date") o.hour = o.minute = o.second = "numeric";
  return o;
}
const DATE_METHODS = { toLocaleString: ["any", "all"], toLocaleDateString: ["date", "date"], toLocaleTimeString: ["time", "time"] };
function installIntl() {
  class NumberFormat {
    _l;
    _o;
    constructor(locale2, opts) {
      this._l = locale2;
      this._o = opts;
      this.format = this.format.bind(this);
    }
    format(value) {
      return intl({ kind: "number", locale: this._l, opts: this._o, value: Number(value) });
    }
    formatToParts(value) {
      return parse(intl({ kind: "numberParts", locale: this._l, opts: this._o, value: Number(value) }), []);
    }
    resolvedOptions() {
      return parse(intl({ kind: "numberOptions", locale: this._l, opts: this._o }), {});
    }
    static supportedLocalesOf(l) {
      return [].concat(l ?? []);
    }
  }
  class DateTimeFormat {
    _l;
    _o;
    constructor(locale2, opts) {
      this._l = locale2;
      this._o = dateTimeOptions(opts, "any", "date");
      this.format = this.format.bind(this);
    }
    format(value) {
      return intl({ kind: "date", locale: this._l, opts: this._o, value: value === void 0 ? Date.now() : +new Date(value) });
    }
    formatToParts(value) {
      return parse(intl({ kind: "dateParts", locale: this._l, opts: this._o, value: value === void 0 ? Date.now() : +new Date(value) }), []);
    }
    resolvedOptions() {
      return parse(intl({ kind: "dateOptions", locale: this._l, opts: this._o }), {});
    }
    static supportedLocalesOf(l) {
      return [].concat(l ?? []);
    }
  }
  class PluralRules {
    _l;
    _o;
    constructor(locale2, opts) {
      this._l = locale2;
      this._o = opts;
    }
    select(n) {
      return intl({ kind: "plural", locale: this._l, opts: this._o, value: Number(n) });
    }
  }
  class RelativeTimeFormat {
    _l;
    _o;
    constructor(locale2, opts) {
      this._l = locale2;
      this._o = opts;
    }
    format(value, unit) {
      return intl({ kind: "relative", locale: this._l, opts: this._o, value: Number(value), unit: String(unit) });
    }
  }
  class ListFormat {
    _l;
    _o;
    constructor(locale2, opts) {
      this._l = locale2;
      this._o = opts;
    }
    format(list) {
      return intl({ kind: "list", locale: this._l, opts: this._o, value: [...list].map(String) });
    }
  }
  class Collator {
    _l;
    _o;
    constructor(locale2, opts) {
      this._l = locale2;
      this._o = opts;
      this.compare = this.compare.bind(this);
    }
    compare(a, b) {
      return Number(intl({ kind: "compare", locale: this._l, opts: this._o, a: String(a), b: String(b) }));
    }
  }
  G.Intl = { NumberFormat, DateTimeFormat, PluralRules, RelativeTimeFormat, ListFormat, Collator, getCanonicalLocales: (l) => [].concat(l ?? []) };
  const def = (proto, name, value) => Object.defineProperty(proto, name, { value, writable: true, configurable: true });
  def(Number.prototype, "toLocaleString", function(l, o) {
    return intl({ kind: "number", locale: l, opts: o, value: Number(this) });
  });
  for (const [method, [required, defaults]] of Object.entries(DATE_METHODS)) {
    def(Date.prototype, method, function(l, o) {
      return intl({ kind: "dateMethod", method, locale: l, opts: dateTimeOptions(o, required, defaults), value: this.getTime() });
    });
  }
  def(String.prototype, "localeCompare", function(other, l, o) {
    return Number(intl({ kind: "compare", locale: l, opts: o, a: String(this), b: String(other) }));
  });
}
const mediaLists = /* @__PURE__ */ new Set();
function matchMedia(media) {
  const mql = new EventTarget();
  mql.media = String(media);
  mql._last = void 0;
  Object.defineProperty(mql, "matches", { get: () => mql._last = query({ q: "matchMedia", query: mql.media }).matches === true });
  mql.onchange = null;
  mql.addListener = (fn) => mql.addEventListener("change", fn);
  mql.removeListener = (fn) => mql.removeEventListener("change", fn);
  const add = mql.addEventListener.bind(mql);
  mql.addEventListener = (type, fn, o) => {
    mediaLists.add(mql);
    mql._last ??= mql.matches;
    add(type, fn, o);
  };
  return mql;
}
function mediaChanged() {
  invalidateLayout();
  for (const mql of mediaLists) {
    const before = mql._last;
    const now = mql.matches;
    if (before !== void 0 && before !== now) {
      const ev = new Event("change");
      ev.matches = now;
      ev.media = mql.media;
      try {
        if (typeof mql.onchange === "function") mql.onchange(ev);
        mql.dispatchEvent(ev);
      } catch (e) {
        reportError(e);
      }
    }
  }
}
const resizeObservers = /* @__PURE__ */ new Set();
class ResizeObserver {
  _cb;
  _targets = /* @__PURE__ */ new Set();
  constructor(cb) {
    this._cb = cb;
  }
  observe(el) {
    if (!el || this._targets.has(el)) return;
    this._targets.add(el);
    resizeObservers.add(this);
    callMethod(el, "observeResize");
  }
  unobserve(el) {
    if (this._targets.delete(el)) callMethod(el, "unobserveResize");
  }
  disconnect() {
    for (const el of this._targets) callMethod(el, "unobserveResize");
    this._targets.clear();
    resizeObservers.delete(this);
  }
}
function fireResize(entries, lookup) {
  invalidateLayout();
  for (const ro of [...resizeObservers]) {
    const mine = [];
    for (const e of entries) {
      const target = lookup(e.id);
      if (!target || !ro._targets.has(target)) continue;
      const rect = { x: 0, y: 0, top: 0, left: 0, width: e.width, height: e.height, right: e.width, bottom: e.height };
      const size = [{ inlineSize: e.width, blockSize: e.height }];
      mine.push({ target, contentRect: rect, contentBoxSize: size, borderBoxSize: size, devicePixelContentBoxSize: [{ inlineSize: e.width * G.devicePixelRatio, blockSize: e.height * G.devicePixelRatio }] });
    }
    if (mine.length) {
      try {
        ro._cb(mine, ro);
      } catch (err) {
        reportError(err);
      }
    }
  }
}
class IntersectionObserver {
  _cb;
  root = null;
  rootMargin = "0px";
  thresholds = [0];
  constructor(cb) {
    this._cb = cb;
    unsupported("IntersectionObserver (emulated: every observed element reports as visible)");
  }
  observe(target) {
    G.setTimeout(() => {
      try {
        const rect = target.getBoundingClientRect();
        this._cb([{ target, isIntersecting: true, intersectionRatio: 1, boundingClientRect: rect, intersectionRect: rect, rootBounds: null, time: G.performance.now() }], this);
      } catch (e) {
        reportError(e);
      }
    }, 0);
  }
  unobserve() {
  }
  disconnect() {
  }
  takeRecords() {
    return [];
  }
}
class NetworkDisabledError extends Error {
  constructor(api) {
    super(`${api} is not available: widgets have no network access`);
    this.name = "NetworkDisabledError";
  }
}
function blocked(api, detail) {
  diag("network-blocked", detail === void 0 ? api : `${api} ${String(detail).slice(0, 200)}`);
  return new NetworkDisabledError(api);
}
function installNetworkStubs() {
  const ctor = (name) => {
    const C = function(arg) {
      throw blocked(name, typeof arg === "string" ? arg : void 0);
    };
    Object.defineProperty(C, "name", { value: name });
    return C;
  };
  G.fetch = (input) => Promise.reject(blocked("fetch", typeof input === "string" ? input : input?.url));
  for (const name of ["XMLHttpRequest", "WebSocket", "EventSource", "RTCPeerConnection", "webkitRTCPeerConnection", "RTCDataChannel", "Worker", "SharedWorker", "WebTransport", "BroadcastChannel"]) G[name] = ctor(name);
  G.importScripts = (...urls) => {
    throw blocked("importScripts", urls[0]);
  };
  G.Request = ctor("Request");
}
let colorScheme = "light";
let themeParams = Object.freeze(completeThemeParams({}, "light"));
const WIDGET_EVENTS = ["themeChanged", "activated", "deactivated", "chatDataChanged", "publicDataChanged", "contentSafeAreaChanged"];
const widgetHandlers = new Map(WIDGET_EVENTS.map((t) => [t, []]));
const themeCallbacks = [];
function fireWidgetEvent(type) {
  for (const cb of [...widgetHandlers.get(type)]) {
    try {
      cb.call(G.TelegramWidget);
    } catch (e) {
      reportError(e);
    }
  }
}
function setTheme(theme, notify) {
  const t = typeof theme === "object" && theme !== null ? theme : { theme };
  const scheme = t.theme === "dark" || t.colorScheme === "dark" ? "dark" : "light";
  const params = completeThemeParams(t.themeParams ?? t.params, scheme);
  const changed = scheme !== colorScheme || Object.keys(params).some((k) => params[k] !== themeParams[k]);
  colorScheme = scheme;
  if (changed) themeParams = Object.freeze(params);
  if (!notify || !changed) return;
  fireWidgetEvent("themeChanged");
  for (const cb of [...themeCallbacks]) {
    try {
      cb(colorScheme);
    } catch (e) {
      reportError(e);
    }
  }
}
let contentSafeArea = NO_CONTENT_SAFE_AREA;
function setContentSafeArea(area, notify) {
  const next = checkContentSafeArea(area);
  if (CONTENT_SAFE_AREA_FIELDS.every((k) => next[k] === contentSafeArea[k])) return;
  contentSafeArea = Object.freeze(next);
  invalidateLayout();
  if (notify) fireWidgetEvent("contentSafeAreaChanged");
}
function fireActivation() {
  fireWidgetEvent(hidden ? "deactivated" : "activated");
}
const bridge = (method, ...args) => host("bridge", JSON.stringify([method, args]));
function link(method, url) {
  const checked = checkLink(method, url);
  if (checked === null) {
    throw new TypeError(method === "openLink" ? "openLink: expected an absolute https: URL of at most 256 characters, without a user name, not on t.me (use openTelegramLink)" : "openTelegramLink: expected https://t.me/\u2026 (or telegram.me, telegram.dog) of at most 256 characters");
  }
  bridge(method, checked);
}
function followLink(href) {
  const url = String(href ?? "").trim();
  if (/^javascript:/i.test(url)) return diag("navigation-blocked", "javascript: link ignored");
  if (checkLink("openTelegramLink", url) !== null) return link("openTelegramLink", url);
  if (checkLink("openLink", url) !== null) return link("openLink", url);
  diag("navigation-blocked", `link ignored (openLink takes https: URLs of at most 256 characters): ${url.slice(0, 200)}`);
}
function haptic(kind, value) {
  if (kind === "impact" && !HAPTIC_IMPACT_STYLES.includes(value)) throw new TypeError(`HapticFeedback.impactOccurred: style must be one of ${HAPTIC_IMPACT_STYLES.join(", ")}`);
  if (kind === "notification" && !HAPTIC_NOTIFICATION_TYPES.includes(value)) throw new TypeError(`HapticFeedback.notificationOccurred: type must be one of ${HAPTIC_NOTIFICATION_TYPES.join(", ")}`);
  if (kind === "selection") bridge("haptic", "selection");
  else bridge("haptic", kind, value);
  return HapticFeedback;
}
const HapticFeedback = Object.freeze({
  impactOccurred: (style) => haptic("impact", style),
  notificationOccurred: (type) => haptic("notification", type),
  selectionChanged: () => haptic("selection")
});
let resizeAnchor = DEFAULT_RESIZE_ANCHOR;
let watchingPublicData = false;
function watchPublicData(on) {
  if (on === watchingPublicData) return;
  watchingPublicData = on;
  bridge("watchPublicData", on);
}
function setResizeAnchor(edge) {
  const checked = checkResizeAnchor(edge);
  if (checked === null) throw new TypeError("setResizeAnchor: edge must be 'top' or 'bottom'");
  if (checked === resizeAnchor) return;
  resizeAnchor = checked;
  bridge("setResizeAnchor", checked);
}
let chatData = null;
let publicData = null;
let isCopy = false;
let canQuery = false;
let isPreview = false;
let chatType = null;
let viewer = null;
let walletAvailable = false;
function configureWidget(config) {
  isCopy = config.isCopy === true;
  isPreview = config.isPreview === true;
  canQuery = config.canQuery === true && !isPreview;
  chatData = isCopy ? null : checkWidgetDataValue(config.chatData);
  publicData = checkWidgetDataValue(config.publicData);
  chatType = checkChatType(config.chatType);
  const v = checkViewer(config.viewer).viewer;
  viewer = v && Object.freeze(v);
  walletAvailable = config.wallet === true && canQuery;
}
function applyData(data) {
  const d = typeof data === "object" && data !== null ? data : {};
  const c = isCopy ? null : checkWidgetDataValue(d.chatData);
  const p = checkWidgetDataValue(d.publicData);
  const chatChanged = c !== chatData, publicChanged = p !== publicData;
  chatData = c;
  publicData = p;
  if (chatChanged) fireWidgetEvent("chatDataChanged");
  if (publicChanged) fireWidgetEvent("publicDataChanged");
}
const REQUEST_MESSAGES = {
  preview: "a preview (an inline result not sent yet) cannot ask the bot",
  "no-wallet": "the client has no wallet for this user (TelegramWidget.wallet is null)",
  disabled: "requests are off for this message (the bot did not allow them here)",
  "no-activation": "it needs a tap on the widget and runs in that tap's handler, one call per tap; background requests only where the client allows them (the private chat with the bot)",
  unsupported: "this client does not deliver requests",
  BUSY: "a request is already in flight; wait for its answer",
  RATE_LIMITED: "too many requests (background requests at most once per 5 s); try again later",
  TIMEOUT: "the bot did not answer in time",
  FAILED: "the client could not deliver the request",
  INVALID_ANSWER: "the bot's answer broke the limits (a result over 1024 bytes, or not text)"
};
const WALLET_MESSAGES = {
  "no-activation": "it needs a tap on the widget and runs in that tap's handler (one call per tap), or follows within 10 s the answer to a call made by a tap",
  REJECTED: "the user declined in the wallet window",
  BAD_REQUEST: "the wallet refused it (the network, the sender, the expiry or the cells)",
  FAILED: "the client could not complete the call"
};
function requestError(code, reason, label) {
  const key = typeof reason === "string" && code === "NOT_ALLOWED" ? reason : code;
  const wallet = label !== "request" ? WALLET_MESSAGES[key] : void 0;
  const e = new Error(label + ": " + (wallet ?? REQUEST_MESSAGES[key] ?? REQUEST_MESSAGES["no-activation"]));
  e.name = "WidgetRequestError";
  e.code = code;
  return e;
}
let requestSeq = 0;
const pendingRequests = /* @__PURE__ */ new Map();
function pending(label, send) {
  const id = ++requestSeq;
  return new Promise((resolve, reject) => {
    pendingRequests.set(id, { resolve, reject, label });
    send(id);
  });
}
function request(data, options) {
  const checked = checkRequestData(data);
  if (checked === null) throw new TypeError("request: data must be a string of 1 to 64 bytes (UTF-8), without lone surrogates");
  const opts = options === void 0 ? { wallet: false } : checkRequestOptions(options);
  if (opts === null) throw new TypeError("request: options must be an object with at most `wallet` (a boolean)");
  if (!canQuery) return Promise.reject(requestError("NOT_ALLOWED", isPreview ? "preview" : "disabled", "request"));
  if (opts.wallet && !walletAvailable) return Promise.reject(requestError("NOT_ALLOWED", "no-wallet", "request"));
  return pending("request", (id) => opts.wallet ? bridge("request", id, checked, { wallet: true }) : bridge("request", id, checked));
}
function walletCall(method, arg, data) {
  const label = "wallet." + method;
  const checked = method === "sendTransaction" ? checkWalletTransaction(arg) : checkSignDataPayload(arg);
  if (checked === null) {
    throw new TypeError(method === "sendTransaction" ? label + ": expected TON Connect's transaction: { valid_until?, network?, from?, messages: [{ address, amount, payload?, stateInit? }] }, 1 to 255 messages, user-friendly addresses, amounts as decimal strings of nanotons, payloads in base64 (at most 8192 characters each, 65536 together)" : label + ": expected TON Connect's payload: { type: 'text', text } (at most 4096 bytes), { type: 'binary', bytes } or { type: 'cell', schema, cell } (base64 of at most 4096 characters); no domain");
  }
  const label64 = checkRequestData(data);
  if (label64 === null) throw new TypeError(label + ": data must be a string of 1 to 64 bytes (UTF-8), without lone surrogates");
  if (!walletAvailable) return Promise.reject(requestError("NOT_ALLOWED", "no-wallet", label));
  return pending(label, (id) => bridge("wallet", id, method, checked, label64));
}
const walletApi = Object.freeze({
  /** Ask the user to send a transaction in the client's wallet window (TON Connect's `sendTransaction` request); resolves with the bot's answer `{ result }` once it is sent. */
  sendTransaction: (transaction, data) => walletCall("sendTransaction", transaction, data),
  /** Ask the user to sign data in the client's wallet window (TON Connect's `signData` payload); the signature goes to the bot, which resolves this with its answer `{ result }`. */
  signData: (payload, data) => walletCall("signData", payload, data)
});
function bridgeEvent(event) {
  const e = typeof event === "object" && event !== null ? event : {};
  if (e.type === "data") return applyData(e);
  if (e.type !== "answer") return;
  const p = typeof e.id === "number" ? pendingRequests.get(e.id) : void 0;
  if (!p) return;
  pendingRequests.delete(e.id);
  if (typeof e.error === "string") {
    p.reject(requestError(REQUEST_ERRORS.includes(e.error) ? e.error : "FAILED", e.reason, p.label));
    return;
  }
  const result = typeof e.result === "string" ? e.result : null;
  p.resolve(Object.freeze({ result }));
}
function copyText(text) {
  const checked = checkCopyText(text);
  if (checked === null) throw new TypeError("copyText: text must be a string of 1 to 256 characters (UTF-16), without lone surrogates");
  bridge("copyText", checked);
}
function installBridge() {
  const widget = {
    /** The widget profile this client enforces (docs/profile-v1.md); a later profile only adds features. */
    get profile() {
      return PROFILE_VERSION;
    },
    isProfileAtLeast(n) {
      return typeof n === "number" && PROFILE_VERSION >= n;
    },
    get colorScheme() {
      return colorScheme;
    },
    /** The chat's palette as `#rrggbb`, Mini Apps keys; a fresh frozen object per change. */
    get themeParams() {
      return themeParams;
    },
    get isActive() {
      return !hidden;
    },
    /**
     * What the client draws over the widget, in CSS px (the `--tg-content-safe-area-*` root variables, `env(safe-area-inset-*)`):
     * `bottom` is the band of the message time over a widget with no caption below it, `cornerLeft` / `cornerRight` the
     * client's corner in it; 0 with a caption below. A fresh frozen object per change, then `contentSafeAreaChanged`.
     */
    get contentSafeAreaInset() {
      return contentSafeArea;
    },
    onEvent(type, handler) {
      const list = widgetHandlers.get(String(type));
      if (!list || typeof handler !== "function" || list.includes(handler) || list.length >= MAX_HANDLERS_PER_EVENT) return;
      list.push(handler);
    },
    offEvent(type, handler) {
      const list = widgetHandlers.get(String(type));
      const i = list ? list.indexOf(handler) : -1;
      if (i >= 0) list.splice(i, 1);
    },
    /** Ask the client to open an external https: page (the user confirms in a native dialog); needs a tap. */
    openLink(url) {
      link("openLink", url);
    },
    /** Ask the client to open a t.me link through its own handling; needs a tap. */
    openTelegramLink(url) {
      link("openTelegramLink", url);
    },
    HapticFeedback,
    /** Signal that the widget has rendered its initial state. */
    ready() {
      bridge("ready");
    },
    /**
     * The edge of the bubble that stays put on screen when the widget's height changes, from now on: `'top'` (the
     * default: the bubble grows and shrinks downward) or `'bottom'` (it grows upward, its bottom stays).
     */
    setResizeAnchor(edge) {
      setResizeAnchor(edge);
    },
    /**
     * Ask for live shared data: while the widget is on screen the client polls its `publicData` (a shared widget's,
     * at the server's period) and `publicDataChanged` brings the new value. Without it the widget gets `publicData`
     * with the message and the bot's pushed edits only. No tap needed; calling it again changes nothing.
     */
    watchPublicData() {
      watchPublicData(true);
    },
    /** Stop asking for live shared data (`watchPublicData`). */
    unwatchPublicData() {
      watchPublicData(false);
    },
    /** What the bot keeps for this message (in a group every member sees it; a forward never gets it); null for none or in a copy. `chatDataChanged` when the bot edits it. */
    get chatData() {
      return chatData;
    },
    /** What the bot keeps for everyone, a forward included (a snapshot, or a value shared with the original); null for none. `publicDataChanged` when it changes. */
    get publicData() {
      return publicData;
    },
    /** This message is a forwarded copy: no `chatData`; requests only if the bot sent the widget live, on a tap. */
    get isForward() {
      return isCopy;
    },
    /** An inline result shown before it is sent: data only, no input, no requests, nothing about the user. */
    get isPreview() {
      return isPreview;
    },
    /** The kind of chat the widget is in (`private`, `group`, `supergroup`, `channel`); null in a copy that cannot request, or when the client does not say. */
    get chatType() {
      return chatType;
    },
    /** Who looks at the widget, `{ id }` (the Telegram user id the bot gets with a request); null in a copy that cannot request. */
    get viewer() {
      return viewer;
    },
    /**
     * Ask the bot (a callback button inside the widget): `data` of 1–64 bytes; resolves with `{ result }`, rejects with `error.code`. Needs a tap, except in the private chat with the bot.
     * `{ wallet: true }` (on a tap only, where `wallet` is not null): the bot gets the user's wallet with it, created if the user had none.
     */
    request(data, options) {
      return request(data, options);
    },
    /**
     * Gram Wallet (docs/sdk-v1.md §2.18): `sendTransaction(transaction, data)` and `signData(payload, data)` in TON Connect's
     * formats, each confirmed by the user in the client's own window; on a tap, or within 10 s of the answer to a call made by a tap.
     * Null where the client has no wallet for this user, where the widget cannot ask the bot, and in a preview.
     */
    get wallet() {
      return walletAvailable ? walletApi : null;
    },
    /** Copy text to the clipboard (the client shows what it copied); 1–256 characters; needs a tap. */
    copyText(text) {
      copyText(text);
    },
    /** Deprecated alias of `colorScheme`. */
    get theme() {
      return colorScheme;
    },
    /** Deprecated: `onEvent('themeChanged', …)`; called at once with the colour scheme and on every change. */
    onTheme(cb) {
      if (typeof cb !== "function" || themeCallbacks.length >= MAX_HANDLERS_PER_EVENT) return;
      themeCallbacks.push(cb);
      try {
        cb(colorScheme);
      } catch (e) {
        reportError(e);
      }
    }
  };
  G.TelegramWidget = widget;
}
function installPolyfills() {
  G.TextEncoder = class {
    encoding = "utf-8";
    encode(s = "") {
      const bin = unescape(encodeURIComponent(String(s)));
      const out = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
      return out;
    }
  };
  G.TextDecoder = class {
    encoding = "utf-8";
    decode(buf) {
      if (!buf) return "";
      const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf.buffer ?? buf);
      let bin = "";
      for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
      try {
        return decodeURIComponent(escape(bin));
      } catch {
        return bin;
      }
    }
  };
  G.queueMicrotask ??= (fn) => {
    Promise.resolve().then(fn).catch(reportError);
  };
  G.structuredClone ??= (v) => v === void 0 ? void 0 : JSON.parse(JSON.stringify(v));
  G.crypto = {
    getRandomValues(arr) {
      const bytes = JSON.parse(host("random", String(arr.byteLength)));
      new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength).set(bytes);
      return arr;
    },
    randomUUID() {
      const b = JSON.parse(host("random", "16"));
      b[6] = b[6] & 15 | 64;
      b[8] = b[8] & 63 | 128;
      const h = b.map((x) => x.toString(16).padStart(2, "0")).join("");
      return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
    }
  };
  class URLSearchParams {
    _e = [];
    constructor(init = "") {
      if (typeof init === "string") {
        for (const part of init.replace(/^\?/, "").split("&")) {
          if (!part) continue;
          const [k, v = ""] = part.split("=");
          this._e.push([decodeURIComponent(k.replace(/\+/g, " ")), decodeURIComponent(v.replace(/\+/g, " "))]);
        }
      } else if (init && typeof init === "object") for (const [k, v] of typeof init[Symbol.iterator] === "function" ? init : Object.entries(init)) this._e.push([String(k), String(v)]);
    }
    get(k) {
      return this._e.find(([n]) => n === k)?.[1] ?? null;
    }
    getAll(k) {
      return this._e.filter(([n]) => n === k).map(([, v]) => v);
    }
    has(k) {
      return this._e.some(([n]) => n === k);
    }
    set(k, v) {
      this.delete(k);
      this._e.push([String(k), String(v)]);
    }
    append(k, v) {
      this._e.push([String(k), String(v)]);
    }
    delete(k) {
      this._e = this._e.filter(([n]) => n !== k);
    }
    forEach(cb) {
      for (const [k, v] of this._e) cb(v, k, this);
    }
    entries() {
      return this._e[Symbol.iterator]();
    }
    keys() {
      return this._e.map(([k]) => k)[Symbol.iterator]();
    }
    values() {
      return this._e.map(([, v]) => v)[Symbol.iterator]();
    }
    [Symbol.iterator]() {
      return this.entries();
    }
    toString() {
      return this._e.map(([k, v]) => encodeURIComponent(k) + "=" + encodeURIComponent(v)).join("&");
    }
  }
  G.URLSearchParams = URLSearchParams;
  class URL {
    constructor(url, base) {
      let s = String(url);
      if (!/^[a-z][a-z0-9+.-]*:/i.test(s) && base !== void 0) s = String(base).replace(/[^/]*$/, "") + s;
      const m = /^([a-z][a-z0-9+.-]*:)(?:\/\/([^/?#]*))?([^?#]*)(\?[^#]*)?(#.*)?$/i.exec(s);
      if (!m) throw new TypeError("Invalid URL: " + s);
      this.protocol = m[1].toLowerCase();
      this.host = m[2] ?? "";
      const [hostname, port = ""] = this.host.replace(/^.*@/, "").split(":");
      this.hostname = hostname;
      this.port = port;
      this.pathname = m[3] || (m[2] !== void 0 ? "/" : "");
      this.search = m[4] ?? "";
      this.hash = m[5] ?? "";
      this.searchParams = new URLSearchParams(this.search);
      this.origin = m[2] !== void 0 ? `${this.protocol}//${this.host}` : "null";
    }
    get href() {
      return `${this.protocol}${this.host || this.protocol === "file:" ? "//" + this.host : ""}${this.pathname}${this.search}${this.hash}`;
    }
    toString() {
      return this.href;
    }
    toJSON() {
      return this.href;
    }
    static createObjectURL() {
      unsupported("URL.createObjectURL");
      return "";
    }
    static revokeObjectURL() {
    }
    static canParse(u, b) {
      try {
        new URL(u, b);
        return true;
      } catch {
        return false;
      }
    }
  }
  G.URL = URL;
  class AbortSignal extends EventTarget {
    aborted = false;
    reason = void 0;
    throwIfAborted() {
      if (this.aborted) throw this.reason;
    }
  }
  G.AbortSignal = AbortSignal;
  G.AbortController = class {
    signal = new AbortSignal();
    abort(reason) {
      if (this.signal.aborted) return;
      this.signal.aborted = true;
      this.signal.reason = reason ?? new Error("AbortError");
      this.signal.dispatchEvent(new Event("abort"));
    }
  };
  G.Blob = class {
    size = 0;
    type = "";
    constructor(parts = [], opts = {}) {
      this.type = opts.type ?? "";
      this.size = parts.reduce((n, p) => n + (p?.length ?? p?.byteLength ?? 0), 0);
      unsupported("Blob");
    }
  };
  G.FileReader = class {
    constructor() {
      unsupported("FileReader");
    }
    readAsText() {
    }
    readAsDataURL() {
    }
    readAsArrayBuffer() {
    }
    addEventListener() {
    }
  };
  G.CSS = { supports: cssSupports, escape: (s) => String(s).replace(/[^\w-]/g, (c) => "\\" + c) };
}
function setViewport(v) {
  G.innerWidth = G.outerWidth = v.innerWidth;
  G.innerHeight = G.outerHeight = v.innerHeight;
  G.devicePixelRatio = v.dpr;
  G.screen = { width: v.innerWidth, height: v.innerHeight, availWidth: v.innerWidth, availHeight: v.innerHeight, colorDepth: 24, pixelDepth: 24, orientation: { type: "portrait-primary", angle: 0, addEventListener() {
  } } };
}
function installWindow(deps) {
  installConsole();
  installPolyfills();
  installIntl();
  installNetworkStubs();
  installBridge();
  for (const name of ["window", "self", "top", "parent", "frames"]) {
    try {
      Object.defineProperty(G, name, { value: G, writable: true, configurable: true, enumerable: false });
    } catch {
    }
  }
  G.document = deps.document;
  setViewport(deps.viewport);
  G.scrollX = G.scrollY = G.pageXOffset = G.pageYOffset = 0;
  G.length = 0;
  G.name = "";
  G.closed = false;
  G.isSecureContext = true;
  G.origin = "null";
  const t0 = Number(host("now"));
  originTime = t0;
  G.performance = {
    now: () => Number(host("now")) - t0,
    timeOrigin: Date.now(),
    mark() {
    },
    measure() {
    },
    getEntriesByName: () => [],
    getEntriesByType: () => [],
    clearMarks() {
    },
    clearMeasures() {
    }
  };
  G.setTimeout = (fn, delay, ...args) => setTimer(fn, delay, args, false);
  G.setInterval = (fn, delay, ...args) => setTimer(fn, delay, args, true);
  G.clearTimeout = G.clearInterval = clearTimer;
  G.requestAnimationFrame = (cb) => {
    const id = frameSeq++;
    if (!frameCallbacks.size) host("raf");
    frameCallbacks.set(id, cb);
    return id;
  };
  G.cancelAnimationFrame = (id) => {
    frameCallbacks.delete(id);
  };
  G.requestIdleCallback = (cb) => G.setTimeout(() => cb({ didTimeout: false, timeRemaining: () => 10 }), 1);
  G.cancelIdleCallback = clearTimer;
  G.localStorage = makeStorage("local");
  G.sessionStorage = makeStorage("session");
  G.DOMException = DOMException;
  G.matchMedia = matchMedia;
  G.ResizeObserver = ResizeObserver;
  G.IntersectionObserver = IntersectionObserver;
  G.getComputedStyle = deps.getComputedStyle;
  G.reportError = (e) => reportError(e);
  const navBlocked = (what, url) => diag("navigation-blocked", url === void 0 ? what : `${what} \u2192 ${String(url).slice(0, 200)}`);
  const location = {
    protocol: "about:",
    host: "",
    hostname: "",
    port: "",
    pathname: "srcdoc",
    search: "",
    hash: "",
    origin: "null",
    assign: (u) => navBlocked("location.assign", u),
    replace: (u) => navBlocked("location.replace", u),
    reload: () => navBlocked("location.reload"),
    toString: () => "about:srcdoc"
  };
  Object.defineProperty(location, "href", { get: () => "about:srcdoc", set: (u) => navBlocked("location.href", u), enumerable: true });
  Object.defineProperty(G, "location", { get: () => location, set: (u) => navBlocked("location", u), configurable: true });
  Object.defineProperty(deps.document, "location", { get: () => location, set: (u) => navBlocked("document.location", u), configurable: true });
  G.history = { length: 1, state: null, pushState() {
  }, replaceState() {
  }, back() {
  }, forward() {
  }, go() {
  }, scrollRestoration: "auto" };
  G.open = (url) => {
    if (url) followLink(url);
    return null;
  };
  G.close = () => {
  };
  G.print = () => unsupported("window.print");
  G.postMessage = () => unsupported("window.postMessage");
  G.alert = () => {
    unsupported("alert/confirm/prompt (blocking dialogs)");
  };
  G.confirm = () => {
    unsupported("alert/confirm/prompt (blocking dialogs)");
    return false;
  };
  G.prompt = () => {
    unsupported("alert/confirm/prompt (blocking dialogs)");
    return null;
  };
  G.scrollTo = G.scroll = G.scrollBy = () => {
  };
  G.focus = G.blur = () => {
  };
  G.getSelection = () => ({ rangeCount: 0, isCollapsed: true, toString: () => "", removeAllRanges() {
  }, addRange() {
  }, getRangeAt: () => null, anchorNode: null, focusNode: null });
  const notAllowed = (api) => {
    unsupported(api);
    return Promise.reject(new DOMException(`${api} is not available in a widget`, "NotAllowedError"));
  };
  G.navigator = {
    userAgent: "Mozilla/5.0 TelegramWidget/1.0",
    get language() {
      return locale;
    },
    get languages() {
      return Object.freeze([locale]);
    },
    platform: "TelegramWidget",
    vendor: "",
    onLine: false,
    cookieEnabled: false,
    hardwareConcurrency: 1,
    maxTouchPoints: 0,
    deviceMemory: 1,
    sendBeacon: (url) => {
      throw blocked("navigator.sendBeacon", url);
    },
    clipboard: {
      writeText: () => notAllowed("navigator.clipboard"),
      readText: () => notAllowed("navigator.clipboard"),
      write: () => notAllowed("navigator.clipboard"),
      read: () => notAllowed("navigator.clipboard")
    },
    vibrate: () => false,
    share: () => notAllowed("navigator.share"),
    canShare: () => false,
    mediaDevices: void 0,
    geolocation: void 0,
    serviceWorker: void 0
  };
  G.addEventListener = addEventListener;
  G.removeEventListener = removeEventListener;
  G.dispatchEvent = dispatchEvent;
}
export {
  DOMException,
  NetworkDisabledError,
  bridgeEvent,
  clearHostTimer,
  configureLimits,
  configureWidget,
  fireActivation,
  fireFrame,
  fireResize,
  fireTimer,
  followLink,
  hostTimer,
  installWindow,
  isHidden,
  mediaChanged,
  preloadStorage,
  reportError,
  setContentSafeArea,
  setFrameHook,
  setHidden,
  setLocale,
  setTheme,
  setViewport,
  takeStorageCommit,
  timeOrigin
};
