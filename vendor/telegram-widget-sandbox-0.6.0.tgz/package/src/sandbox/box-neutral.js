const boxNeutralStyles = /* @__PURE__ */ new Set(["transform", "translate", "rotate", "scale", "opacity", "will-change", "filter", "backdrop-filter", "-webkit-backdrop-filter", "color", "background", "background-color", "background-image", "box-shadow", "transition", "transition-property", "transition-duration", "transition-delay", "transition-timing-function", "pointer-events", "cursor", "visibility"]);
function boxNeutral(o) {
  return o.op === "style" && boxNeutralStyles.has(o.name);
}
export {
  boxNeutral
};
