import { document } from "./dom";
function parseDeclarations(text) {
  const out = /* @__PURE__ */ new Map();
  let depth = 0;
  let quote = "";
  let start = 0;
  const push = (end) => {
    const decl = text.slice(start, end);
    const colon = decl.indexOf(":");
    if (colon > 0) {
      const name = decl.slice(0, colon).trim();
      let value = decl.slice(colon + 1).trim();
      let important = false;
      const m = value.includes("!") ? /!\s*important\s*$/i.exec(value) : null;
      if (m) {
        important = true;
        value = value.slice(0, m.index).trim();
      }
      if (name && value) {
        const key = name.startsWith("--") ? name : name.toLowerCase();
        out.delete(key);
        out.set(key, { value, important });
      }
    }
    start = end + 1;
  };
  if (text.indexOf('"') < 0 && text.indexOf("'") < 0 && text.indexOf("\\") < 0) {
    let open = text.indexOf("("), close = text.indexOf(")"), semi = text.indexOf(";");
    for (; ; ) {
      let at = open < 0 ? close : close < 0 ? open : Math.min(open, close);
      if (semi >= 0 && (at < 0 || semi < at)) at = semi;
      if (at < 0) break;
      if (at === open) {
        depth++;
        open = text.indexOf("(", at + 1);
      } else if (at === close) {
        depth = Math.max(0, depth - 1);
        close = text.indexOf(")", at + 1);
      } else {
        if (depth === 0) push(at);
        semi = text.indexOf(";", at + 1);
      }
    }
    push(text.length);
    return out;
  }
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === "\\") i++;
    else if (quote) {
      if (ch === quote) quote = "";
    } else if (ch === '"' || ch === "'") quote = ch;
    else if (ch === "(") depth++;
    else if (ch === ")") depth = Math.max(0, depth - 1);
    else if (ch === ";" && depth === 0) push(i);
  }
  push(text.length);
  return out;
}
function serializeDeclarations(map) {
  let out = "";
  for (const [name, d] of map) out += `${out ? " " : ""}${name}: ${d.value}${d.important ? " !important" : ""};`;
  return out;
}
const kebabCache = /* @__PURE__ */ new Map();
function toKebab(prop) {
  let k = kebabCache.get(prop);
  if (k === void 0) {
    if (kebabCache.size > 1024) kebabCache.clear();
    kebabCache.set(prop, k = kebabOf(prop));
  }
  return k;
}
function kebabOf(prop) {
  if (prop.startsWith("--") || prop.includes("-")) return prop;
  if (prop === "cssFloat") return "float";
  const k = prop.replace(/[A-Z]/g, (c) => "-" + c.toLowerCase());
  return /^(webkit|moz|ms|o)-/.test(k) ? "-" + k : k;
}
const styles = /* @__PURE__ */ new WeakMap();
const impls = /* @__PURE__ */ new WeakMap();
const pendingStyles = /* @__PURE__ */ new Set();
let setAttrValue = null;
function setRawAttrValueSetter(set) {
  setAttrValue = set;
}
const SVG = "http://www.w3.org/2000/svg";
const canonicalKeys = /* @__PURE__ */ new Map();
const KEY = /^(--[A-Za-z0-9_-]+|[a-z][a-z0-9-]*)$/;
const VALUE_FLAT = /[;!\\"']/;
const VALUE_PARENS = /^[^;!\\"'()]*(\([^;!\\"'()]*\)[^;!\\"'()]*)*$/;
function canonicalKey(name) {
  let ok = canonicalKeys.get(name);
  if (ok === void 0) {
    if (canonicalKeys.size > 1024) canonicalKeys.clear();
    canonicalKeys.set(name, ok = KEY.test(name));
  }
  return ok;
}
function canonicalValue(value) {
  return value.indexOf("(") < 0 && value.indexOf(")") < 0 ? !VALUE_FLAT.test(value) : VALUE_PARENS.test(value);
}
function canonicalMap(map) {
  for (const [name, d] of map) if (!canonicalKey(name) || !canonicalValue(d.value)) return false;
  return true;
}
function styleImplOf(el) {
  return impls.get(el);
}
function forgetSentStyle(el) {
  const impl = impls.get(el);
  if (impl) impl._sentText = null;
}
class StyleImpl {
  _el;
  _text = null;
  _map = /* @__PURE__ */ new Map();
  /** The element's style Attr while it is owned by the element. */
  _attr = null;
  /** The property map and attribute text the host was last told, when canonical. */
  _sent = null;
  _sentText = null;
  /** Properties written through the fast path since the last flush. */
  _keys = null;
  /** The map was re-parsed from a text written some other way since the host was told. */
  _reparsed = false;
  constructor(el) {
    this._el = el;
  }
  _attrText() {
    const a = this._attr;
    return a !== null && a.ownerElement === this._el ? String(a.value) : null;
  }
  _read() {
    let text = this._attrText();
    if (text === null) {
      text = this._el.getAttribute("style") ?? "";
      this._attr = this._el.ownerDocument === document ? this._el.getAttributeNode("style") : null;
    }
    if (text !== this._text) {
      this._text = text;
      this._map = parseDeclarations(text);
      this._reparsed = true;
    }
    return this._map;
  }
  _write(key) {
    const el = this._el;
    const a = this._attr;
    this._text = serializeDeclarations(this._map);
    if (key !== void 0 && setAttrValue !== null && this._sentText !== null && !this._reparsed && a !== null && a.ownerElement === el && el.namespaceURI !== SVG) {
      setAttrValue(a, this._text);
      const k = this._keys;
      if (k === null) {
        this._keys = key;
        pendingStyles.add(this);
      } else if (typeof k === "string") {
        if (k !== key) this._keys = /* @__PURE__ */ new Set([k, key]);
      } else k.add(key);
      return;
    }
    this._keys = null;
    el.setAttribute("style", this._text);
  }
  getPropertyValue(name) {
    return this._read().get(toKebab(String(name)))?.value ?? "";
  }
  getPropertyPriority(name) {
    return this._read().get(toKebab(String(name)))?.important ? "important" : "";
  }
  setProperty(name, value, priority) {
    const key = toKebab(String(name));
    const map = this._read();
    if (value === null || value === void 0 || value === "") {
      if (!map.delete(key)) return;
    } else {
      const v = String(value).trim();
      const old = map.get(key);
      const important = priority === "important";
      if (old && old.value === v && old.important === important) return;
      map.delete(key);
      map.set(key, { value: v, important });
    }
    this._write(key);
  }
  removeProperty(name) {
    const key = toKebab(String(name));
    const map = this._read();
    const old = map.get(key)?.value ?? "";
    if (map.delete(key)) this._write(key);
    return old;
  }
  item(i) {
    return [...this._read().keys()][i] ?? "";
  }
  get length() {
    return this._read().size;
  }
  get cssText() {
    return this._el.getAttribute("style") ?? "";
  }
  set cssText(v) {
    this._el.setAttribute("style", String(v));
  }
  [Symbol.iterator]() {
    return this._read().keys();
  }
}
const handler = {
  get(t, prop) {
    if (typeof prop === "symbol" || prop in t) {
      const v = t[prop];
      return typeof v === "function" ? v.bind(t) : v;
    }
    if (/^\d+$/.test(prop)) return t.item(Number(prop));
    return t.getPropertyValue(prop);
  },
  set(t, prop, value) {
    if (typeof prop === "symbol") return true;
    if (prop === "cssText") t.cssText = value;
    else if (!prop.startsWith("_")) t.setProperty(prop, value);
    else t[prop] = value;
    return true;
  },
  has: () => true
};
function styleOf(el) {
  let s = styles.get(el);
  if (!s) {
    const impl = new StyleImpl(el);
    impls.set(el, impl);
    styles.set(el, s = new Proxy(impl, handler));
  }
  return s;
}
export {
  StyleImpl,
  canonicalKey,
  canonicalMap,
  canonicalValue,
  forgetSentStyle,
  parseDeclarations,
  pendingStyles,
  serializeDeclarations,
  setRawAttrValueSetter,
  styleImplOf,
  styleOf,
  toKebab
};
