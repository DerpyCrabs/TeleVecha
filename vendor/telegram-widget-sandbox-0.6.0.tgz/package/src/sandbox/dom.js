import { parseHTML } from "linkedom";
import { parse, parseFragment } from "parse5";
const SVG_NS = "http://www.w3.org/2000/svg";
const HTML_NS = "http://www.w3.org/1999/xhtml";
const SCRIPT_INERT = /* @__PURE__ */ Symbol("tw.scriptInert");
const lw = parseHTML("<!DOCTYPE html><html><head></head><body></body></html>");
const document = lw.document;
const linkedomWindow = lw;
function ownerOf(proto, name) {
  for (let p = proto; p; p = Object.getPrototypeOf(p)) if (Object.prototype.hasOwnProperty.call(p, name)) return p;
  return null;
}
const EXPOSED = /* @__PURE__ */ Symbol("tw.exposed");
const KIDS_EXPOSED = /* @__PURE__ */ Symbol("tw.kidsExposed");
const domHooks = { observing: () => false, markDirty: (_node) => {
} };
let inPlaceText = true;
let inPlaceKilled = false;
let rawFirstChild;
let rawNextSibling;
let quiet = 0;
function quietly(fn) {
  quiet++;
  try {
    return fn();
  } finally {
    quiet--;
  }
}
function exposeNode(n) {
  if (quiet === 0 && n && typeof n === "object" && n.nodeType === 3) n[EXPOSED] = true;
  return n;
}
function exposeAll() {
  inPlaceKilled = true;
  inPlaceText = false;
}
function setInPlaceText(enabled) {
  inPlaceText = enabled && !inPlaceKilled;
}
{
  const samples = [document.createElement("div"), document.createTextNode("x"), document.createComment("x"), document.createDocumentFragment(), document];
  const wrapped = /* @__PURE__ */ new Set();
  rawFirstChild = Object.getOwnPropertyDescriptor(ownerOf(samples[0], "firstChild"), "firstChild").get;
  rawNextSibling = Object.getOwnPropertyDescriptor(ownerOf(samples[1], "nextSibling"), "nextSibling").get;
  for (const name of ["firstChild", "lastChild", "nextSibling", "previousSibling"]) {
    for (const sample of samples) {
      const proto = ownerOf(sample, name);
      const d = proto && Object.getOwnPropertyDescriptor(proto, name);
      if (!d?.get || wrapped.has(d.get)) continue;
      const get = d.get;
      const wrapper = function() {
        return exposeNode(get.call(this));
      };
      wrapped.add(wrapper);
      Object.defineProperty(proto, name, { ...d, get: wrapper });
    }
  }
  for (const sample of samples) {
    const proto = ownerOf(sample, "childNodes");
    const d = proto && Object.getOwnPropertyDescriptor(proto, "childNodes");
    if (!d?.get || wrapped.has(d.get)) continue;
    const get = d.get;
    const wrapper = function() {
      if (quiet === 0) this[KIDS_EXPOSED] = true;
      return get.call(this);
    };
    wrapped.add(wrapper);
    Object.defineProperty(proto, "childNodes", { ...d, get: wrapper });
  }
  for (const sample of samples) {
    const proto = ownerOf(sample, "normalize");
    if (!proto || wrapped.has(proto.normalize)) continue;
    const normalize = proto.normalize;
    const wrapper = function() {
      if (quiet === 0) this[KIDS_EXPOSED] = true;
      return normalize.call(this);
    };
    wrapped.add(wrapper);
    proto.normalize = wrapper;
  }
  const docProto = ownerOf(document, "createRange");
  for (const name of ["createRange", "createTreeWalker", "createNodeIterator", "evaluate"]) {
    const owner = ownerOf(document, name);
    if (!owner || typeof owner[name] !== "function") continue;
    const orig = owner[name];
    owner[name] = function(...args) {
      exposeAll();
      return orig.apply(this, args);
    };
  }
  void docProto;
}
{
  const sample = document.createElement("div");
  const tokens = sample.classList;
  const classListKey = Object.getOwnPropertySymbols(sample).find((k) => sample[k] === tokens);
  const addToken = Set.prototype.add;
  const classProto = ownerOf(sample, "className");
  const className = classProto && Object.getOwnPropertyDescriptor(classProto, "className");
  if (className?.set && classListKey) {
    const set = className.set;
    const SINGLE = /^\S+$/;
    Object.defineProperty(classProto, "className", {
      ...className,
      set(v) {
        const s = String(v);
        const a = s.length <= 256 && SINGLE.test(s) ? this.getAttributeNode("class") : null;
        if (!a) return set.call(this, v);
        const list = this[classListKey];
        if (list && a.value !== s) {
          list.clear();
          addToken.call(list, s);
        }
        a.value = s;
      }
    });
  }
  const firstChildOf = rawFirstChild;
  const nextSiblingOf = rawNextSibling;
  const textProto = ownerOf(sample, "textContent");
  const textContent = textProto && Object.getOwnPropertyDescriptor(textProto, "textContent");
  if (textContent?.set) {
    const set = textContent.set;
    Object.defineProperty(textProto, "textContent", {
      ...textContent,
      set(v) {
        const first = this.nodeType === 1 ? firstChildOf.call(this) : null;
        if (typeof v === "string" && v !== "" && first && first.nodeType === 3 && !nextSiblingOf.call(first)) {
          if (inPlaceText && !first[EXPOSED] && !this[KIDS_EXPOSED] && !domHooks.observing()) {
            first.data = v;
            return;
          }
          this.replaceChild(document.createTextNode(v), first);
          return;
        }
        set.call(this, v);
      }
    });
  }
}
function setAttrs(el, attrs) {
  for (const a of attrs) {
    try {
      el.setAttribute(a.prefix ? `${a.prefix}:${a.name}` : a.name, a.value);
    } catch {
    }
  }
}
function build(p5, parent, inertScripts = false) {
  for (const c of p5.childNodes ?? []) {
    if (c.nodeName === "#text") parent.appendChild(document.createTextNode(c.value));
    else if (c.nodeName === "#comment") parent.appendChild(document.createComment(c.data));
    else if (c.tagName) {
      let el;
      try {
        el = c.namespaceURI === SVG_NS ? document.createElementNS(SVG_NS, c.tagName) : document.createElement(c.tagName);
      } catch {
        continue;
      }
      setAttrs(el, c.attrs);
      if (inertScripts && c.tagName === "script") el[SCRIPT_INERT] = true;
      parent.appendChild(el);
      if (c.tagName === "template" && c.content && el.content) build(c.content, el.content, inertScripts);
      else build(c, el, inertScripts);
    }
  }
}
function loadDocument(html) {
  const p5 = parse(html);
  const root = p5.childNodes.find((n) => n.tagName === "html");
  if (!root) return;
  setAttrs(document.documentElement, root.attrs);
  for (const c of root.childNodes) {
    if (c.tagName === "head") {
      setAttrs(document.head, c.attrs);
      build(c, document.head);
    } else if (c.tagName === "body") {
      setAttrs(document.body, c.attrs);
      build(c, document.body);
    }
  }
}
function parseInto(context, html, target = context) {
  const svg = context.namespaceURI === SVG_NS && context.localName !== "foreignObject";
  const mock = { nodeName: context.localName, tagName: context.localName, attrs: [], namespaceURI: svg ? SVG_NS : HTML_NS, childNodes: [], parentNode: null };
  const frag = parseFragment(mock, String(html));
  build(frag, target, true);
}
let attrFast = true;
const SINGLE_TOKEN = /^\S+$/;
function setAttrFast(enabled) {
  attrFast = enabled;
}
function installAttributeFastPaths() {
  const sample = document.createElement("div");
  const tokens = sample.classList;
  const classListKey = Object.getOwnPropertySymbols(sample).find((k) => sample[k] === tokens);
  if (!classListKey) return;
  const nodeProto = ownerOf(sample, "getAttributeNode");
  const getNode = nodeProto && nodeProto.getAttributeNode;
  const getProto = ownerOf(sample, "getAttribute");
  const getAttribute = getProto && getProto.getAttribute;
  if (typeof getNode !== "function" || typeof getAttribute !== "function") return;
  getProto.getAttribute = function(name) {
    "use strict";
    if (attrFast && name === "class") {
      const list = this[classListKey];
      if (list && list.size === 1) {
        const a = getNode.call(this, "class");
        if (a) {
          const v = a.value;
          if (list.has(v)) {
            domHooks.markDirty(this);
            return v;
          }
        }
      }
    }
    return getAttribute.call(this, name);
  };
  const classProto = ownerOf(sample, "className");
  const d = classProto && Object.getOwnPropertyDescriptor(classProto, "className");
  if (!d?.set) return;
  const set = d.set;
  Object.defineProperty(classProto, "className", {
    ...d,
    set(v) {
      "use strict";
      if (attrFast && typeof v === "string" && SINGLE_TOKEN.test(v) && !domHooks.observing() && !this.attributeChangedCallback) {
        const a = getNode.call(this, "class");
        if (a && a.value === v) {
          domHooks.markDirty(this);
          domHooks.markDirty(a);
          return;
        }
      }
      set.call(this, v);
    }
  });
}
export {
  EXPOSED,
  SCRIPT_INERT,
  SVG_NS,
  build,
  document,
  domHooks,
  exposeAll,
  exposeNode,
  installAttributeFastPaths,
  linkedomWindow,
  loadDocument,
  parseInto,
  quietly,
  setAttrFast,
  setInPlaceText
};
