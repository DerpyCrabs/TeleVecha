import { build } from "esbuild";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { rendererBuildOptions, sandboxBuildOptions } from "./scripts/sandbox-build.js";
const pkgRoot = path.dirname(fileURLToPath(import.meta.url));
const ISOLATION_HEADERS = {
  "Cross-Origin-Opener-Policy": "same-origin",
  "Cross-Origin-Embedder-Policy": "require-corp",
  "Cross-Origin-Resource-Policy": "same-origin"
};
const VIRTUAL = {
  "virtual:sandbox-bundle": () => sandboxBuildOptions(pkgRoot),
  "virtual:renderer-bundle": () => rendererBuildOptions(pkgRoot)
};
async function bundleIife(options) {
  const out = await build(options);
  return out.outputFiles[0].text;
}
function widgetSandbox() {
  return {
    name: "widget-sandbox",
    config: () => ({
      worker: { format: "es" },
      optimizeDeps: { exclude: ["@telegram/widget-sandbox-quickjs"] },
      server: { headers: ISOLATION_HEADERS },
      preview: { headers: ISOLATION_HEADERS }
    }),
    resolveId(id) {
      if (id in VIRTUAL) return "\0" + id;
    },
    async load(id) {
      const v = VIRTUAL[id.slice(1)];
      if (!id.startsWith("\0") || !v) return;
      const code = await bundleIife(v());
      return `export default ${JSON.stringify(code)};`;
    },
    handleHotUpdate({ file, server }) {
      if (/\/src\/(sandbox|renderer|shared)\//.test(file)) {
        for (const id of Object.keys(VIRTUAL)) {
          const mod = server.moduleGraph.getModuleById("\0" + id);
          if (mod) server.moduleGraph.invalidateModule(mod);
        }
        server.ws.send({ type: "full-reload" });
      }
    },
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        const url = (req.url || "").split("?")[0];
        for (const [k, v] of Object.entries(ISOLATION_HEADERS)) res.setHeader(k, v);
        next();
      });
    }
  };
}
export {
  ISOLATION_HEADERS,
  widgetSandbox
};
